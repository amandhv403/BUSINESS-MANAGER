# Backup and restore

## What a successful backup means

The owner button **Download verified backup** writes a JSON file, checks that the file size is greater than a tiny empty file, and only then records a successful backup in the database. If the file cannot be written, it is not called successful.

That download includes business records and password hashes. Keep it private. It is not included in the source ZIP.

## Database dump for a technician

From a computer that can reach PostgreSQL:

```bash
pg_dump "$DATABASE_URL" -Fc -f "backup-$(date +%F).dump"
```

Check that the file exists and is not 0 bytes before you trust it.

Uploaded files are in `storage/uploads`. Copy that folder as well:

```bash
tar -czf "files-$(date +%F).tar.gz" storage/uploads
```

## How often

There is no automatic schedule running on this computer. On Windows, use Task Scheduler to run the dump command every night. On a server, use cron. If the dashboard says no verified backup exists, take one before adding real customers.

## Restore

Restoring replaces data. Do this only on a copy first.

```bash
pg_restore --clean --if-exists -d "$DATABASE_URL" backup-file.dump
```

Then copy the uploads folder back. Sign in and check a known invoice before you let staff use it.

Never restore over the live database during a normal update.
