# Changelog

## 2026-03-22

- Reviewed the working functions twice.
- Fixed expense posting, advance payments, receipt cancellation, refunds, and supplier lists.
- Rewrote the README so a person or an AI agent can deploy the project from the ZIP.

## 2026-03-21

- First working version of AIO Desk.
- Added company workspaces, roles, customers, sales, operational accounting, visa, travel, education, tourism, shop, HR, office, reports, approvals, and backups.
- Seeded the owner’s business names as separate companies.
- Documented that GitHub and Vercel are not connected from this computer.
