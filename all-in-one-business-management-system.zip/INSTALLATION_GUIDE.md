# Windows ZIP guide

This ZIP is the source code. It is not the daily website, and it is not a desktop `.exe`.

## Difference

- **Daily work:** open the live website in a browser and sign in.
- **ZIP:** a copy of the program for backup, a developer, or running it on your own computer.
- **Deploy:** putting that program on the internet so staff can use it from home.

## Extract the ZIP

1. Download `BUSINESS-MANAGEMENT-SYSTEM.zip`.
2. Open the **Downloads** folder.
3. Right-click the ZIP file.
4. Choose **Extract All**.
5. Choose a folder such as `Documents\AIO-Desk`.
6. Click **Extract**.
7. Open the new folder. You should see `package.json` and a `src` folder.

## What must be installed first

- Node.js 22 from https://nodejs.org (the LTS installer).
- PostgreSQL 15 or newer, with a database named `app_db`.

If a developer is doing this for you, give them this folder and do not give them your real customer files until the empty system is running.

## Run it on your computer

1. Copy `.env.example` to a new file named `.env`.
2. In `.env`, set `DATABASE_URL` to your PostgreSQL address. Do not put that file in email or GitHub.
3. Open **Command Prompt** in the project folder.
4. Run:

```bat
npm install
npx drizzle-kit push
npx tsx src/db/seed.ts
npm run build
npm run start
```

5. Open `http://localhost:3000`.
6. Sign in with the starter owner account, then change the password.

To stop it, click the Command Prompt window and press `Ctrl+C`.

## Update later

1. Keep a backup first.
2. Replace the program files, but do not replace your `.env` or `storage` folder.
3. Run `npm install`, `npx drizzle-kit push`, and `npm run build` again.
4. Start the site. Existing records should remain.

There is also `setup-windows.bat` for the install commands. It does not know your database password, so `.env` must exist first.
