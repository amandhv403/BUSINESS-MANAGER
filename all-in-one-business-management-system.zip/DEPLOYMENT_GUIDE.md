# Deployment guide

The live website is not on the public internet yet.

This computer does not have a GitHub login or a Vercel login. I cannot invent those accounts or claim the site is deployed.

## What you need to do

1. Create a free GitHub account if you do not have one: https://github.com
2. Create a new private repository, for example `aio-desk`.
3. Ask a trusted developer, or use GitHub Desktop, to upload this project folder. Do not upload `.env`.
4. Create a Vercel account: https://vercel.com
5. In Vercel, choose **Add New Project** and import the GitHub repository.
6. Add a hosted PostgreSQL database. Vercel Postgres, Neon, or Supabase are suitable. Copy its connection string.
7. In Vercel project settings, add an environment variable named `DATABASE_URL` with that connection string. Do not paste it into the website code.
8. Deploy.
9. After the first deploy, run the database setup from a trusted computer:

```bash
npx drizzle-kit push
npx tsx src/db/seed.ts
```

10. Open the Vercel website address, sign in, and change the starter password immediately.

## After every update

1. Take a backup first.
2. Update the code.
3. Test it.
4. Upload the code to GitHub.
5. Vercel will deploy from GitHub.
6. Open the live site and sign in to confirm it still works.

Do not run a restore against the live database unless you intend to replace live records.

## File storage

Uploaded passport scans are stored in the `storage/uploads` folder on the server. A plain Vercel deployment does not keep those files forever. Before real passport uploads, connect a private file store such as S3 or Cloudflare R2 and keep the keys only in server environment variables. Until then, treat uploads as suitable for a single server you control.
