# AIO Desk — All-in-One Business Management System

One website for many companies. It is not a Windows program and not a collection of separate apps.

Use this file if you are a person or an AI agent deploying the project. Follow the commands in order. Do not skip the database step.

## What a normal user does

1. Open the website in a browser.
2. Sign in.
3. Choose one company at the top.
4. Add customers, invoices, visa files, staff, and the other records.

## Fresh install login

These accounts are created only by the seed script, and only when the database has no users yet.

| Person | Email | Password |
| --- | --- | --- |
| Owner | `owner@aiodesk.local` | `Owner#2026` |
| Visa officer | `visa@aiodesk.local` | `Staff#2026` |
| Accounts | `accounts@aiodesk.local` | `Staff#2026` |
| HR | `hr@aiodesk.local` | `Staff#2026` |
| Sales | `sales@aiodesk.local` | `Staff#2026` |
| Auditor | `auditor@aiodesk.local` | `Staff#2026` |

Change these passwords in **Settings** before real customer data is added.

## Requirements

- Node.js 22 or newer
- npm
- PostgreSQL 15 or newer
- A database the app can connect to

## Deploy on one computer

From the project folder:

```bash
npm install
cp .env.example .env
```

Edit `.env` and set `DATABASE_URL` to the real PostgreSQL address. Example:

```text
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/app_db
```

Then:

```bash
npx drizzle-kit push
npx tsx src/db/seed.ts
npm run build
npm run start
```

Open `http://localhost:3000`.

Check the site is alive:

```bash
curl http://localhost:3000/api/health
```

A healthy response is `{"ok":true}`.

Stop the site with `Ctrl+C` in the terminal that started it.

Windows users can also read `INSTALLATION_GUIDE.md` and run `setup-windows.bat` after `.env` exists.

## Deploy for an AI agent

Do all of the following. Do not ask the owner to edit source code.

1. Confirm Node.js and PostgreSQL are installed.
2. Create the database if it does not exist.
3. Copy `.env.example` to `.env` if `.env` is missing.
4. Set `DATABASE_URL`. Never commit `.env`.
5. Run `npm install`.
6. Run `npx drizzle-kit push`. This creates the tables from `src/db/schema.ts`. The config file `drizzle.config.ts` reads `DATABASE_URL`.
7. Run `npx tsx src/db/seed.ts`. If users already exist, it skips. It does not wipe an existing database.
8. Run `npm run build`.
9. Run `npm run start`.
10. Request `GET /api/health` and confirm `{"ok":true}`.
11. Sign in as `owner@aiodesk.local` / `Owner#2026` and confirm the dashboard loads.
12. Tell the owner to change the starter password.

Do not put the database password in frontend code, GitHub, or this README.

## Environment variables

| Name | Required | Purpose |
| --- | --- | --- |
| `DATABASE_URL` | Yes | PostgreSQL connection string |
| `SESSION_SECRET` | No | Reserved for later. Sessions already use random database tokens. |

Only `NEXT_PUBLIC_` variables are visible in the browser. This app does not need any public secret.

## What is included and working

- Sign-in, sign-out, password change, reset codes, optional authenticator code
- Separate company workspaces and role permissions, enforced on the server
- Customers, leads, lead conversion, CSV import
- Sales deals, quotations, quotation to invoice
- Invoices, partial payments, advances, refunds, expenses, cash, bank, transfers
- Receipt and invoice cancellation with a reason. Cancelled numbers are not reused.
- Balanced journal entries
- Visa files, passport records, private uploads, status history
- Travel, education, tourism, bookings, shop sales, stock, returns to stock, buying
- Employees, attendance, leave, payroll visibility limits
- Approvals, notifications, reports, audit log, owner backup

## What is not included

Do not claim these are finished:

- A public GitHub or Vercel website. Those need the owner's accounts.
- Email, WhatsApp, SMS, Facebook, or Instagram connections
- Airline, hotel, or card-payment connections
- A full statutory accounting package, tax return, or bank reconciliation
- Automatic nightly backup. Manual backup works. See `BACKUP_RESTORE_GUIDE.md`.
- Permanent cloud storage for passport scans. Uploads stay in `storage/uploads` on the server that is running the app.

## Other guides

- `USER_GUIDE.md` — everyday use
- `ADMIN_GUIDE.md` — owner setup
- `INSTALLATION_GUIDE.md` — Windows ZIP steps
- `DEPLOYMENT_GUIDE.md` — internet hosting
- `DATABASE_SETUP_GUIDE.md`
- `DATABASE_SCHEMA.md`
- `BACKUP_RESTORE_GUIDE.md`
- `PROJECT_ARCHITECTURE.md`
- `SECURITY_NOTES.md`
- `DEVELOPMENT_STATUS.md`
- `TESTING_REPORT.md`
- `CHANGELOG.md`

## Safe update

1. Take a backup first.
2. Keep the existing `.env` and `storage` folder.
3. Replace the program files.
4. Run `npm install`, `npx drizzle-kit push`, and `npm run build`.
5. Start the site again and sign in. Existing records should remain.
