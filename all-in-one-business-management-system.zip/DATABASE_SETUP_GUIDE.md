# Database setup

The application uses PostgreSQL. The tables are described in `src/db/schema.ts` and applied with Drizzle.

## Local database

1. Install PostgreSQL.
2. Create a database named `app_db`.
3. Put this in `.env`, using your real password:

```text
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@127.0.0.1:5432/app_db
```

4. From the project folder, run:

```bash
npx drizzle-kit push
npx tsx src/db/seed.ts
```

`drizzle-kit push` creates or updates tables. The seed adds starter companies and sign-ins only when the user list is empty, so it will not wipe an existing database.

## Money safety

Amounts are stored in paisa, which are hundredths of a taka, so 1.50 taka cannot be rounded badly by floating-point maths.

Confirmed invoices, receipts, and journal lines are not deleted in normal use. Cancellations add a reversing entry and keep the original number.

## Company separation

Almost every business record has a company number. The server only returns rows for companies the signed-in person may open. Filtering in the browser is not the security control.
