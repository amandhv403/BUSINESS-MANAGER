# Development status

Updated after a second full review of AIO Desk.

## Completed and working in this installation

- Sign-in, sign-out, password change, and one-time reset codes.
- Optional authenticator setup.
- 11 starter companies with separate colours, prefixes, and modules.
- Roles for owner, visa, accounts, HR, sales, auditor, and the other named roles.
- Server-side permission and company checks.
- Customers, leads, conversion, and CSV import.
- Sales deals, quotations, and quotation-to-invoice.
- Invoices, partial payments, advances, refunds, expenses, transfers, and supplier payments.
- Receipt and invoice cancellation with reasons, without reusing numbers.
- Journal entries that must balance.
- Visa files, passport records, private document upload, and status history.
- Travel, education, tourism, bookings, shop sales, stock, buying, office tasks, support, targets, and documents through working forms.
- Attendance, leave approval, payroll visibility limits, and My desk.
- Reports from database records.
- Audit log, notifications, approvals inbox.
- Owner backup that is marked successful only after the file is checked.
- Print views and a simple PDF download.
- Sample data so the screens are not empty. Figures are labelled as starter examples.

## Checked in the database

- 11 companies exist.
- Sample invoice `DH-INV-0001` is partial: total 20,000 taka, paid 8,000 taka, due 12,000 taka.
- Service income and third-party money are stored separately.
- Journal debits equal journal credits.

## Not done

- GitHub upload. This computer has no GitHub login.
- Vercel deployment. This computer has no Vercel login.
- Email, WhatsApp, and SMS sending.
- Live Facebook or Instagram connections.
- Airline, hotel, or payment-gateway connections.
- A full statutory general ledger, tax return, or bank reconciliation screen.
- Automatic nightly backup. The manual backup works. A schedule must be set on your computer or server.
- Permanent cloud file storage for passport scans.
- An independent security audit.

## Next steps for the owner

1. Change starter passwords.
2. Replace sample customers with real ones when you are ready.
3. Create a private GitHub repository and a Vercel project if you want the site on the internet. The exact clicks are in `DEPLOYMENT_GUIDE.md`.
4. Tell me which company should go live first if you want the next round of work focused there.
