import Link from "next/link";
import { archiveRecordAction, saveRecordAction } from "@/server/actions";
import { SubmitButton } from "@/components/widgets";
import type { EntityDef, FieldDef } from "@/lib/registry";
import { formatBdt, formatDate, formatDateTime, qs } from "@/lib/utils";
import type { SearchParams } from "@/lib/types";

export function Notice({ notice, error }: { notice?: string; error?: string }) {
  if (notice) return <div className="notice">{notice}</div>;
  if (error) return <div className="notice notice-bad">{error}</div>;
  return null;
}

export function Frame({ kicker = "AIO Desk", title, lede, actions, children }: { kicker?: string; title: string; lede?: string; actions?: React.ReactNode; children: React.ReactNode }) {
  return (
    <section>
      <div className="page-head">
        <div>
          <p className="kicker">{kicker}</p>
          <h1>{title}</h1>
          {lede ? <p className="lede">{lede}</p> : null}
        </div>
        <div>{actions}</div>
      </div>
      {children}
    </section>
  );
}

export function Denied({ what = "this page" }: { what?: string }) {
  return <div className="card"><h2>You cannot open {what}</h2><p>Ask the owner if your role should include it. The server checks permission, so hiding a menu is not the only protection.</p></div>;
}

export function Off({ name }: { name: string }) {
  return <div className="card"><h2>{name} is turned off for this company</h2><p>Open Companies and turn the module on if this business should use it.</p></div>;
}

export function Badge({ value }: { value: unknown }) {
  const text = String(value ?? "—");
  const tone = /paid|approved|won|active|verified|delivered|done|recorded/.test(text)
    ? "ok"
    : /pending|partial|wait|draft|open|new/.test(text)
      ? "wait"
      : /cancel|refus|lost|reject|overdue/.test(text)
        ? "bad"
        : "info";
  return <span className={`badge badge-${tone}`}>{text.replaceAll("_", " ")}</span>;
}

export function show(value: unknown, format?: string) {
  if (value == null || value === "") return "—";
  if (format === "money") return formatBdt(Number(value));
  if (format === "date") return formatDate(String(value));
  if (format === "datetime") return formatDateTime(value as string);
  if (format === "status") return <Badge value={value} />;
  if (typeof value === "boolean") return value ? "Yes" : "No";
  return String(value);
}

export function Pager({ page, total, sp, path }: { page: number; total: number; sp: SearchParams; path: string }) {
  const pages = Math.max(1, Math.ceil(total / 15));
  return (
    <div className="pager">
      <span className="muted">{total} records</span>
      {page > 1 ? <Link className="btn-ghost" href={`${path}${qs(sp, { page: String(page - 1) })}`}>Previous</Link> : null}
      {page < pages ? <Link className="btn-ghost" href={`${path}${qs(sp, { page: String(page + 1) })}`}>Next</Link> : null}
    </div>
  );
}

function Field({ field, choices }: { field: FieldDef; choices?: { id: number; label: string }[] }) {
  const wide = field.kind === "long";
  if (choices?.length) {
    return (
      <label className="field">
        <span>{field.label}{field.required ? " *" : ""}</span>
        <select name={field.key} required={field.required} defaultValue="">
          <option value="">{field.required ? "Choose" : "None"}</option>
          {choices.map((choice) => <option key={choice.id} value={choice.id}>{choice.label}</option>)}
        </select>
        {field.help ? <small>{field.help}</small> : null}
      </label>
    );
  }
  return (
    <label className={wide ? "field full" : "field"}>
      <span>{field.label}{field.required ? " *" : ""}</span>
      {field.kind === "long" ? <textarea name={field.key} rows={4} required={field.required} /> : null}
      {field.kind === "select" ? (
        <select name={field.key} required={field.required} defaultValue={field.options?.[0]}>
          {field.options?.map((option) => <option key={option}>{option}</option>)}
        </select>
      ) : null}
      {field.kind === "bool" ? <input name={field.key} type="checkbox" defaultChecked /> : null}
      {!["long", "select", "bool"].includes(field.kind) ? (
        <input name={field.key} required={field.required} type={field.kind === "date" ? "date" : field.kind === "datetime" ? "datetime-local" : field.kind === "int" || field.kind === "money" ? "number" : field.kind === "time" ? "time" : "text"} step={field.kind === "money" ? "0.01" : undefined} />
      ) : null}
      {field.help ? <small>{field.help}</small> : null}
    </label>
  );
}

export function EntityForm({ def, back, choices }: { def: EntityDef; back: string; choices?: Record<string, { id: number; label: string }[]> }) {
  return (
    <form className="card" action={saveRecordAction}>
      <h2>Add {def.title.toLowerCase()}</h2>
      <input type="hidden" name="entity" value={def.key} />
      <input type="hidden" name="back" value={back} />
      <div className="fields">
        {def.fields.map((field) => <Field key={field.key} field={field} choices={choices?.[field.key]} />)}
      </div>
      <div style={{ marginTop: 12 }}><SubmitButton>Save</SubmitButton></div>
    </form>
  );
}

export function ArchiveForm({ entity, id, back }: { entity: string; id: number; back: string }) {
  return (
    <form action={archiveRecordAction}>
      <input type="hidden" name="entity" value={entity} />
      <input type="hidden" name="id" value={id} />
      <input type="hidden" name="back" value={back} />
      <button className="btn-ghost" type="submit">Archive</button>
    </form>
  );
}

export function Tabs({ items, current }: { items: { href: string; label: string }[]; current: string }) {
  return (
    <div className="tabs">
      {items.map((item) => <Link key={item.href} href={item.href} className={current === item.href ? "on" : ""}>{item.label}</Link>)}
    </div>
  );
}
