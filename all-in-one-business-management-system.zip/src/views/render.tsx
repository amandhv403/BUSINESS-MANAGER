import Link from "next/link";
import { notFound } from "next/navigation";
import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { accountTransactions, companies, documents, expenses, leaveRequests, moneyAccounts, notifications, opportunities, payslips, purchaseOrders, quotations, visaApplications } from "@/db/schema";
import { LineItems, ShopLines, SubmitButton, ConfirmButton } from "@/components/widgets";
import { getContext, moduleEnabled } from "@/lib/context";
import { NAV, MODULES, BUSINESS_TYPES, VISA_STATUSES, PAYMENT_METHODS, PIPELINE } from "@/lib/constants";
import { ENTITIES } from "@/lib/registry";
import { customerFile, dashboardData, invoiceFile, listCustomers, listEntity, listInvoices, lookups, myDesk, pendingApprovals, privateRows, reportData, searchAll, settingsData, visaFile, auditRows } from "@/lib/queries";
import type { SearchParams } from "@/lib/types";
import { formatBdt, formatDate, maskPassport, pageOf, spOne, todayDhaka } from "@/lib/utils";
import { ArchiveForm, Badge, Denied, EntityForm, Frame, Notice, Off, Pager, Tabs, show } from "./bits";
import {
  cancelInvoiceAction,
  cancelReceiptAction,
  convertLeadAction,
  convertQuotationAction,
  decideApprovalAction,
  importCustomersAction,
  markReadAction,
  recordPaymentAction,
  refundAction,
  saveAssessmentAction,
  saveAttendanceAction,
  saveCompanyAction,
  saveCustomerAction,
  saveEmployeeAction,
  saveExpenseAction,
  saveInvoiceAction,
  saveLeaveAction,
  saveOpportunityAction,
  savePassportAction,
  savePayslipAction,
  savePurchaseAction,
  saveQuotationAction,
  saveVisaAction,
  shopSaleAction,
  stockAction,
  toggleModuleAction,
  transferAction,
  uploadAction,
  verifyDocumentAction,
  visaStatusAction,
  paySupplierAction,
  receivePurchaseAction,
  returnStockAction,
  changePasswordAction,
  confirmTotpAction,
  toggleTotpAction,
  resetCodeAction,
  saveUserAction,
  saveRoleAction,
  moveStageAction,
} from "@/server/actions";

function gate(ctx: Awaited<ReturnType<typeof getContext>>, module: string, action = "view") {
  if (module !== "dashboard" && !ctx.can(module, action) && module !== "settings") return "denied" as const;
  if (ctx.company && !moduleEnabled(ctx, module) && !["dashboard", "settings", "companies", "audit"].includes(module)) return "off" as const;
  return "ok" as const;
}

export async function renderRoute(slug: string[], sp: SearchParams) {
  const ctx = await getContext();
  const notice = spOne(sp, "notice");
  const error = spOne(sp, "error");
  const [section, id] = slug;
  const common = { ctx, notice, error, sp };
  if (section === "dashboard") return <Dashboard {...common} />;
  if (section === "crm" && id) return <CustomerPage {...common} id={Number(id)} />;
  if (section === "crm") return <CustomersPage {...common} />;
  if (section === "leads") return <Generic {...common} entity="lead" path="/leads" extra="convert" />;
  if (section === "sales") return <SalesPage {...common} />;
  if (section === "accounting" && id) return <InvoicePage {...common} id={Number(id)} />;
  if (section === "accounting") return <AccountingPage {...common} />;
  if (section === "expenses") return <ExpensesPage {...common} />;
  if (section === "cash") return <CashPage {...common} />;
  if (section === "visa" && id) return <VisaPage {...common} id={Number(id)} />;
  if (section === "visa") return <VisaList {...common} />;
  if (section === "shop") return <ShopPage {...common} />;
  if (section === "people" && id) return <EmployeePage {...common} id={Number(id)} />;
  if (section === "people") return <PeoplePage {...common} />;
  if (section === "attendance") return <AttendancePage {...common} />;
  if (section === "leave") return <LeavePage {...common} />;
  if (section === "payroll") return <PayrollPage {...common} />;
  if (section === "me") return <MePage {...common} />;
  if (section === "reports") return <ReportsPage {...common} />;
  if (section === "settings") return <SettingsPage {...common} />;
  if (section === "companies") return <CompaniesPage {...common} />;
  if (section === "approvals") return <ApprovalsPage {...common} />;
  if (section === "notifications") return <NotesPage {...common} />;
  if (section === "documents") return <DocumentsPage {...common} />;
  if (section === "help") return <HelpPage />;
  if (section === "search") return <SearchPage {...common} />;
  if (section === "data-entry") return <EntryPage {...common} />;
  if (section === "private") return <PrivatePage {...common} />;
  if (section === "audit") return <AuditPage {...common} />;
  if (section === "office") return <Tabbed {...common} base="/office" tabs={[["Tasks", "task"], ["Meetings", "meeting"], ["Notices", "announcement"], ["Visitors", "visitor"], ["Couriers", "courier"], ["Incidents", "incident"]]} current={id || "task"} />;
  if (section === "marketing") return <Tabbed {...common} base="/marketing" tabs={[["Campaigns", "campaign"], ["Content", "contentPost"]]} current={id || "campaign"} />;
  if (section === "travel") return <Tabbed {...common} base="/travel" tabs={[["Bookings", "travel"], ["Hotels", "hotel"]]} current={id || "travel"} />;
  if (section === "education") return <Tabbed {...common} base="/education" tabs={[["Students", "student"], ["Applications", "admission"], ["Universities", "university"]]} current={id || "student"} />;
  if (section === "tourism") return <Tabbed {...common} base="/tourism" tabs={[["Projects", "project"], ["Partners", "partner"]]} current={id || "project"} />;
  if (section === "bookings") return <Generic {...common} entity="booking" path="/bookings" />;
  if (section === "buying") return <BuyingPage {...common} />;
  if (section === "stock") return <StockPage {...common} />;
  if (section === "support") return <Generic {...common} entity="ticket" path="/support" />;
  if (section === "targets") return <Generic {...common} entity="target" path="/targets" />;
  if (section === "structure") return <Tabbed {...common} base="/structure" tabs={[["Branches", "branch"], ["Departments", "department"]]} current={id || "branch"} />;
  notFound();
}

function Dashboard({ ctx, notice, error }: { ctx: Awaited<ReturnType<typeof getContext>>; notice: string; error: string }) {
  return <DashboardInner ctx={ctx} notice={notice} error={error} />;
}

async function DashboardInner({ ctx, notice, error }: { ctx: Awaited<ReturnType<typeof getContext>>; notice: string; error: string }) {
  const data = await dashboardData(ctx);
  const max = Math.max(...data.comparison.map((row) => row.amount), 1);
  return (
    <Frame kicker="Today" title={ctx.allMode ? "Group desk" : ctx.company?.name || "Dashboard"} lede="Figures below come from records currently in the database. This is operational accounting, not a statutory audit report.">
      <Notice notice={notice} error={error} />
      {data.sampleCount ? <div className="notice">Starter examples are loaded so you can learn the screens. Replace them with your real customers before daily use, and change the starter passwords in Settings.</div> : null}
      {!data.lastBackup ? <div className="notice notice-bad">No verified backup has been saved yet. Open Settings and download a backup after you add real records.</div> : null}
      <div className="stats">
        <div className="stat"><span>Collected today</span><strong>{formatBdt(data.today)}</strong></div>
        <div className="stat"><span>Collected this month</span><strong>{formatBdt(data.monthIn)}</strong></div>
        <div className="stat"><span>Expenses this month</span><strong>{formatBdt(data.monthOut)}</strong></div>
        <div className="stat"><span>Still due from customers</span><strong>{formatBdt(data.outstanding)}</strong></div>
      </div>
      <div className="stats">
        <Link className="stat" href="/leads"><span>Open leads</span><strong>{data.leads}</strong></Link>
        <Link className="stat" href="/visa"><span>Visa files in progress</span><strong>{data.visas}</strong></Link>
        <Link className="stat" href="/office"><span>Tasks due</span><strong>{data.tasks}</strong></Link>
        <Link className="stat" href="/approvals"><span>Waiting for approval</span><strong>{data.approvals}</strong></Link>
      </div>
      <div className="split">
        <div className="card">
          <h2>Money by company this month</h2>
          <div className="bars">
            {data.comparison.length ? data.comparison.map((row) => {
              const company = ctx.companies.find((item) => item.id === row.companyId);
              return (
                <div className="bar" key={row.companyId}>
                  <span>{company?.shortName || row.companyId}</span>
                  <i><b style={{ width: `${Math.max(6, (row.amount / max) * 100)}%` }} /></i>
                  <strong>{formatBdt(row.amount)}</strong>
                </div>
              );
            }) : <p>No collections yet.</p>}
          </div>
          <p className="muted">Cash and bank now: {data.cash.map((row) => `${row.type} ${formatBdt(row.amount)}`).join(" · ") || "No accounts"}</p>
        </div>
        <div className="card">
          <h2>Needs attention</h2>
          {data.followDue.map((row) => <p key={row.id}>Follow up by {formatDate(row.dueOn)} — {row.notes}</p>)}
          {data.expiring.map((row) => <p key={row.id}>Passport {maskPassport(row.passportNo)} expires {formatDate(row.expiryDate)}</p>)}
          {data.lowStock ? <p>{data.lowStock} product(s) are at or below the reorder level.</p> : null}
          {!data.followDue.length && !data.expiring.length && !data.lowStock ? <p>Nothing urgent in the reminder list.</p> : null}
        </div>
      </div>
    </Frame>
  );
}

async function CustomersPage({ ctx, notice, error, sp }: PageProps) {
  if (gate(ctx, "crm") === "denied") return <Denied what="customers" />;
  if (gate(ctx, "crm") === "off") return <Off name="Customers" />;
  const page = pageOf(sp);
  const q = spOne(sp, "q");
  const data = await listCustomers(ctx, q, spOne(sp, "status"), page);
  const look = await lookups(ctx);
  return (
    <Frame title="Customers" lede="One person should be entered once. Link invoices, visa files, and bookings to that record.">
      <Notice notice={notice} error={error} />
      <div className="split">
        <div>
          <form className="fields" action="/crm">
            <label className="field">Search<input name="q" defaultValue={q} placeholder="Name, phone, or code" /></label>
            <button className="btn" type="submit">Find</button>
          </form>
          <div className="table-wrap">
            <table className="data">
              <thead><tr><th>Code</th><th>Name</th><th>Phone</th><th>Source</th><th>Status</th><th>Advance held</th></tr></thead>
              <tbody>
                {data.rows.map((row) => (
                  <tr key={row.id}>
                    <td><Link href={`/crm/${row.id}`}>{row.customerCode}</Link></td>
                    <td>{row.name}</td>
                    <td>{row.phone}</td>
                    <td>{row.source}</td>
                    <td><Badge value={row.status} /></td>
                    <td>{formatBdt(row.creditPaisa)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!data.rows.length ? <div className="empty">No customers yet.</div> : null}
          </div>
          <Pager page={page} total={data.total} sp={sp} path="/crm" />
          {ctx.can("crm", "create") ? (
            <form className="card" action={importCustomersAction} style={{ marginTop: 12 }}>
              <h2>Import from CSV</h2>
              <p className="muted">Columns: name, phone, email, address, source, category. Save an Excel file as CSV first.</p>
              <input name="file" type="file" accept=".csv,text/csv" required />
              <div style={{ marginTop: 8 }}><SubmitButton>Import</SubmitButton></div>
            </form>
          ) : null}
        </div>
        {ctx.can("crm", "create") && ctx.company ? (
          <form className="card" action={saveCustomerAction}>
            <h2>Add customer</h2>
            <div className="fields">
              <label className="field full">Name *<input name="name" required /></label>
              <label className="field">Phone<input name="phone" /></label>
              <label className="field">Email<input name="email" type="email" /></label>
              <label className="field">Source<select name="source"><option value="">Choose</option>{["Facebook","Instagram","WhatsApp","Website","Phone call","Walk-in","Referral","Existing customer","Other"].map((s) => <option key={s}>{s}</option>)}</select></label>
              <label className="field">Category<input name="category" placeholder="Family, student, corporate" /></label>
              <label className="field full">Address<textarea name="address" rows={2} /></label>
              <label className="field">Assigned user
                <select name="assignedUserId"><option value="">Unassigned</option>{look.users.map((u) => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
              </label>
              <label className="field full">Notes<textarea name="notes" rows={3} /></label>
              <label className="field full"><input name="allowDuplicate" type="checkbox" /> Save anyway if the phone already exists</label>
            </div>
            <SubmitButton>Save customer</SubmitButton>
          </form>
        ) : <div className="card">Choose one company before adding a customer.</div>}
      </div>
    </Frame>
  );
}

async function CustomerPage({ ctx, id, notice, error }: PageProps & { id: number }) {
  const file = await customerFile(ctx, id);
  if (!file) notFound();
  return (
    <Frame kicker={file.customer.customerCode} title={file.customer.name} lede={`${file.customer.phone || "No phone"} · ${file.customer.email || "No email"} · ${file.customer.source || "No source"}`}>
      <Notice notice={notice} error={error} />
      <div className="stats">
        <div className="stat"><span>Still due</span><strong>{formatBdt(file.due)}</strong></div>
        <div className="stat"><span>Advance we hold</span><strong>{formatBdt(file.customer.creditPaisa)}</strong></div>
        <div className="stat"><span>Visa files</span><strong>{file.visas.length}</strong></div>
        <div className="stat"><span>Status</span><strong style={{ fontSize: "1.2rem" }}>{file.customer.status}</strong></div>
      </div>
      <div className="split">
        <div className="card">
          <h2>History</h2>
          <div className="timeline">
            {file.timeline.map((item) => <article key={item.id}><strong>{item.summary}</strong><div className="muted">{formatDate(String(item.happenedAt))} · {item.activityType}</div><p>{item.body}</p></article>)}
            {file.bills.map((bill) => <article key={`i${bill.id}`}><Link href={`/accounting/${bill.id}`}>{bill.number}</Link> · {formatBdt(bill.totalPaisa)} · <Badge value={bill.status} /></article>)}
            {!file.timeline.length && !file.bills.length ? <p>No history yet.</p> : null}
          </div>
        </div>
        <div className="card">
          <h2>Open work</h2>
          {file.visas.map((visa) => <p key={visa.id}><Link href={`/visa/${visa.id}`}>{visa.applicationCode}</Link> · <Badge value={visa.status} /></p>)}
          {file.follows.map((row) => <p key={row.id}>Follow up {formatDate(row.dueOn)} · {row.notes}</p>)}
          {file.tickets.map((row) => <p key={row.id}>{row.number}: {row.subject}</p>)}
          <p className="muted">{file.customer.address}</p>
          <p className="muted">{file.customer.notes}</p>
        </div>
      </div>
    </Frame>
  );
}

async function SalesPage({ ctx, notice, error }: PageProps) {
  if (gate(ctx, "sales") === "denied") return <Denied what="sales" />;
  if (gate(ctx, "sales") === "off") return <Off name="Sales" />;
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const [deals, quotes, look] = await Promise.all([
    db.select().from(opportunities).where(inArray(opportunities.companyId, ids)).orderBy(desc(opportunities.id)).limit(30),
    db.select().from(quotations).where(inArray(quotations.companyId, ids)).orderBy(desc(quotations.id)).limit(15),
    lookups(ctx),
  ]);
  return (
    <Frame title="Sales" lede="Move a deal from new lead to won or lost. A quotation can become an invoice without retyping the lines.">
      <Notice notice={notice} error={error} />
      <div className="tabs">{PIPELINE.map((stage) => <span key={stage} className="badge">{stage} {deals.filter((d) => d.stage === stage).length}</span>)}</div>
      <div className="split">
        <div className="table-wrap">
          <table className="data">
            <thead><tr><th>Deal</th><th>Stage</th><th>Value</th><th></th></tr></thead>
            <tbody>
              {deals.map((deal) => (
                <tr key={deal.id}>
                  <td>{deal.title}</td>
                  <td><Badge value={deal.stage} /></td>
                  <td>{formatBdt(deal.valuePaisa)}</td>
                  <td>
                    <form action={moveStageAction} className="fields">
                      <input type="hidden" name="id" value={deal.id} />
                      <select name="stage" defaultValue={deal.stage}>{PIPELINE.map((stage) => <option key={stage}>{stage}</option>)}</select>
                      <input name="lostReason" placeholder="Lost reason, if lost" />
                      <SubmitButton>Update</SubmitButton>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div>
          {ctx.company ? (
            <form className="card" action={saveOpportunityAction}>
              <h2>New deal</h2>
              <div className="fields">
                <label className="field full">Deal name *<input name="title" required /></label>
                <label className="field">Customer<select name="customerId"><option value="">None yet</option>{look.customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
                <label className="field">Expected value (taka)<input name="value" type="number" step="0.01" /></label>
                <label className="field">Stage<select name="stage">{PIPELINE.map((stage) => <option key={stage}>{stage}</option>)}</select></label>
                <label className="field">Expected close<input name="expectedClose" type="date" /></label>
                <label className="field full">Notes<textarea name="notes" rows={2} /></label>
              </div>
              <SubmitButton>Save deal</SubmitButton>
            </form>
          ) : null}
          <form className="card" action={saveQuotationAction}>
            <h2>Quotation</h2>
            <div className="fields">
              <label className="field">Customer<select name="customerId" required><option value="">Choose</option>{look.customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
              <label className="field">Date<input name="issueDate" type="date" defaultValue={todayDhaka()} /></label>
              <label className="field">Discount (taka)<input name="discount" type="number" step="0.01" defaultValue="0" /></label>
              <LineItems />
            </div>
            <SubmitButton>Save quotation</SubmitButton>
          </form>
          {quotes.map((quote) => (
            <form key={quote.id} action={convertQuotationAction} className="card">
              <input type="hidden" name="id" value={quote.id} />
              <strong>{quote.number}</strong> · {formatBdt(quote.totalPaisa)} · <Badge value={quote.status} />
              <div style={{ marginTop: 8 }}><SubmitButton>Create invoice</SubmitButton></div>
            </form>
          ))}
        </div>
      </div>
    </Frame>
  );
}

async function AccountingPage({ ctx, notice, error, sp }: PageProps) {
  if (gate(ctx, "accounting") === "denied") return <Denied what="invoices" />;
  if (gate(ctx, "accounting") === "off") return <Off name="Money" />;
  const page = pageOf(sp);
  const data = await listInvoices(ctx, spOne(sp, "q"), page);
  const look = await lookups(ctx);
  const names = new Map(look.customers.map((c) => [c.id, c.name]));
  return (
    <Frame title="Invoices and receipts" lede="Service fees, product sales, and third-party money are kept apart. Cancelled numbers are never reused.">
      <Notice notice={notice} error={error} />
      <div className="split">
        <div>
          <div className="table-wrap">
            <table className="data">
              <thead><tr><th>Invoice</th><th>Customer</th><th>Total</th><th>Due</th><th>Status</th></tr></thead>
              <tbody>
                {data.rows.map((row) => (
                  <tr key={row.id}>
                    <td><Link href={`/accounting/${row.id}`}>{row.number}</Link></td>
                    <td>{names.get(row.customerId) || row.customerId}</td>
                    <td>{formatBdt(row.totalPaisa)}</td>
                    <td>{formatBdt(row.duePaisa)}</td>
                    <td><Badge value={row.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <Pager page={page} total={data.total} sp={sp} path="/accounting" />
        </div>
        {ctx.company ? (
          <form className="card" action={saveInvoiceAction}>
            <h2>New invoice</h2>
            <div className="fields">
              <label className="field">Customer<select name="customerId" required><option value="">Choose</option>{look.customers.map((c) => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}</select></label>
              <label className="field">Date<input type="date" name="issueDate" defaultValue={todayDhaka()} required /></label>
              <label className="field">Due<input type="date" name="dueDate" /></label>
              <label className="field">Discount in taka<input name="discount" type="number" step="0.01" defaultValue="0" /></label>
              <LineItems />
              <label className="field full">Notes<textarea name="notes" rows={2} /></label>
              <label className="field full"><input type="checkbox" name="issueNow" defaultChecked /> Issue now and update the books</label>
            </div>
            <p className="muted">Tax, if set on the company, is added to service and product lines only. A discount above 10% waits for approval unless you can approve money.</p>
            <SubmitButton>Save invoice</SubmitButton>
          </form>
        ) : <div className="card">Choose one company before creating an invoice.</div>}
      </div>
    </Frame>
  );
}

async function InvoicePage({ ctx, id, notice, error }: PageProps & { id: number }) {
  const file = await invoiceFile(ctx, id);
  if (!file) notFound();
  const look = await lookups(ctx);
  const { invoice, items, customer, company } = file;
  return (
    <Frame kicker={company?.name} title={invoice.number} lede={`${customer?.name || "Customer"} · ${formatDate(invoice.issueDate)}`}>
      <Notice notice={notice} error={error} />
      <div className="page-head">
        <Badge value={invoice.status} />
        <div style={{ display: "flex", gap: 8 }}>
          <Link className="btn-ghost" href={`/print/invoice/${invoice.id}`}>Print or save PDF</Link>
          <a className="btn-ghost" href={`/api/pdf/invoice/${invoice.id}`}>Download PDF</a>
        </div>
      </div>
      <div className="split">
        <div className="card">
          <table className="data">
            <thead><tr><th>Description</th><th>Type</th><th>Qty</th><th>Amount</th></tr></thead>
            <tbody>
              {items.map((item) => <tr key={item.id}><td>{item.description}</td><td>{item.kind === "third_party" ? "Third-party" : item.kind}</td><td>{item.qty}</td><td>{formatBdt(item.lineTotalPaisa)}</td></tr>)}
            </tbody>
          </table>
          <p>Our service income: {formatBdt(invoice.servicePaisa)}</p>
          <p>Product income: {formatBdt(invoice.productPaisa)}</p>
          <p>Third-party money held: {formatBdt(invoice.thirdPartyPaisa)}</p>
          <p>Tax: {formatBdt(invoice.taxPaisa)} · Discount: {formatBdt(invoice.discountPaisa)}</p>
          <h2>Total {formatBdt(invoice.totalPaisa)} · Due {formatBdt(invoice.duePaisa)}</h2>
          {invoice.cancelReason ? <p>Cancelled: {invoice.cancelReason}</p> : null}
        </div>
        <div>
          {invoice.status !== "cancelled" && invoice.duePaisa > 0 && ctx.company ? (
            <form className="card" action={recordPaymentAction}>
              <h2>Record payment</h2>
              <input type="hidden" name="back" value={`/accounting/${invoice.id}`} />
              <input type="hidden" name="customerId" value={invoice.customerId} />
              <input type="hidden" name="invoiceId" value={invoice.id} />
              <div className="fields">
                <label className="field">Amount in taka<input name="amount" type="number" step="0.01" required /></label>
                <label className="field">Date<input type="date" name="paidOn" defaultValue={todayDhaka()} /></label>
                <label className="field">Method<select name="method">{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}</select></label>
                <label className="field">Account<select name="accountId" required><option value="">Choose</option>{look.accounts.map((a) => <option key={a.id} value={a.id}>{a.name} · {formatBdt(a.currentPaisa)}</option>)}</select></label>
                <label className="field full">Bank or bKash reference<input name="reference" placeholder="Must be unique" /></label>
              </div>
              <SubmitButton>Save receipt</SubmitButton>
            </form>
          ) : null}
          {customer && customer.creditPaisa > 0 && invoice.duePaisa > 0 ? (
            <form className="card" action={recordPaymentAction}>
              <input type="hidden" name="back" value={`/accounting/${invoice.id}`} />
              <input type="hidden" name="fromCredit" value="on" />
              <input type="hidden" name="customerId" value={customer.id} />
              <input type="hidden" name="invoiceId" value={invoice.id} />
              <input type="hidden" name="method" value="advance" />
              <p>Advance available: {formatBdt(customer.creditPaisa)}</p>
              <label className="field">Use advance (taka)<input name="amount" type="number" step="0.01" required /></label>
              <SubmitButton>Apply advance</SubmitButton>
            </form>
          ) : null}
          {invoice.paidPaisa > 0 && invoice.status !== "cancelled" ? (
            <form className="card" action={refundAction}>
              <h2>Refund money</h2>
              <input type="hidden" name="back" value={`/accounting/${invoice.id}`} />
              <input type="hidden" name="customerId" value={invoice.customerId} />
              <input type="hidden" name="invoiceId" value={invoice.id} />
              <div className="fields">
                <label className="field">Amount in taka<input name="amount" type="number" step="0.01" required /></label>
                <label className="field">Pay from<select name="accountId" required>{look.accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
                <label className="field">Method<select name="method">{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}</select></label>
                <label className="field full">Reason<input name="notes" required /></label>
              </div>
              <ConfirmButton message="Refund this amount?">Record refund</ConfirmButton>
            </form>
          ) : null}
          {items.some((item) => item.productId) ? (
            <form className="card" action={returnStockAction}>
              <h2>Return an item to stock</h2>
              <input type="hidden" name="back" value={`/accounting/${invoice.id}`} />
              <input type="hidden" name="invoiceId" value={invoice.id} />
              <label className="field">Product<select name="productId">{items.filter((item) => item.productId).map((item) => <option key={item.id} value={item.productId || 0}>{item.description}</option>)}</select></label>
              <label className="field">Quantity<input name="qty" type="number" min={1} defaultValue={1} /></label>
              <label className="field">Reason<input name="reason" required /></label>
              <SubmitButton>Put back in stock</SubmitButton>
            </form>
          ) : null}
          {invoice.status !== "cancelled" && invoice.paidPaisa === 0 ? (
            <form className="card" action={cancelInvoiceAction}>
              <input type="hidden" name="id" value={invoice.id} />
              <input type="hidden" name="back" value={`/accounting/${invoice.id}`} />
              <label className="field">Reason to cancel<input name="reason" required /></label>
              <ConfirmButton message="Cancel this invoice? The number will not be used again.">Cancel invoice</ConfirmButton>
            </form>
          ) : null}
          <div className="card">
            <h3>Receipts</h3>
            {file.receipts.map((receipt) => (
              <div key={receipt.id} style={{ marginBottom: 10 }}>
                <p><Link href={`/print/receipt/${receipt.id}`}>{receipt.number}</Link> · {formatBdt(receipt.amountPaisa)} · <Badge value={receipt.status} /> · printed {receipt.printCount}</p>
                {receipt.status === "issued" ? (
                  <form action={cancelReceiptAction}>
                    <input type="hidden" name="id" value={receipt.id} />
                    <input type="hidden" name="back" value={`/accounting/${invoice.id}`} />
                    <label className="field">Reason to cancel this receipt<input name="reason" required /></label>
                    <ConfirmButton message="Cancel this receipt? The number will not be used again.">Cancel receipt</ConfirmButton>
                  </form>
                ) : null}
              </div>
            ))}
            {!file.receipts.length ? <p>No receipt yet.</p> : null}
          </div>
        </div>
      </div>
    </Frame>
  );
}

async function ExpensesPage({ ctx, notice, error }: PageProps) {
  if (gate(ctx, "accounting") !== "ok") return gate(ctx, "accounting") === "off" ? <Off name="Expenses" /> : <Denied what="expenses" />;
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const rows = await db.select().from(expenses).where(inArray(expenses.companyId, ids)).orderBy(desc(expenses.id)).limit(20);
  const look = await lookups(ctx);
  return (
    <Frame title="Expenses" lede="People who cannot approve money will send the expense for approval. It is not paid from the books until approved.">
      <Notice notice={notice} error={error} />
      <div className="split">
        <div className="table-wrap">
          <table className="data"><thead><tr><th>Date</th><th>Description</th><th>Amount</th><th>Status</th></tr></thead>
            <tbody>{rows.map((row) => <tr key={row.id}><td>{formatDate(row.spentOn)}</td><td>{row.description}</td><td>{formatBdt(row.amountPaisa)}</td><td><Badge value={row.status} /></td></tr>)}</tbody>
          </table>
        </div>
        {ctx.company ? (
          <form className="card" action={saveExpenseAction}>
            <h2>Record expense</h2>
            <div className="fields">
              <label className="field full">What was it for? *<input name="description" required /></label>
              <label className="field">Amount in taka *<input name="amount" type="number" step="0.01" required /></label>
              <label className="field">Date<input type="date" name="spentOn" defaultValue={todayDhaka()} /></label>
              <label className="field">Category<select name="categoryId"><option value="">Choose</option>{look.categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
              <label className="field">Paid from<select name="accountId" required><option value="">Choose</option>{look.accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
              <label className="field">Method<select name="method">{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}</select></label>
            </div>
            <SubmitButton>Save expense</SubmitButton>
          </form>
        ) : null}
      </div>
    </Frame>
  );
}

async function CashPage({ ctx, notice, error }: PageProps) {
  if (gate(ctx, "accounting") !== "ok") return <Denied what="cash and bank" />;
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const accounts = await db.select().from(moneyAccounts).where(inArray(moneyAccounts.companyId, ids));
  const txns = await db.select().from(accountTransactions).where(inArray(accountTransactions.companyId, ids)).orderBy(desc(accountTransactions.id)).limit(20);
  return (
    <Frame title="Cash and bank" lede="Each movement is kept. A transfer updates both accounts and the books.">
      <Notice notice={notice} error={error} />
      <div className="stats">{accounts.map((a) => <div className="stat" key={a.id}><span>{a.name}</span><strong>{formatBdt(a.currentPaisa)}</strong><small>{a.accountType}</small></div>)}</div>
      {ctx.company ? (
        <form className="card" action={transferAction}>
          <h2>Transfer</h2>
          <div className="fields">
            <label className="field">From<select name="fromId">{accounts.filter((a) => !ctx.company || a.companyId === ctx.company.id).map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
            <label className="field">To<select name="toId">{accounts.filter((a) => !ctx.company || a.companyId === ctx.company.id).map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
            <label className="field">Amount<input name="amount" type="number" step="0.01" required /></label>
            <label className="field">Date<input type="date" name="date" defaultValue={todayDhaka()} /></label>
            <label className="field full">Note<input name="notes" /></label>
          </div>
          <SubmitButton>Transfer</SubmitButton>
        </form>
      ) : null}
      <div className="table-wrap">
        <table className="data"><thead><tr><th>Date</th><th>Account</th><th>Direction</th><th>Amount</th><th>Description</th></tr></thead>
          <tbody>{txns.map((row) => <tr key={row.id}><td>{formatDate(row.txnDate)}</td><td>{accounts.find((a) => a.id === row.accountId)?.name}</td><td>{row.direction}</td><td>{formatBdt(row.amountPaisa)}</td><td>{row.description}</td></tr>)}</tbody>
        </table>
      </div>
    </Frame>
  );
}

async function VisaList({ ctx, notice, error }: PageProps) {
  if (gate(ctx, "visa") === "denied") return <Denied what="visa files" />;
  if (gate(ctx, "visa") === "off") return <Off name="Visa" />;
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const [rows, look] = await Promise.all([
    db.select().from(visaApplications).where(inArray(visaApplications.companyId, ids)).orderBy(desc(visaApplications.id)).limit(30),
    lookups(ctx),
  ]);
  return (
    <Frame title="Visa files" lede="Passport scans stay private. Lists show only the last digits.">
      <Notice notice={notice} error={error} />
      <div className="split">
        <div className="table-wrap">
          <table className="data"><thead><tr><th>File</th><th>Status</th><th>Appointment</th></tr></thead>
            <tbody>{rows.map((row) => <tr key={row.id}><td><Link href={`/visa/${row.id}`}>{row.applicationCode}</Link></td><td><Badge value={row.status} /></td><td>{formatDate(row.appointmentDate)}</td></tr>)}</tbody>
          </table>
        </div>
        {ctx.company ? (
          <form className="card" action={saveVisaAction}>
            <h2>Open a file</h2>
            <div className="fields">
              <label className="field">Customer<select name="customerId" required><option value="">Choose</option>{look.customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
              <label className="field">Country<select name="countryId"><option value="">Choose</option>{look.countries.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
              <label className="field">Purpose<input name="purpose" placeholder="Tourism, study, work" /></label>
              <label className="field">Application date<input type="date" name="applicationDate" defaultValue={todayDhaka()} /></label>
              <label className="field">Travel start<input type="date" name="travelStart" /></label>
              <label className="field">Appointment<input type="date" name="appointmentDate" /></label>
              <label className="field full">Embassy<input name="embassy" /></label>
              <label className="field full">Notes<textarea name="notes" rows={3} /></label>
            </div>
            <SubmitButton>Open file</SubmitButton>
          </form>
        ) : null}
      </div>
    </Frame>
  );
}

async function VisaPage({ ctx, id, notice, error }: PageProps & { id: number }) {
  const file = await visaFile(ctx, id);
  if (!file) notFound();
  return (
    <Frame kicker="Visa file" title={file.app.applicationCode} lede={`${file.customer?.name || "Customer"} · ${file.app.purpose || "Purpose not set"}`}>
      <Notice notice={notice} error={error} />
      <div className="card">
        <h2>Status: {file.app.status}</h2>
        <div className="tabs">{VISA_STATUSES.map((status) => <span key={status} className={status === file.app.status ? "badge badge-info" : "badge"}>{status}</span>)}</div>
        <form action={visaStatusAction} className="fields">
          <input type="hidden" name="id" value={file.app.id} />
          <label className="field">New status<select name="status" defaultValue={file.app.status}>{VISA_STATUSES.map((s) => <option key={s}>{s}</option>)}</select></label>
          <label className="field">Note<input name="note" placeholder="Required if refused" /></label>
          <SubmitButton>Update status</SubmitButton>
        </form>
        <div className="timeline">{file.history.map((row) => <article key={row.id}><strong>{row.toStatus}</strong><div className="muted">{formatDate(String(row.createdAt))}</div><p>{row.note}</p></article>)}</div>
      </div>
      <div className="split">
        <form className="card" action={savePassportAction}>
          <h2>Passport</h2>
          {file.passport ? <p>On file: {maskPassport(file.passport.passportNo)} · expires {formatDate(file.passport.expiryDate)}</p> : <p>No passport record yet.</p>}
          <input type="hidden" name="back" value={`/visa/${file.app.id}`} />
          <input type="hidden" name="customerId" value={file.app.customerId} />
          <input type="hidden" name="applicationId" value={file.app.id} />
          <div className="fields">
            <label className="field">Passport number<input name="passportNo" required /></label>
            <label className="field">Nationality<input name="nationality" defaultValue="Bangladeshi" /></label>
            <label className="field">Expiry<input type="date" name="expiryDate" /></label>
          </div>
          <SubmitButton>Save passport</SubmitButton>
        </form>
        <div className="card">
          <h2>Documents</h2>
          {file.docs.map((doc) => (
            <p key={doc.id}><a href={`/api/files/${doc.id}`}>{doc.title}</a> {doc.verified ? "· verified" : ""}</p>
          ))}
          <form action={uploadAction}>
            <input type="hidden" name="back" value={`/visa/${file.app.id}`} />
            <input type="hidden" name="ownerEntity" value="visa" />
            <input type="hidden" name="ownerId" value={file.app.id} />
            <input type="hidden" name="visibility" value="restricted" />
            <label className="field">Title<input name="title" /></label>
            <input name="file" type="file" required />
            <div style={{ marginTop: 8 }}><SubmitButton>Upload privately</SubmitButton></div>
          </form>
        </div>
      </div>
    </Frame>
  );
}

async function ShopPage({ ctx, notice, error }: PageProps) {
  if (gate(ctx, "ecommerce") === "denied") return <Denied what="the shop" />;
  if (gate(ctx, "ecommerce") === "off") return <Off name="Shop" />;
  const look = await lookups(ctx);
  return (
    <Frame title="Shop sale" lede="One save creates the order, invoice, stock movement, and receipt if money was taken." actions={<Link className="btn-ghost" href="/stock">Products and stock</Link>}>
      <Notice notice={notice} error={error} />
      {ctx.company && look.products.length && look.customers.length ? (
        <form className="card" action={shopSaleAction}>
          <div className="fields">
            <label className="field">Customer<select name="customerId" required>{look.customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
            <label className="field">Paid now (taka)<input name="paid" type="number" step="0.01" defaultValue="0" /></label>
            <label className="field">Discount<input name="discount" type="number" step="0.01" defaultValue="0" /></label>
            <label className="field">Method<select name="method">{PAYMENT_METHODS.map((m) => <option key={m}>{m}</option>)}</select></label>
            <label className="field">Account<select name="accountId">{look.accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
            <label className="field">Reference<input name="reference" /></label>
            <ShopLines products={look.products.map((p) => ({ id: p.id, name: p.name, sku: p.sku, salePaisa: p.salePaisa, stockQty: p.stockQty }))} />
            <label className="field full">Delivery address<textarea name="deliveryAddress" rows={2} /></label>
            <label className="field full"><input type="checkbox" name="fulfillNow" defaultChecked /> Hand over or dispatch now and reduce stock</label>
          </div>
          <SubmitButton>Complete sale</SubmitButton>
        </form>
      ) : <div className="card">Add a customer and a product in this company before making a sale.</div>}
      <Generic ctx={ctx} notice="" error="" sp={{}} entity="product" path="/shop" />
    </Frame>
  );
}

async function PeoplePage({ ctx, notice, error }: PageProps) {
  if (gate(ctx, "hrm") === "denied") return <Denied what="employees" />;
  const look = await lookups(ctx);
  return (
    <Frame title="Employees" lede="Salary figures are hidden from people who do not have payroll access." actions={<Link className="btn-ghost" href="/attendance">Attendance</Link>}>
      <Notice notice={notice} error={error} />
      <div className="split">
        <div className="table-wrap">
          <table className="data"><thead><tr><th>Code</th><th>Name</th><th>Role</th>{ctx.can("payroll", "view") ? <th>Salary</th> : null}</tr></thead>
            <tbody>{look.employees.map((e) => <tr key={e.id}><td><Link href={`/people/${e.id}`}>{e.code}</Link></td><td>{e.name}</td><td>{e.designation}</td>{ctx.can("payroll", "view") ? <td>{formatBdt(e.salaryPaisa)}</td> : null}</tr>)}</tbody>
          </table>
        </div>
        {ctx.company && ctx.can("hrm", "create") ? (
          <form className="card" action={saveEmployeeAction}>
            <h2>Add employee</h2>
            <div className="fields">
              <label className="field">Name *<input name="name" required /></label>
              <label className="field">Designation<input name="designation" /></label>
              <label className="field">Phone<input name="phone" /></label>
              <label className="field">Email<input name="email" /></label>
              <label className="field">Joining<input type="date" name="joiningDate" defaultValue={todayDhaka()} /></label>
              <label className="field">Salary in taka<input name="salary" type="number" step="0.01" /></label>
              <label className="field">Commission %<input name="commissionPercent" type="number" step="0.1" defaultValue="0" /></label>
              <label className="field full">Notes<textarea name="notes" rows={2} /></label>
            </div>
            <SubmitButton>Save employee</SubmitButton>
          </form>
        ) : null}
      </div>
    </Frame>
  );
}

async function EmployeePage({ ctx, id }: PageProps & { id: number }) {
  const look = await lookups(ctx);
  const employee = look.employees.find((row) => row.id === id);
  if (!employee) notFound();
  return (
    <Frame title={employee.name} lede={`${employee.code} · ${employee.designation || "Staff"}`}>
      {ctx.can("payroll", "view") ? <p>Salary: {formatBdt(employee.salaryPaisa)}</p> : <p>Salary is hidden for your role.</p>}
      <Link className="btn-ghost" href="/people">Back to employees</Link>
    </Frame>
  );
}

async function AttendancePage({ ctx, notice, error }: PageProps) {
  if (!ctx.can("hrm", "view")) return <Denied what="attendance" />;
  const look = await lookups(ctx);
  return (
    <Frame title="Attendance" lede={`Mark everyone for one day. Today in Dhaka is ${todayDhaka()}.`}>
      <Notice notice={notice} error={error} />
      <form action={saveAttendanceAction} className="card">
        <label className="field">Date<input type="date" name="workDate" defaultValue={todayDhaka()} /></label>
        <div className="table-wrap">
          <table className="data"><thead><tr><th>Employee</th><th>Status</th><th>In</th><th>Out</th></tr></thead>
            <tbody>{look.employees.map((e) => (
              <tr key={e.id}>
                <td>{e.name}<input type="hidden" name="employeeId" value={e.id} /></td>
                <td><select name={`status_${e.id}`} defaultValue="present"><option>present</option><option>late</option><option>absent</option><option>leave</option><option>holiday</option></select></td>
                <td><input type="time" name={`in_${e.id}`} /></td>
                <td><input type="time" name={`out_${e.id}`} /></td>
              </tr>
            ))}</tbody>
          </table>
        </div>
        <div style={{ marginTop: 10 }}><SubmitButton>Save attendance</SubmitButton></div>
      </form>
    </Frame>
  );
}

async function LeavePage({ ctx, notice, error }: PageProps) {
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const rows = await db.select().from(leaveRequests).where(inArray(leaveRequests.companyId, ids)).orderBy(desc(leaveRequests.id)).limit(20);
  const look = await lookups(ctx);
  return (
    <Frame title="Leave" lede="A request stays pending until HR or a manager approves it.">
      <Notice notice={notice} error={error} />
      <div className="split">
        <div className="table-wrap"><table className="data"><thead><tr><th>Employee</th><th>Type</th><th>From</th><th>To</th><th>Status</th></tr></thead>
          <tbody>{rows.map((row) => <tr key={row.id}><td>{look.employees.find((e) => e.id === row.employeeId)?.name || row.employeeId}</td><td>{row.leaveType}</td><td>{formatDate(row.startDate)}</td><td>{formatDate(row.endDate)}</td><td><Badge value={row.status} /></td></tr>)}</tbody>
        </table></div>
        <form className="card" action={saveLeaveAction}>
          <h2>Request leave</h2>
          <div className="fields">
            {ctx.can("hrm", "create") ? <label className="field">Employee<select name="employeeId">{look.employees.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}</select></label> : null}
            <label className="field">Type<select name="leaveType"><option>annual</option><option>sick</option><option>unpaid</option><option>other</option></select></label>
            <label className="field">From<input type="date" name="startDate" required /></label>
            <label className="field">To<input type="date" name="endDate" required /></label>
            <label className="field full">Reason<textarea name="reason" rows={2} /></label>
          </div>
          <SubmitButton>Send request</SubmitButton>
        </form>
      </div>
    </Frame>
  );
}

async function PayrollPage({ ctx, notice, error }: PageProps) {
  if (!ctx.can("payroll", "view")) return <Denied what="payroll" />;
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const slips = await db.select().from(payslips).where(inArray(payslips.companyId, ids)).orderBy(desc(payslips.id)).limit(20);
  const look = await lookups(ctx);
  return (
    <Frame title="Payroll" lede="Only HR, the owner, and the employee can see a payslip. This is not a government payroll filing.">
      <Notice notice={notice} error={error} />
      <div className="split">
        <div className="table-wrap"><table className="data"><thead><tr><th>Period</th><th>Employee</th><th>Net</th><th>Status</th></tr></thead>
          <tbody>{slips.map((row) => <tr key={row.id}><td>{row.periodKey}</td><td>{look.employees.find((e) => e.id === row.employeeId)?.name}</td><td>{formatBdt(row.netPaisa)}</td><td><Badge value={row.status} /></td></tr>)}</tbody>
        </table></div>
        {ctx.can("payroll", "create") ? (
          <form className="card" action={savePayslipAction}>
            <h2>Prepare payslip</h2>
            <div className="fields">
              <label className="field">Employee<select name="employeeId" required>{look.employees.map((e) => <option key={e.id} value={e.id}>{e.name}</option>)}</select></label>
              <label className="field">Period<input name="periodKey" placeholder="2026-03" required /></label>
              <label className="field">Basic<input name="basic" type="number" step="0.01" /></label>
              <label className="field">Allowances<input name="allowances" type="number" step="0.01" /></label>
              <label className="field">Deductions<input name="deductions" type="number" step="0.01" /></label>
              <label className="field">Bonus<input name="bonus" type="number" step="0.01" /></label>
              <label className="field">Commission<input name="commission" type="number" step="0.01" /></label>
              <label className="field">Advance recovery<input name="advance" type="number" step="0.01" /></label>
            </div>
            <SubmitButton>Save payslip</SubmitButton>
          </form>
        ) : null}
      </div>
    </Frame>
  );
}

async function MePage({ ctx }: PageProps) {
  const desk = await myDesk(ctx);
  return (
    <Frame title="My desk" lede="Your own attendance, leave, payslips, and tasks.">
      {!desk.employee ? <p>Your sign-in is not linked to an employee record yet. The owner can link it in Settings.</p> : <p>{desk.employee.name} · {desk.employee.designation}</p>}
      <div className="split">
        <div className="card"><h2>Attendance</h2>{desk.attendance.map((row) => <p key={row.id}>{formatDate(row.workDate)} · {row.status}</p>)}</div>
        <div className="card"><h2>Payslips</h2>{desk.slips.map((row) => <p key={row.id}>{row.periodKey} · {formatBdt(row.netPaisa)}</p>)}{!desk.slips.length ? <p>No payslip yet.</p> : null}</div>
      </div>
      <form className="card" action={saveLeaveAction}><h2>Ask for leave</h2><div className="fields"><label className="field">Type<select name="leaveType"><option>annual</option><option>sick</option></select></label><label className="field">From<input type="date" name="startDate" required /></label><label className="field">To<input type="date" name="endDate" required /></label><label className="field full">Reason<textarea name="reason" /></label></div><SubmitButton>Send</SubmitButton></form>
    </Frame>
  );
}

async function ReportsPage({ ctx }: PageProps) {
  if (!ctx.can("reports", "view") && !ctx.permissions.includes("*")) return <Denied what="reports" />;
  const data = await reportData(ctx);
  const names = new Map(ctx.companies.map((c) => [c.id, c.name]));
  return (
    <Frame title="Reports" lede="These numbers are calculated from saved records. Export is available to people with export permission." actions={ctx.can("reports", "export") || ctx.can("accounting", "export") ? <a className="btn" href="/api/export?type=invoices">Download invoices CSV</a> : null}>
      <div className="split">
        <div className="card"><h2>Collections this month</h2>{data.collections.map((row) => <p key={row.companyId}>{names.get(row.companyId)} · {formatBdt(row.amount)}</p>)}</div>
        <div className="card"><h2>Expenses this month</h2>{data.expenses.map((row) => <p key={row.companyId}>{names.get(row.companyId)} · {formatBdt(row.amount)}</p>)}</div>
      </div>
      <div className="card"><h2>Still due</h2>{data.outstanding.map((row) => <p key={row.companyId}>{names.get(row.companyId)} · {formatBdt(row.amount)}</p>)}</div>
      <div className="card">
        <h2>Simple trial balance from journal entries</h2>
        <p className="muted">This is the foundation for later full accounts. It is not a completed statutory set of books.</p>
        <table className="data"><thead><tr><th>Account</th><th>Debit</th><th>Credit</th></tr></thead>
          <tbody>{data.trial.map((row) => <tr key={row.glCode}><td>{row.glCode} {row.name}</td><td>{formatBdt(row.debit)}</td><td>{formatBdt(row.credit)}</td></tr>)}</tbody>
        </table>
      </div>
      <div className="card"><h2>Visa files by status</h2>{data.visas.map((row) => <p key={row.status}>{row.status}: {row.n}</p>)}</div>
      <div className="card"><h2>Leads by source</h2>{data.leads.map((row) => <p key={row.source}>{row.source || "Unknown"}: {row.n}</p>)}</div>
    </Frame>
  );
}

async function CompaniesPage({ ctx, notice, error }: PageProps) {
  if (!ctx.can("companies", "view") && !ctx.permissions.includes("*") && !ctx.can("companies", "manage")) return <Denied what="companies" />;
  const rows = ctx.permissions.includes("*") ? await db.select().from(companies).orderBy(companies.name) : ctx.companies;
  return (
    <Frame title="Companies" lede="Each company has its own customers, money, and modules. Records are not mixed.">
      <Notice notice={notice} error={error} />
      <div className="stats">{rows.map((c) => <div className="stat" key={c.id} style={{ borderTop: `4px solid ${"brandColor" in c ? c.brandColor : "#0f6e68"}` }}><span>{c.businessType}</span><strong style={{ fontSize: "1.3rem" }}>{c.name}</strong></div>)}</div>
      {(ctx.permissions.includes("*") || ctx.can("companies", "manage")) ? (
        <form className="card" action={saveCompanyAction}>
          <h2>Add a company</h2>
          <div className="fields">
            <label className="field">Name *<input name="name" required /></label>
            <label className="field">Short code *<input name="shortName" required placeholder="DH" /></label>
            <label className="field">Type<select name="businessType">{Object.entries(BUSINESS_TYPES).map(([key, value]) => <option key={key} value={key}>{value.label}</option>)}</select></label>
            <label className="field">City<input name="city" defaultValue="Dhaka" /></label>
            <label className="field">Phone<input name="phone" /></label>
            <label className="field">Email<input name="email" /></label>
            <label className="field full">Address<textarea name="address" rows={2} /></label>
            <label className="field">Brand colour<input name="brandColor" defaultValue="#0f6e68" /></label>
            <label className="field">Invoice prefix<input name="invoicePrefix" placeholder="DH-INV" /></label>
            <label className="field">Receipt prefix<input name="receiptPrefix" placeholder="DH-RCT" /></label>
            <label className="field">VAT %<input name="taxPercent" type="number" step="0.01" defaultValue="0" /></label>
          </div>
          <SubmitButton>Create company</SubmitButton>
        </form>
      ) : null}
      {ctx.company && (ctx.can("companies", "manage") || ctx.permissions.includes("*")) ? (
        <div className="card">
          <h2>Modules for {ctx.company.name}</h2>
          <p className="muted">Turn off a module the company does not use. Staff will not see it, and the server will refuse it.</p>
          {MODULES.map((mod) => (
            <form key={mod.key} action={toggleModuleAction} style={{ display: "flex", gap: 8, alignItems: "center", marginBottom: 8 }}>
              <input type="hidden" name="companyId" value={ctx.company?.id} />
              <input type="hidden" name="moduleKey" value={mod.key} />
              <label><input type="checkbox" name="enabled" defaultChecked={ctx.modules.has(mod.key)} /> {mod.label}</label>
              <button className="btn-ghost" type="submit">Save</button>
            </form>
          ))}
        </div>
      ) : null}
      <p><Link href="/structure">Branches and departments</Link></p>
    </Frame>
  );
}

async function SettingsPage({ ctx, notice, error }: PageProps) {
  const data = await settingsData(ctx);
  return (
    <Frame title="Settings" lede="Change your password here. Starter passwords should be changed before real customer data is added.">
      <Notice notice={notice} error={error} />
      <div className="split">
        <form className="card" action={changePasswordAction}>
          <h2>Change my password</h2>
          <label className="field">Current password<input type="password" name="current" required /></label>
          <label className="field">New password<input type="password" name="password" required /></label>
          <SubmitButton>Update password</SubmitButton>
        </form>
        <div className="card">
          <h2>Extra sign-in code</h2>
          <p className="muted">Optional. Start setup, add the secret to an authenticator app, then enter a code.</p>
          <form action={toggleTotpAction}><input type="hidden" name="enable" value="on" /><SubmitButton>Start setup</SubmitButton></form>
          <form action={confirmTotpAction} style={{ marginTop: 8 }}>
            <label className="field">6-digit code<input name="code" inputMode="numeric" /></label>
            <SubmitButton>Turn on</SubmitButton>
          </form>
        </div>
      </div>
      {ctx.can("settings", "manage") || ctx.permissions.includes("*") ? (
        <form className="card" action={saveUserAction}>
          <h2>Add a user</h2>
          <div className="fields">
            <label className="field">Name<input name="name" required /></label>
            <label className="field">Email<input name="email" type="email" required /></label>
            <label className="field">Starting password<input name="password" required /></label>
            <label className="field">Role<select name="roleId">{data.roles.map((role) => <option key={role.id} value={role.id}>{role.name}</option>)}</select></label>
            <div className="field full">{ctx.companies.map((c) => <label key={c.id} style={{ display: "block" }}><input type="checkbox" name="companyId" value={c.id} /> {c.name}</label>)}</div>
          </div>
          <SubmitButton>Save user</SubmitButton>
        </form>
      ) : null}
      <div className="card">
        <h2>People</h2>
        {data.users.map((user) => (
          <p key={user.id}>{user.name} · {user.email} · {data.roles.find((r) => r.id === user.roleId)?.name}
            {ctx.can("settings", "manage") ? <form action={resetCodeAction} style={{ display: "inline" }}><input type="hidden" name="userId" value={user.id} /><button className="btn-ghost" type="submit">Reset code</button></form> : null}
          </p>
        ))}
      </div>
      {ctx.permissions.includes("*") ? (
        <form className="card" action={saveRoleAction}>
          <h2>Custom role</h2>
          <label className="field">Name<input name="name" required /></label>
          <div className="fields">{MODULES.flatMap((mod) => ["view", "create", "edit", "approve", "export"].map((action) => <label key={mod.key + action}><input type="checkbox" name="permission" value={`${mod.key}:${action}`} /> {mod.label}: {action}</label>))}</div>
          <SubmitButton>Save role</SubmitButton>
        </form>
      ) : null}
      <div className="card">
        <h2>Backup</h2>
        <p>A backup is marked successful only after the file is written and its size is checked. Download it and keep it somewhere safe. It contains business records.</p>
        {ctx.permissions.includes("*") ? <a className="btn" href="/api/backup">Download verified backup</a> : <p>Only the owner can download the full backup.</p>}
      </div>
    </Frame>
  );
}

async function ApprovalsPage({ ctx, notice, error }: PageProps) {
  if (!ctx.can("approvals", "view") && !ctx.can("approvals", "approve") && !ctx.permissions.includes("*")) return <Denied what="approvals" />;
  const rows = await pendingApprovals(ctx);
  return (
    <Frame title="Approvals" lede="Nothing sensitive is finished until someone with permission says yes.">
      <Notice notice={notice} error={error} />
      {rows.map((row) => (
        <form key={row.id} className="card" action={decideApprovalAction}>
          <input type="hidden" name="id" value={row.id} />
          <strong>{row.type.replaceAll("_", " ")}</strong>
          <p>{row.reason}</p>
          <label className="field">Comment<input name="comments" /></label>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn" name="decision" value="approved">Approve</button>
            <button className="btn-danger" name="decision" value="rejected">Decline</button>
          </div>
        </form>
      ))}
      {!rows.length ? <div className="empty">Nothing is waiting.</div> : null}
    </Frame>
  );
}

async function NotesPage({ ctx }: PageProps) {
  const rows = await db.select().from(notifications).where(eq(notifications.userId, ctx.user.id)).orderBy(desc(notifications.id)).limit(40);
  return (
    <Frame title="Notifications" actions={<form action={markReadAction}><SubmitButton>Mark all read</SubmitButton></form>}>
      {rows.map((row) => <article className="card" key={row.id}><strong>{row.title}</strong><p>{row.body}</p>{row.href ? <Link href={row.href}>Open</Link> : null}<div className="muted">{row.readAt ? "Read" : "New"}</div></article>)}
      {!rows.length ? <p>No notifications yet.</p> : null}
    </Frame>
  );
}

async function DocumentsPage({ ctx, notice, error }: PageProps) {
  if (!ctx.can("documents", "view")) return <Denied what="documents" />;
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const docs = await db.select().from(documents).where(inArray(documents.companyId, ids)).orderBy(desc(documents.id)).limit(30);
  return (
    <Frame title="Documents" lede="Files are stored privately. A link only works for someone signed in with access.">
      <Notice notice={notice} error={error} />
      <form className="card" action={uploadAction}>
        <input type="hidden" name="back" value="/documents" />
        <div className="fields">
          <label className="field">Title<input name="title" /></label>
          <label className="field">Visibility<select name="visibility"><option value="standard">Standard</option><option value="restricted">Restricted</option></select></label>
          <label className="field full">File<input type="file" name="file" required /></label>
        </div>
        <SubmitButton>Upload</SubmitButton>
      </form>
      {docs.map((doc) => (
        <p key={doc.id}><a href={`/api/files/${doc.id}`}>{doc.title}</a> · {doc.visibility} {doc.verified ? "· verified" : ""}
          {ctx.can("documents", "verify") ? <form action={verifyDocumentAction} style={{ display: "inline" }}><input type="hidden" name="id" value={doc.id} /><input type="hidden" name="back" value="/documents" /><input type="hidden" name="verified" value="on" /><button className="btn-ghost">Verify</button></form> : null}
        </p>
      ))}
      <Generic ctx={ctx} notice="" error="" sp={{}} entity="template" path="/documents" />
    </Frame>
  );
}

function HelpPage() {
  const articles = [
    ["Choose a company", "Use the company list at the top. Add records only after one company is selected. All companies is for looking, not for new records."],
    ["Add a customer once", "Customers → Add customer. Later invoices and visa files use that same person."],
    ["Take a payment", "Open the invoice, enter the amount, choose cash, bank, or bKash, and save. The due amount updates. A reference cannot be used twice."],
    ["Cancel a receipt", "Write a reason. The number stays used. The money and customer balance are reversed, not deleted."],
    ["Visa file", "Open a file, add the passport, upload scans, and change the status as the embassy process moves."],
    ["Shop sale", "Shop → choose products and how much was paid. Stock falls only if you tick hand over now."],
    ["Leave and payroll", "Staff request leave from My desk. HR approves it under Approvals. Payslips are hidden from other staff."],
    ["Backup", "Settings → Download verified backup. Keep the file private. A backup is not called successful unless the file was written and checked."],
  ];
  return (
    <Frame title="Help" lede="Short instructions for everyday work. You do not need to understand programming to use this desk.">
      <div className="help-grid">{articles.map(([title, body]) => <article className="card" key={title}><h2>{title}</h2><p>{body}</p></article>)}</div>
    </Frame>
  );
}

async function SearchPage({ ctx, sp }: PageProps) {
  const q = spOne(sp, "q");
  const data = await searchAll(ctx, q);
  return (
    <Frame title="Search" lede={q ? `Results for “${q}”` : "Type at least 2 letters."}>
      {data.customers.map((row) => <p key={row.id}><Link href={`/crm/${row.id}`}>{row.customerCode} · {row.name}</Link> · {row.phone}</p>)}
      {data.invoices.map((row) => <p key={row.id}><Link href={`/accounting/${row.id}`}>{row.number}</Link> · {formatBdt(row.totalPaisa)}</p>)}
      {data.visas.map((row) => <p key={row.id}><Link href={`/visa/${row.id}`}>{row.applicationCode}</Link> · {row.status}</p>)}
      {data.employees.map((row) => <p key={row.id}><Link href={`/people/${row.id}`}>{row.employeeCode} · {row.name}</Link></p>)}
    </Frame>
  );
}

function EntryPage({ ctx }: PageProps) {
  const links = [
    ["/crm", "Customer", "crm"],
    ["/leads", "Lead", "crm"],
    ["/visa", "Visa file", "visa"],
    ["/education", "Student", "education"],
    ["/expenses", "Expense", "accounting"],
    ["/accounting", "Payment via invoice", "accounting"],
    ["/buying", "Supplier", "procurement"],
    ["/bookings", "Booking", "bookings"],
    ["/office", "Visitor", "office"],
  ].filter((item) => ctx.can(item[2], "create") || ctx.permissions.includes("*"));
  return (
    <Frame title="Data entry" lede="Pick the kind of record. Required fields are marked. Duplicates are checked for customers.">
      <div className="stats">{links.map(([href, label]) => <Link key={href} className="stat" href={href}><strong style={{ fontSize: "1.3rem" }}>{label}</strong><span>Open the form</span></Link>)}</div>
    </Frame>
  );
}

async function PrivatePage({ ctx, notice, error }: PageProps) {
  if (!ctx.can("sensitive", "view") && !ctx.can("sensitive", "create")) return <Denied what="private records" />;
  const data = await privateRows(ctx);
  const look = await lookups(ctx);
  return (
    <Frame title="Private records" lede="Questionnaires and companion notes need consent first. They are not shown to ordinary sales or accounts staff.">
      <Notice notice={notice} error={error} />
      <form className="card" action={saveAssessmentAction}>
        <h2>Save a consented note</h2>
        <div className="fields">
          <label className="field">Customer<select name="customerId" required>{look.customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></label>
          <label className="field">Consent purpose must already be granted<input name="purpose" required placeholder="Life profile assessment" /></label>
          <label className="field full">Answer<input name="q_main" /></label>
          <label className="field full">Result summary<textarea name="resultSummary" rows={2} /></label>
          <label className="field full">Recommendation<textarea name="recommendations" rows={2} /></label>
        </div>
        <SubmitButton>Save privately</SubmitButton>
      </form>
      <p className="muted">To grant consent, add a consent record below and tick granted.</p>
      <Generic ctx={ctx} notice="" error="" sp={{}} entity="consent" path="/private" />
      {data.assessments.map((row) => <p key={row.id}>Customer {row.customerId}: {row.resultSummary || "Private record saved"}</p>)}
    </Frame>
  );
}

async function AuditPage({ ctx }: PageProps) {
  const rows = await auditRows(ctx);
  if (!rows.length && !ctx.can("audit", "view")) return <Denied what="the audit log" />;
  return (
    <Frame title="Audit log" lede="Important actions keep who did them and when.">
      <div className="table-wrap"><table className="data"><thead><tr><th>When</th><th>Action</th><th>Record</th><th>User</th></tr></thead>
        <tbody>{rows.map((row) => <tr key={row.id}><td>{formatDate(String(row.createdAt))}</td><td>{row.action}</td><td>{row.entity} {row.entityId || ""}</td><td>{row.userId}</td></tr>)}</tbody>
      </table></div>
    </Frame>
  );
}

async function BuyingPage({ ctx, notice, error }: PageProps) {
  if (gate(ctx, "procurement") === "denied") return <Denied />;
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const orders = await db.select().from(purchaseOrders).where(inArray(purchaseOrders.companyId, ids)).orderBy(desc(purchaseOrders.id)).limit(20);
  const look = await lookups(ctx);
  return (
    <Frame title="Buying" lede="Request, approve, receive, then pay. Stock increases only when goods are received.">
      <Notice notice={notice} error={error} />
      <Generic ctx={ctx} notice="" error="" sp={{}} entity="supplier" path="/buying" />
      <form className="card" action={savePurchaseAction}>
        <h2>Purchase request</h2>
        <div className="fields">
          <label className="field">Supplier<select name="supplierId" required>{look.suppliers.map((row) => <option key={row.id} value={row.id}>{row.name}</option>)}</select></label>
          <label className="field">Product<select name="productId"><option value="">No stock item</option>{look.products.map((row) => <option key={row.id} value={row.id}>{row.name}</option>)}</select></label>
          <label className="field full">What are you buying?<input name="description" required /></label>
          <label className="field">Qty<input name="qty" type="number" defaultValue="1" /></label>
          <label className="field">Unit cost<input name="unit" type="number" step="0.01" /></label>
        </div>
        <SubmitButton>Save request</SubmitButton>
      </form>
      {orders.map((order) => (
        <form key={order.id} className="card" action={receivePurchaseAction}>
          <input type="hidden" name="id" value={order.id} />
          <strong>{order.number}</strong> · {formatBdt(order.totalPaisa)} · <Badge value={order.status} />
          <label><input type="checkbox" name="payNow" /> Pay now</label>
          <select name="accountId"><option value="">Account if paying now</option>{look.accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select>
          <SubmitButton>Mark received</SubmitButton>
        </form>
      ))}
      <form className="card" action={paySupplierAction}>
        <h2>Pay a supplier</h2>
        <div className="fields">
          <label className="field">Supplier<select name="supplierId" required>{look.suppliers.map((row) => <option key={row.id} value={row.id}>{row.name}</option>)}</select></label>
          <label className="field">Amount<input name="amount" type="number" step="0.01" required /></label>
          <label className="field">Account<select name="accountId">{look.accounts.map((a) => <option key={a.id} value={a.id}>{a.name}</option>)}</select></label>
        </div>
        <SubmitButton>Pay</SubmitButton>
      </form>
    </Frame>
  );
}

async function StockPage({ ctx, notice, error }: PageProps) {
  if (!ctx.can("inventory", "view") && !ctx.can("ecommerce", "view")) return <Denied what="stock" />;
  const look = await lookups(ctx);
  return (
    <Frame title="Stock and assets" lede="Company stock is separate. Low stock is highlighted when quantity is at the reorder level.">
      <Notice notice={notice} error={error} />
      <div className="table-wrap"><table className="data"><thead><tr><th>SKU</th><th>Product</th><th>Stock</th><th>Price</th></tr></thead>
        <tbody>{look.products.map((p) => <tr key={p.id}><td>{p.sku}</td><td>{p.name}</td><td>{p.stockQty <= p.reorderLevel ? <Badge value="low" /> : null} {p.stockQty}</td><td>{formatBdt(p.salePaisa)}</td></tr>)}</tbody>
      </table></div>
      <form className="card" action={stockAction}>
        <h2>Adjust stock</h2>
        <div className="fields">
          <label className="field">Product<select name="productId">{look.products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
          <label className="field">Change<input name="qtyChange" type="number" required placeholder="-1 or 5" /></label>
          <label className="field">Reason<input name="reason" required /></label>
        </div>
        <SubmitButton>Update stock</SubmitButton>
      </form>
      <Generic ctx={ctx} notice="" error="" sp={{}} entity="asset" path="/stock" />
      <Generic ctx={ctx} notice="" error="" sp={{}} entity="supply" path="/stock" />
    </Frame>
  );
}

type PageProps = { ctx: Awaited<ReturnType<typeof getContext>>; notice: string; error: string; sp: SearchParams };

async function Generic({ ctx, notice, error, sp, entity, path, extra }: PageProps & { entity: string; path: string; extra?: string }) {
  const def = ENTITIES[entity];
  if (!def) return null;
  if (!ctx.can(def.module, "view") && !ctx.permissions.includes("*")) return <Denied what={def.title} />;
  if (ctx.company && !moduleEnabled(ctx, def.module) && def.module !== "companies") return <Off name={def.title} />;
  const page = pageOf(sp);
  const data = await listEntity(ctx, entity, spOne(sp, "q"), page, spOne(sp, "status"));
  const look = await lookups(ctx);
  const choices: Record<string, { id: number; label: string }[]> = {
    customerId: look.customers.map((row) => ({ id: row.id, label: `${row.code} — ${row.name}` })),
    assignedUserId: look.users.map((row) => ({ id: row.id, label: row.name })),
    counsellorId: look.users.map((row) => ({ id: row.id, label: row.name })),
    userId: look.users.map((row) => ({ id: row.id, label: row.name })),
    employeeId: look.employees.map((row) => ({ id: row.id, label: row.name })),
    managerId: look.employees.map((row) => ({ id: row.id, label: row.name })),
    assignedEmployeeId: look.employees.map((row) => ({ id: row.id, label: row.name })),
    productId: look.products.map((row) => ({ id: row.id, label: `${row.sku} — ${row.name}` })),
    countryId: look.countries.map((row) => ({ id: row.id, label: row.name })),
    categoryId: look.categories.map((row) => ({ id: row.id, label: row.name })),
    supplierId: look.suppliers.map((row) => ({ id: row.id, label: row.name })),
    serviceId: look.services.map((row) => ({ id: row.id, label: row.name })),
    universityId: look.universities.map((row) => ({ id: row.id, label: row.country ? `${row.name} · ${row.country}` : row.name })),
  };
  return (
    <Frame title={def.title} lede={def.intro}>
      <Notice notice={notice} error={error} />
      <div className="split">
        <div>
          <div className="table-wrap">
            <table className="data">
              <thead><tr>{def.columns.map((col) => <th key={col.key}>{col.label}</th>)}<th></th></tr></thead>
              <tbody>
                {data.rows.map((row: Record<string, unknown>) => (
                  <tr key={String(row.id)}>
                    {def.columns.map((col) => <td key={col.key}>{show(row[col.key], col.format)}</td>)}
                    <td>
                      {extra === "convert" && !row.customerId ? <form action={convertLeadAction}><input type="hidden" name="id" value={String(row.id)} /><SubmitButton>Make customer</SubmitButton></form> : null}
                      {ctx.can(def.module, "delete") ? <ArchiveForm entity={entity} id={Number(row.id)} back={path} /> : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            {!data.rows.length ? <div className="empty">Nothing here yet.</div> : null}
          </div>
          <Pager page={page} total={data.total} sp={sp} path={path} />
        </div>
        {ctx.can(def.module, "create") && (def.scope === "global" || ctx.company) ? <EntityForm def={def} back={path} choices={choices} /> : <div className="card">Choose a company before adding a record.</div>}
      </div>
    </Frame>
  );
}

async function Tabbed({ ctx, notice, error, sp, base, tabs, current }: PageProps & { base: string; tabs: string[][]; current: string }) {
  const match = tabs.find((tab) => tab[1] === current) || tabs[0];
  return (
    <div>
      <Tabs items={tabs.map(([label, key]) => ({ href: key === tabs[0][1] ? base : `${base}/${key}`, label }))} current={match[1] === tabs[0][1] ? base : `${base}/${match[1]}`} />
      <Generic ctx={ctx} notice={notice} error={error} sp={sp} entity={match[1]} path={match[1] === tabs[0][1] ? base : `${base}/${match[1]}`} />
    </div>
  );
}


