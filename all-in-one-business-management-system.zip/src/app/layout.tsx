import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "AIO Desk", template: "%s · AIO Desk" },
  description: "All-in-one business management for your companies.",
  applicationName: "AIO Desk",
  manifest: "/manifest.webmanifest",
  icons: { icon: "/brand/icon.png", apple: "/brand/icon.png" },
  robots: { index: false, follow: false },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
