import { completeResetAction } from "@/server/actions";
import { SubmitButton } from "@/components/widgets";

export default async function ResetPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string }> }) {
  const sp = await searchParams;
  return (
    <main className="login-panel" style={{ minHeight: "100vh", maxWidth: 560, margin: "0 auto" }}>
      <p className="kicker">Password reset</p>
      <h1>Set a new password</h1>
      <p className="lede">Ask the owner for a one-time code. Codes expire after two hours and cannot be used twice.</p>
      {sp.error ? <div className="notice notice-bad">{sp.error}</div> : null}
      {sp.notice ? <div className="notice">{sp.notice}</div> : null}
      <form action={completeResetAction} className="fields">
        <label className="field full">Email<input name="email" type="email" required /></label>
        <label className="field full">Reset code<input name="code" required /></label>
        <label className="field full">New password<input name="password" type="password" required /></label>
        <SubmitButton>Save password</SubmitButton>
      </form>
    </main>
  );
}
