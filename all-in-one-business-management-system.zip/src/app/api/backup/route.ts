import { mkdir, stat, writeFile } from "fs/promises";
import path from "path";
import { db } from "@/db";
import { backupLogs, companies, customers, invoices, payments, receipts, users } from "@/db/schema";
import { getContext } from "@/lib/context";

export const runtime = "nodejs";

export async function GET() {
  const ctx = await getContext();
  if (!ctx.permissions.includes("*")) return new Response("Only the owner can download a backup.", { status: 403 });
  const payload = {
    exportedAt: new Date().toISOString(),
    note: "Confidential backup. Passwords are included as hashes so a restore can keep sign-ins. Do not email this file.",
    companies: await db.select().from(companies),
    customers: await db.select().from(customers),
    invoices: await db.select().from(invoices),
    receipts: await db.select().from(receipts),
    payments: await db.select().from(payments),
    users: (await db.select().from(users)).map((user) => user),
  };
  const json = JSON.stringify(payload, null, 2);
  const dir = path.join(process.cwd(), "storage", "backups");
  await mkdir(dir, { recursive: true });
  const file = path.join(dir, `backup-${Date.now()}.json`);
  await writeFile(file, json);
  const info = await stat(file);
  if (info.size < 50) return new Response("Backup file was empty, so it was not marked successful.", { status: 500 });
  await db.insert(backupLogs).values({ kind: "json", status: "verified", bytes: info.size, message: "File written and size checked.", createdBy: ctx.user.id });
  return new Response(json, {
    headers: {
      "Content-Type": "application/json",
      "Content-Disposition": "attachment; filename=aio-desk-backup.json",
    },
  });
}
