import { inArray } from "drizzle-orm";
import { db } from "@/db";
import { customers, invoices } from "@/db/schema";
import { getContext } from "@/lib/context";
import { csvCell, formatBdt } from "@/lib/utils";

export const runtime = "nodejs";

export async function GET(req: Request) {
  const ctx = await getContext();
  if (!ctx.can("reports", "export") && !ctx.can("accounting", "export") && !ctx.permissions.includes("*")) {
    return new Response("You cannot export.", { status: 403 });
  }
  const type = new URL(req.url).searchParams.get("type") || "customers";
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  let csv = "";
  if (type === "invoices") {
    const rows = await db.select().from(invoices).where(inArray(invoices.companyId, ids)).limit(5000);
    csv = ["number,status,total,due,date", ...rows.map((row) => [row.number, row.status, formatBdt(row.totalPaisa), formatBdt(row.duePaisa), row.issueDate].map(csvCell).join(","))].join("\n");
  } else {
    const rows = await db.select().from(customers).where(inArray(customers.companyId, ids)).limit(5000);
    csv = ["code,name,phone,email,source,status", ...rows.map((row) => [row.customerCode, row.name, row.phone, row.email, row.source, row.status].map(csvCell).join(","))].join("\n");
  }
  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${type}.csv"`,
    },
  });
}
