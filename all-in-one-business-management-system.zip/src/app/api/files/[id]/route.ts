import { readFile } from "fs/promises";
import path from "path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { documents } from "@/db/schema";
import { getContext } from "@/lib/context";

export const runtime = "nodejs";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const session = await getContext();
  const [doc] = await db.select().from(documents).where(eq(documents.id, Number(id)));
  if (!doc || !session.companyIds.includes(doc.companyId)) return new Response("Not found", { status: 404 });
  if (doc.visibility === "restricted" && !session.can("documents", "view") && !session.can("visa", "view") && !session.permissions.includes("*")) {
    return new Response("Not found", { status: 404 });
  }
  const root = path.resolve(process.cwd(), "storage", "uploads");
  const full = path.resolve(root, doc.storagePath);
  if (!full.startsWith(root)) return new Response("Not found", { status: 404 });
  const bytes = await readFile(full);
  return new Response(bytes, {
    headers: {
      "Content-Type": doc.mime || "application/octet-stream",
      "Content-Disposition": `inline; filename="${doc.fileName.replace(/"/g, "")}"`,
      "X-Content-Type-Options": "nosniff",
      "Cache-Control": "private, no-store",
    },
  });
}
