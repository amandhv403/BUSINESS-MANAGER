import { eq } from "drizzle-orm";
import { PDFDocument, StandardFonts, rgb } from "pdf-lib";
import { db } from "@/db";
import { companies, customers, invoiceItems, invoices } from "@/db/schema";
import { getContext } from "@/lib/context";
import { formatBdtPlain, formatDate } from "@/lib/utils";

export const runtime = "nodejs";

export async function GET(_req: Request, ctxArg: { params: Promise<{ id: string }> }) {
  const { id } = await ctxArg.params;
  const ctx = await getContext();
  const [invoice] = await db.select().from(invoices).where(eq(invoices.id, Number(id)));
  if (!invoice || !ctx.companyIds.includes(invoice.companyId) || !ctx.can("accounting", "view")) return new Response("Not found", { status: 404 });
  const [company] = await db.select().from(companies).where(eq(companies.id, invoice.companyId));
  const [customer] = await db.select().from(customers).where(eq(customers.id, invoice.customerId));
  const items = await db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoice.id));
  const pdf = await PDFDocument.create();
  const page = pdf.addPage([595, 842]);
  const font = await pdf.embedFont(StandardFonts.Helvetica);
  const bold = await pdf.embedFont(StandardFonts.HelveticaBold);
  let y = 800;
  const draw = (text: string, size = 11, strong = false) => {
    page.drawText(text.slice(0, 110), { x: 48, y, size, font: strong ? bold : font, color: rgb(0.09, 0.12, 0.2) });
    y -= size + 8;
  };
  draw(company?.name || "Company", 18, true);
  draw(company?.address || "");
  draw(`Invoice ${invoice.number}`, 16, true);
  draw(`Customer: ${customer?.name || ""}`);
  draw(`Date: ${formatDate(invoice.issueDate)}  Status: ${invoice.status}`);
  y -= 8;
  for (const item of items) {
    draw(`${item.description}  x${item.qty}  ${formatBdtPlain(item.lineTotalPaisa)}`);
  }
  y -= 6;
  draw(`Service income ${formatBdtPlain(invoice.servicePaisa)}`);
  draw(`Third-party money ${formatBdtPlain(invoice.thirdPartyPaisa)}`);
  draw(`Total ${formatBdtPlain(invoice.totalPaisa)}   Due ${formatBdtPlain(invoice.duePaisa)}`, 13, true);
  draw("Operational invoice. Not a completed statutory tax document.");
  const bytes = await pdf.save();
  return new Response(Buffer.from(bytes), {
    headers: {
      "Content-Type": "application/pdf",
      "Content-Disposition": `attachment; filename="${invoice.number}.pdf"`,
    },
  });
}
