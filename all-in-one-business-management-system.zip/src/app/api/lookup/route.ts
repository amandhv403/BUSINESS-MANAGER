import { and, ilike, inArray, or } from "drizzle-orm";
import { db } from "@/db";
import { customers } from "@/db/schema";
import { getContext } from "@/lib/context";
import { likeTerm } from "@/lib/utils";

export async function GET(req: Request) {
  const ctx = await getContext();
  const q = new URL(req.url).searchParams.get("q") || "";
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const rows = await db.select({ id: customers.id, name: customers.name, code: customers.customerCode, phone: customers.phone }).from(customers).where(and(inArray(customers.companyId, ids), q ? or(ilike(customers.name, likeTerm(q)), ilike(customers.phone, likeTerm(q))) : undefined)).limit(20);
  return Response.json({ options: rows });
}
