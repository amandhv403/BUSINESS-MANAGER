import { notFound } from "next/navigation";
import { getContext } from "@/lib/context";
import { invoiceFile } from "@/lib/queries";
import { formatBdt, formatDate } from "@/lib/utils";
import { PrintBar } from "@/components/print-bar";

export const dynamic = "force-dynamic";

export default async function PrintInvoice({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const ctx = await getContext();
  const file = await invoiceFile(ctx, Number(id));
  if (!file || !ctx.can("accounting", "view")) notFound();
  const { invoice, items, customer, company } = file;
  return (
    <main style={{ maxWidth: 800, margin: "24px auto", background: "white", padding: 32, color: "#172033" }}>
      <PrintBar kind="invoice" id={invoice.id} />
      <p style={{ letterSpacing: "0.14em", textTransform: "uppercase", color: company?.brandColor || "#0f6e68" }}>{company?.name}</p>
      <h1 style={{ fontFamily: "Georgia, serif" }}>Invoice {invoice.number}</h1>
      <p>{company?.address} · {company?.phone} · {company?.email}</p>
      <p><strong>{customer?.name}</strong><br />{customer?.phone}<br />{customer?.address}</p>
      <p>Date {formatDate(invoice.issueDate)} · Due {formatDate(invoice.dueDate)}</p>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead><tr><th align="left">Description</th><th>Type</th><th>Qty</th><th align="right">Amount</th></tr></thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id}>
              <td style={{ borderTop: "1px solid #eee", padding: 8 }}>{item.description}</td>
              <td style={{ borderTop: "1px solid #eee" }}>{item.kind}</td>
              <td style={{ borderTop: "1px solid #eee" }}>{item.qty}</td>
              <td style={{ borderTop: "1px solid #eee" }} align="right">{formatBdt(item.lineTotalPaisa)}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <p>Service income {formatBdt(invoice.servicePaisa)} · Product income {formatBdt(invoice.productPaisa)} · Third-party money {formatBdt(invoice.thirdPartyPaisa)}</p>
      <h2>Total {formatBdt(invoice.totalPaisa)} · Due {formatBdt(invoice.duePaisa)}</h2>
      <p style={{ color: "#666" }}>Operational invoice. Not a statutory tax invoice unless your accountant confirms the tax setup.</p>
    </main>
  );
}
