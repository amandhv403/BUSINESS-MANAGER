import { notFound } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { companies, customers, receipts } from "@/db/schema";
import { getContext } from "@/lib/context";
import { formatBdt, formatDate } from "@/lib/utils";
import { PrintBar } from "@/components/print-bar";

export const dynamic = "force-dynamic";

export default async function PrintReceipt({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const ctx = await getContext();
  const [receipt] = await db.select().from(receipts).where(eq(receipts.id, Number(id)));
  if (!receipt || !ctx.companyIds.includes(receipt.companyId) || !ctx.can("accounting", "view")) notFound();
  const [company] = await db.select().from(companies).where(eq(companies.id, receipt.companyId));
  const [customer] = await db.select().from(customers).where(eq(customers.id, receipt.customerId));
  return (
    <main style={{ maxWidth: 720, margin: "24px auto", background: "white", padding: 32 }}>
      <PrintBar kind="receipt" id={receipt.id} />
      <p style={{ letterSpacing: "0.14em", textTransform: "uppercase", color: company?.brandColor }}>{company?.logoText || company?.name}</p>
      <h1 style={{ fontFamily: "Georgia, serif" }}>Money receipt {receipt.number}</h1>
      <p>{company?.address}<br />{company?.phone} · {company?.email}</p>
      <p>Date {formatDate(receipt.receiptDate)}</p>
      <p>Received from <strong>{customer?.name}</strong></p>
      <p>Amount {formatBdt(receipt.amountPaisa)}</p>
      <p>Method {receipt.method} {receipt.reference ? `· Ref ${receipt.reference}` : ""}</p>
      <p>Previous balance {formatBdt(receipt.previousBalancePaisa)} · Remaining balance {formatBdt(receipt.remainingBalancePaisa)}</p>
      <p>Status: {receipt.status}{receipt.cancelReason ? ` · ${receipt.cancelReason}` : ""}</p>
      <p>Printed {receipt.printCount} time(s). Cancelled numbers are not reused.</p>
    </main>
  );
}
