import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/context";
import { loginAction } from "@/server/actions";
import { SubmitButton } from "@/components/widgets";

export const dynamic = "force-dynamic";

const companies = ["Dhaka Holiday", "GlobePath Holidays", "Dhaka Educare", "GlobePath Education", "Community Tourism", "Ethnic & Indigenous Cultural Tourism", "Nosara Traveler", "Little Wonder Co.", "The Conversation Club", "Life Profile", "AI Life Companion"];

export default async function LoginPage({ searchParams }: { searchParams: Promise<{ error?: string; notice?: string; next?: string }> }) {
  const user = await getCurrentUser();
  if (user) redirect("/dashboard");
  const sp = await searchParams;
  return (
    <main className="login">
      <section className="login-visual">
        <img src="/brand/login-desk.jpg" alt="A quiet desk with tea, a compass, and a notebook" />
        <div className="login-copy">
          <p className="kicker" style={{ color: "#f3e6c8" }}>All-in-one business management</p>
          <h1 style={{ color: "white", fontSize: "clamp(2.4rem, 5vw, 4.4rem)" }}>Every company. One calm desk.</h1>
          <p>Travel, education, tourism, shop, and office work stay in separate company workspaces, with one sign-in for the owner.</p>
          <div className="chips">{companies.map((name) => <span key={name}>{name}</span>)}</div>
        </div>
      </section>
      <section className="login-panel">
        <p className="kicker">Sign in</p>
        <h2>Welcome back</h2>
        {sp.error ? <div className="notice notice-bad">{sp.error}</div> : null}
        {sp.notice ? <div className="notice">{sp.notice}</div> : null}
        <form action={loginAction} className="fields">
          <input type="hidden" name="next" value={sp.next || "/dashboard"} />
          <label className="field full">Email<input name="email" type="email" autoComplete="username" required placeholder="owner@aiodesk.local" /></label>
          <label className="field full">Password<input name="password" type="password" autoComplete="current-password" required /></label>
          <label className="field full">Authenticator code <small>only if you turned on extra security</small><input name="code" inputMode="numeric" autoComplete="one-time-code" placeholder="6 digits" /></label>
          <SubmitButton>Sign in</SubmitButton>
        </form>
        <div className="practice">
          <strong>First sign-in for this installation</strong>
          <p>Owner: owner@aiodesk.local / Owner#2026</p>
          <p>Visa, accounts, HR, or sales practice: visa@aiodesk.local, accounts@aiodesk.local, hr@aiodesk.local, sales@aiodesk.local / Staff#2026</p>
          <p>These are starter passwords. Change them in Settings before you add real customer records. <a href="/reset">I have a reset code</a></p>
        </div>
      </section>
    </main>
  );
}
