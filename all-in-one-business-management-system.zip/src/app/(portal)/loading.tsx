export default function Loading() {
  return (
    <section>
      <p className="kicker">AIO Desk</p>
      <h1>Opening your desk…</h1>
      <p className="lede">Fetching the latest records for the selected company.</p>
    </section>
  );
}
