import { AppShell } from "@/components/shell";
import { getContext } from "@/lib/context";
import { NAV } from "@/lib/constants";
import { unreadCount } from "@/lib/queries";

export const dynamic = "force-dynamic";

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const ctx = await getContext();
  const unread = await unreadCount(ctx.user.id);
  const nav = NAV.filter((item) => {
    if (item.module === "dashboard") return true;
    if (item.module === "settings") return true;
    if (item.module === "companies") return ctx.can("companies", "view") || ctx.can("companies", "manage") || ctx.permissions.includes("*");
    if (item.module === "audit") return ctx.can("audit", "view");
    if (!ctx.can(item.module, "view")) return false;
    if (!ctx.modules.has(item.module) && item.module !== "approvals") return false;
    return true;
  }).map((item) => ({ group: item.group, href: item.href, label: item.label }));
  return (
    <AppShell
      user={{ name: ctx.user.name, role: ctx.user.roleName }}
      companies={ctx.companies.map((company) => ({ id: company.id, name: company.name, color: company.brandColor }))}
      companyId={ctx.allMode ? "all" : String(ctx.company?.id ?? "")}
      companyName={ctx.allMode ? "All companies" : ctx.company?.name || "No company"}
      brand={ctx.company?.brandColor || "#0f6e68"}
      unread={unread}
      nav={nav}
      canAll={ctx.permissions.includes("*") || ctx.can("group", "view")}
    >
      {children}
    </AppShell>
  );
}
