"use client";

export default function PortalError({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <section className="card">
      <p className="kicker">Something needs attention</p>
      <h1>This page could not be opened</h1>
      <p>{error.message || "Please try again. If it keeps happening, tell the person who looks after the system."}</p>
      <button className="btn" onClick={reset}>Try again</button>
    </section>
  );
}
