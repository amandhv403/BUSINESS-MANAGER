import { renderRoute } from "@/views/render";
import type { SearchParams } from "@/lib/types";

export const dynamic = "force-dynamic";

export default async function PortalPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string[] }>;
  searchParams: Promise<SearchParams>;
}) {
  const { slug } = await params;
  return renderRoute(slug, await searchParams);
}
