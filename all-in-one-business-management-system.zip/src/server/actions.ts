"use server";

import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { passwordResets, users } from "@/db/schema";
import { getContext } from "@/lib/context";
import { AppError } from "@/lib/errors";
import {
  assertPasswordStrength,
  createSession,
  destroySession,
  generateTotpSecret,
  hashCode,
  hashPassword,
  makeResetCode,
  rateLimit,
  setCompanyCookie,
  verifyPassword,
  verifyTotp,
  writeLoginAudit,
} from "@/lib/auth";
import { saveCustomer, saveCompany, saveGeneric, archiveGeneric, convertLead, importCustomers, saveUser, saveRole, toggleModule, uploadDocument, verifyDocument } from "@/lib/services/records";
import { saveInvoice, recordPayment, requestOrRefund, cancelReceipt, cancelInvoice, saveExpense, transferFunds, paySupplier, adjustStock } from "@/lib/services/finance";
import { saveQuotation, convertQuotation, moveStage, saveVisa, updateVisaStatus, savePassport, shopSale, saveAttendance, saveLeave, saveEmployee, savePayslip, receivePurchase, savePurchase, saveAssessment, decideApproval, saveOpportunity, returnToStock } from "@/lib/services/ops";
import type { LineInput } from "@/lib/types";
import { dateOf, intOf, safeNext, takaToPaisa, textOf, todayDhaka } from "@/lib/utils";

function go(path: string, kind: "notice" | "error", message: string): never {
  const join = path.includes("?") ? "&" : "?";
  redirect(`${path}${join}${kind}=${encodeURIComponent(message)}`);
}

async function run(path: string, work: () => Promise<unknown>, success: string) {
  try {
    await work();
  } catch (error) {
    if (error instanceof AppError) go(path, "error", error.message);
    throw error;
  }
  go(path, "notice", success);
}

function linesFrom(form: FormData): LineInput[] {
  let data: unknown;
  try {
    data = JSON.parse(String(form.get("items") || "[]"));
  } catch {
    throw new AppError("The lines could not be read. Please try again.");
  }
  if (!Array.isArray(data)) throw new AppError("Add at least one line.");
  return data.map((row) => {
    const item = row as Record<string, unknown>;
    const kind = String(item.kind || "service");
    return {
      description: String(item.description || ""),
      qty: Number(item.qty || 1),
      unitPaisa: takaToPaisa(item.unitTaka, "Price"),
      kind: (kind === "product" || kind === "third_party" ? kind : "service") as LineInput["kind"],
      productId: item.productId ? Number(item.productId) : null,
    };
  });
}

export async function loginAction(form: FormData) {
  const email = String(form.get("email") || "").trim().toLowerCase();
  const password = String(form.get("password") || "");
  const code = String(form.get("code") || "");
  try {
    const h = await headers();
    const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim() || "local";
    rateLimit(`${ip}:${email}`);
    const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
    if (!user || !user.active || !verifyPassword(password, user.passwordHash)) throw new AppError("Email or password is not correct.");
    if (user.totpEnabled && (!user.totpSecret || !verifyTotp(user.totpSecret, code))) {
      throw new AppError("Enter the 6-digit code from your authenticator app.");
    }
    await createSession(user.id);
    await writeLoginAudit(user.id, ip);
  } catch (error) {
    if (error instanceof AppError) go("/login", "error", error.message);
    throw error;
  }
  redirect(safeNext(form.get("next")));
}

export async function logoutAction() {
  await destroySession();
  redirect("/login");
}

export async function switchCompanyAction(form: FormData) {
  const ctx = await getContext();
  const value = String(form.get("companyId") || "");
  if (value === "all") {
    if (!ctx.permissions.includes("*") && !ctx.can("group", "view")) go("/dashboard", "error", "Only the owner or group administrator can open the group view.");
  } else if (!ctx.companies.some((company) => String(company.id) === value)) {
    go("/dashboard", "error", "You cannot open that company.");
  }
  await setCompanyCookie(value);
  redirect(safeNext(form.get("next")));
}

export async function saveRecordAction(form: FormData) {
  const back = String(form.get("back") || "/dashboard");
  const entity = String(form.get("entity") || "");
  await run(back, async () => {
    const ctx = await getContext();
    await saveGeneric(ctx, entity, form);
  }, "Saved.");
}

export async function archiveRecordAction(form: FormData) {
  const back = String(form.get("back") || "/dashboard");
  await run(back, async () => {
    const ctx = await getContext();
    await archiveGeneric(ctx, String(form.get("entity")), Number(form.get("id")));
  }, "Archived. The history is still kept.");
}

export async function saveCustomerAction(form: FormData) {
  await run("/crm", async () => {
    const ctx = await getContext();
    await saveCustomer(ctx, form);
  }, "Customer saved.");
}

export async function convertLeadAction(form: FormData) {
  await run("/leads", async () => {
    const ctx = await getContext();
    await convertLead(ctx, Number(form.get("id")));
  }, "Lead converted to a customer. You do not need to type their details again.");
}

export async function importCustomersAction(form: FormData) {
  const file = form.get("file");
  try {
    const ctx = await getContext();
    if (!(file instanceof File)) throw new AppError("Choose a CSV file.");
    const result = await importCustomers(ctx, await file.text());
    go("/crm", "notice", `Imported ${result.created}. Skipped ${result.skipped}. ${result.errors.slice(0, 3).join(" ")}`);
  } catch (error) {
    if (error instanceof AppError) go("/crm", "error", error.message);
    throw error;
  }
}

export async function saveCompanyAction(form: FormData) {
  await run("/companies", async () => {
    const ctx = await getContext();
    await saveCompany(ctx, form);
  }, "Company saved.");
}

export async function toggleModuleAction(form: FormData) {
  await run("/companies", async () => {
    const ctx = await getContext();
    await toggleModule(ctx, Number(form.get("companyId")), String(form.get("moduleKey")), form.get("enabled") === "on");
  }, "Module setting saved.");
}

export async function saveUserAction(form: FormData) {
  await run("/settings", async () => {
    const ctx = await getContext();
    await saveUser(ctx, form);
  }, "User saved. Ask them to change the starting password.");
}

export async function saveRoleAction(form: FormData) {
  await run("/settings", async () => {
    const ctx = await getContext();
    await saveRole(ctx, form);
  }, "Role saved.");
}

export async function changePasswordAction(form: FormData) {
  await run("/settings", async () => {
    const ctx = await getContext();
    const next = String(form.get("password") || "");
    assertPasswordStrength(next);
    const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id));
    if (!user || !verifyPassword(String(form.get("current") || ""), user.passwordHash)) throw new AppError("Current password is not correct.");
    await db.update(users).set({ passwordHash: hashPassword(next), mustChangePassword: false, updatedAt: new Date() }).where(eq(users.id, user.id));
  }, "Password changed.");
}

export async function resetCodeAction(form: FormData) {
  const ctx = await getContext();
  if (!ctx.can("settings", "manage") && !ctx.permissions.includes("*")) go("/settings", "error", "You cannot reset another person’s password.");
  const userId = Number(form.get("userId"));
  const code = makeResetCode();
  await db.insert(passwordResets).values({ userId, codeHash: hashCode(code), expiresAt: new Date(Date.now() + 2 * 60 * 60 * 1000) });
  go("/settings", "notice", `Give this one-time code to the person: ${code}. It expires in 2 hours.`);
}

export async function completeResetAction(form: FormData) {
  try {
    const email = String(form.get("email") || "").trim().toLowerCase();
    const code = String(form.get("code") || "").trim().toUpperCase();
    const password = String(form.get("password") || "");
    assertPasswordStrength(password);
    const [user] = await db.select().from(users).where(eq(users.email, email));
    if (!user) throw new AppError("That reset code is not valid.");
    const resets = await db.select().from(passwordResets).where(eq(passwordResets.userId, user.id));
    const match = resets.find((row) => !row.usedAt && row.expiresAt > new Date() && row.codeHash === hashCode(code));
    if (!match) throw new AppError("That reset code is not valid or has expired.");
    await db.update(users).set({ passwordHash: hashPassword(password), mustChangePassword: false, updatedAt: new Date() }).where(eq(users.id, user.id));
    await db.update(passwordResets).set({ usedAt: new Date() }).where(eq(passwordResets.id, match.id));
  } catch (error) {
    if (error instanceof AppError) go("/reset", "error", error.message);
    throw error;
  }
  go("/login", "notice", "Password updated. You can sign in now.");
}

export async function toggleTotpAction(form: FormData) {
  const ctx = await getContext();
  const enable = form.get("enable") === "on";
  if (!enable) {
    const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id));
    if (!user?.totpSecret || !verifyTotp(user.totpSecret, String(form.get("code") || ""))) go("/settings", "error", "Enter a current authenticator code to turn extra security off.");
    await db.update(users).set({ totpEnabled: false, totpSecret: null, updatedAt: new Date() }).where(eq(users.id, ctx.user.id));
    go("/settings", "notice", "Extra sign-in security is off.");
  }
  const secret = generateTotpSecret();
  await db.update(users).set({ totpSecret: secret, totpEnabled: false, updatedAt: new Date() }).where(eq(users.id, ctx.user.id));
  go("/settings", "notice", `Add this secret to your authenticator app, then enter a code and save again to turn it on: ${secret}`);
}

export async function confirmTotpAction(form: FormData) {
  const ctx = await getContext();
  const [user] = await db.select().from(users).where(eq(users.id, ctx.user.id));
  if (!user?.totpSecret || !verifyTotp(user.totpSecret, String(form.get("code") || ""))) go("/settings", "error", "That code did not match. Check the secret and try again.");
  await db.update(users).set({ totpEnabled: true, updatedAt: new Date() }).where(eq(users.id, ctx.user.id));
  go("/settings", "notice", "Extra sign-in security is on.");
}

export async function saveInvoiceAction(form: FormData) {
  try {
    const ctx = await getContext();
    if (!ctx.company) throw new AppError("Choose one company before creating an invoice.");
    const invoice = await saveInvoice(ctx, {
      companyId: ctx.company.id,
      customerId: Number(form.get("customerId")),
      issueDate: dateOf(form.get("issueDate"), "Invoice date") || todayDhaka(),
      dueDate: dateOf(form.get("dueDate"), "Due date"),
      lines: linesFrom(form),
      discountPaisa: takaToPaisa(form.get("discount"), "Discount"),
      notes: textOf(form.get("notes"), "Notes") || null,
      issueNow: form.get("issueNow") !== "off",
    });
    redirect(`/accounting/${invoice.id}?notice=${encodeURIComponent(invoice.status === "pending_approval" ? "Invoice saved and sent for discount approval." : "Invoice saved.")}`);
  } catch (error) {
    if (error instanceof AppError) go("/accounting", "error", error.message);
    throw error;
  }
}

export async function recordPaymentAction(form: FormData) {
  const back = String(form.get("back") || "/accounting");
  await run(back, async () => {
    const ctx = await getContext();
    if (!ctx.company) throw new AppError("Choose one company before recording money.");
    await recordPayment(ctx, {
      companyId: ctx.company.id,
      customerId: Number(form.get("customerId")),
      amountPaisa: takaToPaisa(form.get("amount"), "Amount"),
      method: textOf(form.get("method"), "Method", true, 40),
      reference: textOf(form.get("reference"), "Reference") || null,
      accountId: intOf(form.get("accountId"), "Account"),
      paidOn: dateOf(form.get("paidOn"), "Date") || todayDhaka(),
      invoiceId: intOf(form.get("invoiceId"), "Invoice"),
      allocateOldest: form.get("allocateOldest") === "on",
      notes: textOf(form.get("notes"), "Notes") || null,
      fromCredit: form.get("fromCredit") === "on",
    });
  }, "Payment recorded. The balance has been updated.");
}

export async function refundAction(form: FormData) {
  const back = String(form.get("back") || "/accounting");
  try {
    const ctx = await getContext();
    if (!ctx.company) throw new AppError("Choose one company first.");
    const result = await requestOrRefund(ctx, {
      companyId: ctx.company.id,
      customerId: Number(form.get("customerId")),
      amountPaisa: takaToPaisa(form.get("amount"), "Amount"),
      accountId: Number(form.get("accountId")),
      method: textOf(form.get("method"), "Method", true, 40),
      reference: textOf(form.get("reference"), "Reference") || null,
      invoiceId: intOf(form.get("invoiceId"), "Invoice"),
      notes: textOf(form.get("notes"), "Reason", true),
      paidOn: todayDhaka(),
    });
    go(back, "notice", result.pending ? "Refund sent for approval. Money has not been paid out yet." : "Refund recorded.");
  } catch (error) {
    if (error instanceof AppError) go(back, "error", error.message);
    throw error;
  }
}

export async function cancelReceiptAction(form: FormData) {
  const back = String(form.get("back") || "/accounting");
  try {
    const ctx = await getContext();
    const result = await cancelReceipt(ctx, Number(form.get("id")), textOf(form.get("reason"), "Reason", true));
    go(back, "notice", result.pending ? "Cancellation is waiting for approval. The number is still reserved." : "Receipt cancelled. The number will not be used again.");
  } catch (error) {
    if (error instanceof AppError) go(back, "error", error.message);
    throw error;
  }
}

export async function cancelInvoiceAction(form: FormData) {
  const back = String(form.get("back") || "/accounting");
  try {
    const ctx = await getContext();
    const result = await cancelInvoice(ctx, Number(form.get("id")), textOf(form.get("reason"), "Reason", true));
    go(back, "notice", result.pending ? "Cancellation is waiting for approval." : "Invoice cancelled. The number will not be used again.");
  } catch (error) {
    if (error instanceof AppError) go(back, "error", error.message);
    throw error;
  }
}

export async function saveExpenseAction(form: FormData) {
  try {
    const ctx = await getContext();
    if (!ctx.company) throw new AppError("Choose one company first.");
    const expense = await saveExpense(ctx, {
      companyId: ctx.company.id,
      categoryId: intOf(form.get("categoryId"), "Category"),
      supplierId: intOf(form.get("supplierId"), "Supplier"),
      description: textOf(form.get("description"), "Description", true, 300),
      spentOn: dateOf(form.get("spentOn"), "Date") || todayDhaka(),
      amountPaisa: takaToPaisa(form.get("amount"), "Amount"),
      method: textOf(form.get("method"), "Method") || "cash",
      accountId: intOf(form.get("accountId"), "Account"),
      notes: textOf(form.get("notes"), "Notes") || null,
    });
    go("/expenses", "notice", expense.status === "pending_approval" ? "Expense sent for approval." : "Expense recorded.");
  } catch (error) {
    if (error instanceof AppError) go("/expenses", "error", error.message);
    throw error;
  }
}

export async function transferAction(form: FormData) {
  await run("/cash", async () => {
    const ctx = await getContext();
    await transferFunds(ctx, {
      fromId: Number(form.get("fromId")),
      toId: Number(form.get("toId")),
      amountPaisa: takaToPaisa(form.get("amount"), "Amount"),
      date: dateOf(form.get("date"), "Date") || todayDhaka(),
      notes: textOf(form.get("notes"), "Notes") || undefined,
    });
  }, "Transfer recorded in both accounts.");
}

export async function paySupplierAction(form: FormData) {
  await run("/buying", async () => {
    const ctx = await getContext();
    await paySupplier(ctx, {
      supplierId: Number(form.get("supplierId")),
      amountPaisa: takaToPaisa(form.get("amount"), "Amount"),
      accountId: Number(form.get("accountId")),
      method: textOf(form.get("method"), "Method") || "bank",
      paidOn: dateOf(form.get("paidOn"), "Date") || todayDhaka(),
      reference: textOf(form.get("reference"), "Reference") || undefined,
      notes: textOf(form.get("notes"), "Notes") || undefined,
    });
  }, "Supplier payment recorded.");
}

export async function returnStockAction(form: FormData) {
  const back = String(form.get("back") || "/shop");
  await run(back, async () => {
    const ctx = await getContext();
    await returnToStock(ctx, Number(form.get("invoiceId")), Number(form.get("productId")), Number(form.get("qty") || 1), textOf(form.get("reason"), "Reason", true));
  }, "Item returned to stock. Refund the money separately if you are giving money back.");
}

export async function savePurchaseAction(form: FormData) {
  await run("/buying", async () => {
    const ctx = await getContext();
    await savePurchase(ctx, form);
  }, "Purchase saved.");
}

export async function receivePurchaseAction(form: FormData) {
  await run("/buying", async () => {
    const ctx = await getContext();
    await receivePurchase(ctx, Number(form.get("id")), form.get("payNow") === "on", Number(form.get("accountId") || 0) || undefined);
  }, "Goods received and stock updated.");
}

export async function stockAction(form: FormData) {
  await run("/stock", async () => {
    const ctx = await getContext();
    await adjustStock(ctx, Number(form.get("productId")), Number(form.get("qtyChange")), textOf(form.get("reason"), "Reason", true));
  }, "Stock updated.");
}

export async function saveOpportunityAction(form: FormData) {
  await run("/sales", async () => {
    const ctx = await getContext();
    await saveOpportunity(ctx, form);
  }, "Deal saved.");
}

export async function moveStageAction(form: FormData) {
  await run("/sales", async () => {
    const ctx = await getContext();
    await moveStage(ctx, Number(form.get("id")), String(form.get("stage")), String(form.get("lostReason") || ""));
  }, "Stage updated.");
}

export async function saveQuotationAction(form: FormData) {
  try {
    const ctx = await getContext();
    const id = await saveQuotation(ctx, {
      customerId: Number(form.get("customerId")),
      issueDate: dateOf(form.get("issueDate"), "Date") || todayDhaka(),
      validUntil: dateOf(form.get("validUntil"), "Valid until"),
      lines: linesFrom(form),
      discountPaisa: takaToPaisa(form.get("discount"), "Discount"),
      notes: textOf(form.get("notes"), "Notes") || undefined,
    });
    redirect(`/sales?notice=${encodeURIComponent("Quotation " + id + " saved.")}`);
  } catch (error) {
    if (error instanceof AppError) go("/sales", "error", error.message);
    throw error;
  }
}

export async function convertQuotationAction(form: FormData) {
  try {
    const ctx = await getContext();
    const invoiceId = await convertQuotation(ctx, Number(form.get("id")));
    redirect(`/accounting/${invoiceId}?notice=${encodeURIComponent("Invoice created from the quotation.")}`);
  } catch (error) {
    if (error instanceof AppError) go("/sales", "error", error.message);
    throw error;
  }
}

export async function saveVisaAction(form: FormData) {
  try {
    const ctx = await getContext();
    const id = await saveVisa(ctx, form);
    redirect(`/visa/${id}?notice=${encodeURIComponent("Visa application opened.")}`);
  } catch (error) {
    if (error instanceof AppError) go("/visa", "error", error.message);
    throw error;
  }
}

export async function visaStatusAction(form: FormData) {
  const id = Number(form.get("id"));
  await run(`/visa/${id}`, async () => {
    const ctx = await getContext();
    await updateVisaStatus(ctx, id, String(form.get("status")), textOf(form.get("note"), "Note"));
  }, "Visa status updated.");
}

export async function savePassportAction(form: FormData) {
  const back = String(form.get("back") || "/visa");
  await run(back, async () => {
    const ctx = await getContext();
    await savePassport(ctx, form);
  }, "Passport record saved. The full number is hidden in lists.");
}

export async function shopSaleAction(form: FormData) {
  try {
    const ctx = await getContext();
    let parsed: { productId: number; qty: number }[] = [];
    try {
      parsed = JSON.parse(String(form.get("lines") || "[]"));
    } catch {
      throw new AppError("The product lines could not be read.");
    }
    const result = await shopSale(ctx, {
      customerId: Number(form.get("customerId")),
      lines: parsed.filter((line) => line.qty > 0),
      discountPaisa: takaToPaisa(form.get("discount"), "Discount"),
      paidPaisa: takaToPaisa(form.get("paid"), "Paid now"),
      accountId: intOf(form.get("accountId"), "Account"),
      method: textOf(form.get("method"), "Method") || "cash",
      reference: textOf(form.get("reference"), "Reference"),
      fulfillNow: form.get("fulfillNow") !== "off",
      deliveryAddress: textOf(form.get("deliveryAddress"), "Delivery address"),
    });
    redirect(`/accounting/${result.invoiceId}?notice=${encodeURIComponent("Sale saved as " + result.number + ".")}`);
  } catch (error) {
    if (error instanceof AppError) go("/shop", "error", error.message);
    throw error;
  }
}

export async function saveAttendanceAction(form: FormData) {
  await run("/attendance", async () => {
    const ctx = await getContext();
    const workDate = dateOf(form.get("workDate"), "Date") || todayDhaka();
    const rows = form.getAll("employeeId").map((id) => ({
      employeeId: Number(id),
      status: String(form.get(`status_${id}`) || ""),
      checkIn: String(form.get(`in_${id}`) || ""),
      checkOut: String(form.get(`out_${id}`) || ""),
    }));
    await saveAttendance(ctx, workDate, rows);
  }, "Attendance saved.");
}

export async function saveLeaveAction(form: FormData) {
  await run("/leave", async () => {
    const ctx = await getContext();
    await saveLeave(ctx, form);
  }, "Leave request sent for approval.");
}

export async function saveEmployeeAction(form: FormData) {
  try {
    const ctx = await getContext();
    const id = await saveEmployee(ctx, form);
    redirect(`/people/${id}?notice=${encodeURIComponent("Employee saved.")}`);
  } catch (error) {
    if (error instanceof AppError) go("/people", "error", error.message);
    throw error;
  }
}

export async function savePayslipAction(form: FormData) {
  await run("/payroll", async () => {
    const ctx = await getContext();
    await savePayslip(ctx, form);
  }, "Payslip saved. Only HR, the owner, and the employee can see it.");
}

export async function decideApprovalAction(form: FormData) {
  await run("/approvals", async () => {
    const ctx = await getContext();
    await decideApproval(ctx, Number(form.get("id")), form.get("decision") === "rejected" ? "rejected" : "approved", textOf(form.get("comments"), "Comment"));
  }, "Decision saved.");
}

export async function uploadAction(form: FormData) {
  const back = String(form.get("back") || "/documents");
  await run(back, async () => {
    const ctx = await getContext();
    await uploadDocument(ctx, form);
  }, "File uploaded. It is not public.");
}

export async function verifyDocumentAction(form: FormData) {
  const back = String(form.get("back") || "/documents");
  await run(back, async () => {
    const ctx = await getContext();
    await verifyDocument(ctx, Number(form.get("id")), form.get("verified") === "on");
  }, "Document verification updated.");
}

export async function saveAssessmentAction(form: FormData) {
  await run("/private", async () => {
    const ctx = await getContext();
    await saveAssessment(ctx, form);
  }, "Private record saved. Only people with private-record access can open it.");
}

export async function markReadAction(form: FormData) {
  const ctx = await getContext();
  const { notifications } = await import("@/db/schema");
  const { eq, and, isNull } = await import("drizzle-orm");
  if (form.get("id")) {
    await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.id, Number(form.get("id"))), eq(notifications.userId, ctx.user.id)));
  } else {
    await db.update(notifications).set({ readAt: new Date() }).where(and(eq(notifications.userId, ctx.user.id), isNull(notifications.readAt)));
  }
  redirect("/notifications");
}

export async function printLogAction(kind: string, id: number) {
  const ctx = await getContext();
  const { audit } = await import("@/lib/audit");
  const { receipts } = await import("@/db/schema");
  const { sql } = await import("drizzle-orm");
  await audit(db, ctx, "print", kind, id, { at: new Date().toISOString() });
  if (kind === "receipt") {
    await db.update(receipts).set({ printCount: sql`${receipts.printCount} + 1` }).where(eq(receipts.id, id));
  }
}
