"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { logoutAction, switchCompanyAction } from "@/server/actions";

type NavItem = { group: string; href: string; label: string };

export function AppShell({
  user,
  companies,
  companyId,
  companyName,
  brand,
  unread,
  nav,
  canAll,
  children,
}: {
  user: { name: string; role: string };
  companies: { id: number; name: string; color: string }[];
  companyId: string;
  companyName: string;
  brand: string;
  unread: number;
  nav: NavItem[];
  canAll: boolean;
  children: React.ReactNode;
}) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const groups = [...new Set(nav.map((item) => item.group))];
  return (
    <div className="shell" style={{ ["--brand" as string]: brand }}>
      <aside className={open ? "sidebar open" : "sidebar"}>
        <div className="brand">
          <div className="mark">A</div>
          <div>
            <strong>AIO Desk</strong>
            <small>All companies, one place</small>
          </div>
        </div>
        <nav className="nav">
          {groups.map((group) => (
            <div key={group}>
              <div className="nav-group">{group}</div>
              {nav.filter((item) => item.group === group).map((item) => (
                <Link key={item.href} href={item.href} className={path === item.href || path.startsWith(item.href + "/") ? "active" : ""} onClick={() => setOpen(false)}>
                  {item.label}
                </Link>
              ))}
            </div>
          ))}
        </nav>
        <div className="side-user">
          <strong>{user.name}</strong>
          <span>{user.role}</span>
          <form action={logoutAction}><button className="btn-ghost" style={{ marginTop: 8, color: "white", borderColor: "rgba(255,255,255,.2)" }}>Sign out</button></form>
        </div>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <button className="menu-btn" type="button" onClick={() => setOpen((v) => !v)}>Menu</button>
          <form className="top-search" action="/search">
            <input name="q" placeholder="Search customers, invoices, visa files" aria-label="Search" />
            <button className="btn" type="submit">Search</button>
          </form>
          <form action={switchCompanyAction} className="company-select">
            <input type="hidden" name="next" value={path} />
            <select name="companyId" defaultValue={companyId} aria-label="Selected company" onChange={(e) => e.currentTarget.form?.requestSubmit()}>
              {canAll ? <option value="all">All companies</option> : null}
              {companies.map((company) => (
                <option key={company.id} value={company.id}>{company.name}</option>
              ))}
            </select>
          </form>
          <Link className="icon-btn bell" href="/notifications" aria-label="Notifications">
            Alerts {unread > 0 ? <em>{unread}</em> : null}
          </Link>
        </header>
        <main className="content">
          <p className="muted" style={{ marginTop: 0 }}>Working in <strong>{companyName}</strong></p>
          {children}
        </main>
      </div>
    </div>
  );
}
