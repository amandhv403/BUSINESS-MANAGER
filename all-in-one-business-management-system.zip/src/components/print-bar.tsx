"use client";

import { useEffect } from "react";
import { printLogAction } from "@/server/actions";

export function PrintBar({ kind, id }: { kind: string; id: number }) {
  useEffect(() => {
    printLogAction(kind, id).catch(() => undefined);
  }, [kind, id]);
  return <button className="btn no-print" onClick={() => window.print()}>Print or save as PDF</button>;
}
