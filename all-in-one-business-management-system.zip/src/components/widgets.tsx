"use client";

import { useMemo, useState } from "react";
import { useFormStatus } from "react-dom";

export function SubmitButton({ children, danger = false }: { children: React.ReactNode; danger?: boolean }) {
  const { pending } = useFormStatus();
  return <button className={danger ? "btn-danger" : "btn"} disabled={pending}>{pending ? "Saving..." : children}</button>;
}

export function ConfirmButton({ children, message }: { children: React.ReactNode; message: string }) {
  const { pending } = useFormStatus();
  return (
    <button className="btn-danger" disabled={pending} onClick={(event) => { if (!confirm(message)) event.preventDefault(); }}>
      {pending ? "Working..." : children}
    </button>
  );
}

type Line = { description: string; qty: number; unitTaka: string; kind: string };

export function LineItems() {
  const [rows, setRows] = useState<Line[]>([{ description: "", qty: 1, unitTaka: "", kind: "service" }]);
  const subtotal = useMemo(() => rows.reduce((sum, row) => sum + Number(row.qty || 0) * Number(row.unitTaka || 0), 0), [rows]);
  function update(index: number, patch: Partial<Line>) {
    setRows((current) => current.map((row, i) => (i === index ? { ...row, ...patch } : row)));
  }
  return (
    <div className="field full">
      <span>Lines</span>
      {rows.map((row, index) => (
        <div key={index} className="fields" style={{ marginBottom: 8 }}>
          <label className="field full">Description<input value={row.description} onChange={(e) => update(index, { description: e.target.value })} placeholder="Visa service fee" /></label>
          <label className="field">Qty<input type="number" min={1} value={row.qty} onChange={(e) => update(index, { qty: Number(e.target.value) })} /></label>
          <label className="field">Price in taka<input inputMode="decimal" value={row.unitTaka} onChange={(e) => update(index, { unitTaka: e.target.value })} placeholder="5000" /></label>
          <label className="field">Type
            <select value={row.kind} onChange={(e) => update(index, { kind: e.target.value })}>
              <option value="service">Our service fee</option>
              <option value="product">Product</option>
              <option value="third_party">Third-party money, not our income</option>
            </select>
          </label>
        </div>
      ))}
      <button type="button" className="btn-ghost" onClick={() => setRows((rows) => [...rows, { description: "", qty: 1, unitTaka: "", kind: "service" }])}>Add another line</button>
      <small>Subtotal before tax and discount: ৳{subtotal.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</small>
      <input type="hidden" name="items" value={JSON.stringify(rows)} />
    </div>
  );
}

export function ShopLines({ products }: { products: { id: number; name: string; sku: string; salePaisa: number; stockQty: number }[] }) {
  const [rows, setRows] = useState([{ productId: products[0]?.id ?? 0, qty: 1 }]);
  const total = rows.reduce((sum, row) => {
    const product = products.find((item) => item.id === Number(row.productId));
    return sum + (product ? (product.salePaisa / 100) * Number(row.qty || 0) : 0);
  }, 0);
  return (
    <div className="field full">
      <span>Products</span>
      {rows.map((row, index) => (
        <div key={index} className="fields" style={{ marginBottom: 8 }}>
          <label className="field">Product
            <select value={row.productId} onChange={(e) => setRows((current) => current.map((item, i) => i === index ? { ...item, productId: Number(e.target.value) } : item))}>
              {products.map((product) => <option key={product.id} value={product.id}>{product.name} · {product.sku} · stock {product.stockQty}</option>)}
            </select>
          </label>
          <label className="field">Qty<input type="number" min={1} value={row.qty} onChange={(e) => setRows((current) => current.map((item, i) => i === index ? { ...item, qty: Number(e.target.value) } : item))} /></label>
        </div>
      ))}
      <button type="button" className="btn-ghost" onClick={() => setRows((current) => [...current, { productId: products[0]?.id ?? 0, qty: 1 }])}>Add product</button>
      <small>Sale total before discount: ৳{total.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</small>
      <input type="hidden" name="lines" value={JSON.stringify(rows)} />
    </div>
  );
}
