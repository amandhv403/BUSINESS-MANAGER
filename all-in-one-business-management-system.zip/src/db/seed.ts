import "dotenv/config";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import {
  approvals,
  companies,
  countries,
  customers,
  employees,
  expenses,
  invoices,
  leads,
  moneyAccounts,
  passports,
  products,
  roles,
  sampleMarkers,
  services,
  sessionBookings,
  students,
  tasks,
  universities,
  userCompanies,
  users,
  visaApplications,
  visaCategories,
  visaStatusHistory,
} from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { rolePresets } from "@/lib/constants";
import type { Ctx } from "@/lib/types";
import { todayDhaka } from "@/lib/utils";
import { openingBalance } from "@/lib/services/finance";
import { provisionCompany } from "@/lib/services/records";
import { saveInvoice, recordPayment, saveExpense } from "@/lib/services/finance";

async function main() {
  const existing = await db.select({ id: users.id }).from(users).limit(1);
  if (existing.length) {
    console.log("Seed skipped: users already exist.");
    return;
  }
  const presets = rolePresets();
  const roleRows = await db.insert(roles).values(Object.entries(presets).map(([key, role]) => ({
    key,
    name: role.name,
    description: role.description,
    isSystem: true,
    permissions: role.permissions,
  }))).returning();
  const roleId = (key: string) => roleRows.find((role) => role.key === key)!.id;

  const companySeed = [
    ["Dhaka Holiday", "DH", "travel", "#0f6e68", "Visa, tickets, and tours from Dhaka."],
    ["GlobePath Holidays", "GPH", "travel", "#1d4e89", "Travel packages and immigration support."],
    ["Dhaka Educare", "DE", "education", "#7a4e2d", "Study-abroad counselling."],
    ["GlobePath Education", "GPE", "education", "#3d4f8a", "University applications and student visas."],
    ["Community Tourism", "CT", "tourism", "#2f6b3a", "Agro-tourism and homestay projects."],
    ["Ethnic & Indigenous Cultural Tourism", "EIT", "tourism", "#8a4b2f", "Cultural experiences with community partners."],
    ["Nosara Traveler", "NT", "travel", "#1f6f78", "Stays, hosts, and experience enquiries."],
    ["Little Wonder Co.", "LW", "ecommerce", "#c46b4a", "Baby and children's products."],
    ["The Conversation Club", "TCC", "services", "#6b4c7a", "Sessions and memberships."],
    ["Life Profile", "LP", "assessment", "#3f5c4b", "Questionnaires and recommendations."],
    ["AI Life Companion", "ALC", "companion", "#245c6b", "Companion service records and consent."],
  ] as const;

  const companyRows: (typeof companies.$inferSelect)[] = [];
  for (const [name, shortName, businessType, brandColor, notes] of companySeed) {
    const [company] = await db.insert(companies).values({
      name,
      shortName,
      businessType,
      brandColor,
      accentColor: "#a78445",
      city: name.includes("Nosara") ? "Nosara" : "Dhaka",
      address: "Sample office, Gulshan, Dhaka",
      phone: "01700000000",
      email: `${shortName.toLowerCase()}@aiodesk.local`,
      logoText: shortName,
      invoicePrefix: `${shortName}-INV`,
      receiptPrefix: `${shortName}-RCT`,
      quotationPrefix: `${shortName}-QT`,
      notes,
      financialYearStart: "07-01",
    }).returning();
    await db.transaction(async (tx) => provisionCompany(tx as never, company));
    companyRows.push(company);
    await db.insert(sampleMarkers).values({ entity: "company", entityId: company.id });
  }

  const ownerHash = hashPassword("Owner#2026");
  const staffHash = hashPassword("Staff#2026");
  const [owner] = await db.insert(users).values({
    name: "Amina Rahman",
    email: "owner@aiodesk.local",
    passwordHash: ownerHash,
    roleId: roleId("super_admin"),
    extraPermissions: [],
    deniedPermissions: [],
    mustChangePassword: true,
    phone: "01700000001",
  }).returning();
  const staff = [
    ["Imran Hossain", "visa@aiodesk.local", "visa_officer"],
    ["Tanvir Ahmed", "accounts@aiodesk.local", "accounts"],
    ["Laila Chowdhury", "hr@aiodesk.local", "hr"],
    ["Rafiq Mahmud", "sales@aiodesk.local", "sales"],
    ["Rita Sen", "auditor@aiodesk.local", "auditor"],
  ] as const;
  const staffRows = [];
  for (const [name, email, role] of staff) {
    const [user] = await db.insert(users).values({
      name,
      email,
      passwordHash: staffHash,
      roleId: roleId(role),
      extraPermissions: [],
      deniedPermissions: [],
      mustChangePassword: true,
    }).returning();
    staffRows.push(user);
  }
  await db.insert(userCompanies).values(companyRows.map((company, index) => ({ userId: owner.id, companyId: company.id, isDefault: index === 0 })));
  const visaUser = staffRows[0];
  const accountsUser = staffRows[1];
  const hrUser = staffRows[2];
  const salesUser = staffRows[3];
  for (const company of companyRows.filter((c) => ["DH", "GPH"].includes(c.shortName))) {
    await db.insert(userCompanies).values({ userId: visaUser.id, companyId: company.id, isDefault: company.shortName === "DH" });
  }
  for (const company of companyRows) {
    await db.insert(userCompanies).values({ userId: accountsUser.id, companyId: company.id, isDefault: company.shortName === "DH" });
    await db.insert(userCompanies).values({ userId: hrUser.id, companyId: company.id, isDefault: company.shortName === "DH" });
  }
  await db.insert(userCompanies).values({ userId: salesUser.id, companyId: companyRows[0].id, isDefault: true });
  await db.insert(userCompanies).values({ userId: staffRows[4].id, companyId: companyRows[0].id, isDefault: true });

  const dh = companyRows[0];
  const educare = companyRows[2];
  const wonder = companyRows[7];
  const club = companyRows[8];
  const tourism = companyRows[4];

  function ctxFor(user: typeof owner, company: typeof dh): Ctx {
    return {
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        roleId: user.roleId,
        roleKey: "super_admin",
        roleName: "Owner",
        permissions: ["*"],
        employeeId: user.employeeId,
        active: true,
        totpEnabled: false,
        phone: user.phone,
      },
      companies: companyRows.map((c) => ({
        id: c.id,
        name: c.name,
        shortName: c.shortName,
        businessType: c.businessType,
        brandColor: c.brandColor,
        accentColor: c.accentColor,
        city: c.city,
        currency: c.currency,
        taxName: c.taxName,
        taxRateBps: c.taxRateBps,
        address: c.address,
        phone: c.phone,
        email: c.email,
        logoText: c.logoText,
        invoicePrefix: c.invoicePrefix,
        receiptPrefix: c.receiptPrefix,
        active: c.active,
      })),
      company: {
        id: company.id,
        name: company.name,
        shortName: company.shortName,
        businessType: company.businessType,
        brandColor: company.brandColor,
        accentColor: company.accentColor,
        city: company.city,
        currency: company.currency,
        taxName: company.taxName,
        taxRateBps: company.taxRateBps,
        address: company.address,
        phone: company.phone,
        email: company.email,
        logoText: company.logoText,
        invoicePrefix: company.invoicePrefix,
        receiptPrefix: company.receiptPrefix,
        active: company.active,
      },
      companyIds: [company.id],
      allMode: false,
      modules: new Set(["crm", "sales", "accounting", "visa", "travel", "education", "ecommerce", "hrm", "payroll", "office", "support", "bookings", "tourism"]),
      branchId: null,
      permissions: ["*"],
      can: () => true,
      ip: "seed",
    };
  }
  const ctx = ctxFor(owner, dh);
  const [employee] = await db.insert(employees).values({
    companyId: dh.id,
    employeeCode: "DH-E-0001",
    name: "Imran Hossain",
    designation: "Visa officer",
    status: "active",
    salaryPaisa: 4500000,
    joiningDate: "2024-01-15",
    phone: "01700000011",
    email: "visa@aiodesk.local",
  }).returning();
  await db.update(users).set({ employeeId: employee.id }).where(eq(users.id, visaUser.id));
  await numberSequencesSafe(dh.id);

  const countryRows = await db.insert(countries).values([
    ["Malaysia", "MY", "Asia"],
    ["Thailand", "TH", "Asia"],
    ["United Arab Emirates", "AE", "Middle East"],
    ["United Kingdom", "GB", "Europe"],
    ["Canada", "CA", "North America"],
    ["Saudi Arabia", "SA", "Middle East"],
    ["India", "IN", "Asia"],
    ["Singapore", "SG", "Asia"],
  ].map(([name, code, region]) => ({ name, code, region }))).returning();
  await db.insert(visaCategories).values(countryRows.slice(0, 4).map((country) => ({
    countryId: country.id,
    name: "Tourist",
    requirements: "Passport, photo, bank statement, travel plan. Confirm the latest embassy list before submission.",
    checklist: ["Passport", "Photo", "Bank statement", "Travel plan"],
    processingDays: 15,
  })));

  const [customer] = await db.insert(customers).values({
    companyId: dh.id,
    customerCode: "DH-C-0001",
    name: "Nusrat Karim",
    phone: "01800000021",
    email: "nusrat.sample@example.com",
    source: "Facebook",
    category: "Family",
    status: "active",
    assignedUserId: salesUser.id,
    nationality: "Bangladeshi",
    notes: "Sample customer for learning the screens.",
    createdBy: owner.id,
  }).returning();
  const [lead] = await db.insert(leads).values({
    companyId: dh.id,
    name: "Karim Uddin",
    phone: "01900000022",
    source: "Walk-in",
    status: "follow-up",
    interestedService: "Malaysia tourist visa",
    assignedUserId: salesUser.id,
    createdBy: owner.id,
  }).returning();
  await db.insert(sampleMarkers).values([{ entity: "customer", entityId: customer.id }, { entity: "lead", entityId: lead.id }]);

  const cash = (await db.select().from(moneyAccounts).where(eq(moneyAccounts.companyId, dh.id))).find((a) => a.accountType === "cash");
  if (!cash) throw new Error("Cash account missing");
  await openingBalance(db, ctx, cash.id, 20000000, todayDhaka());

  const invoice = await saveInvoice(ctx, {
    companyId: dh.id,
    customerId: customer.id,
    issueDate: todayDhaka(),
    dueDate: todayDhaka(),
    lines: [
      { description: "Malaysia tourist visa service fee", qty: 1, unitPaisa: 800000, kind: "service" },
      { description: "Embassy fee collected for the client", qty: 1, unitPaisa: 1200000, kind: "third_party" },
    ],
    discountPaisa: 0,
    notes: "Sample invoice. Service fee is our income. Embassy fee is third-party money.",
    issueNow: true,
  });
  await recordPayment(ctx, {
    companyId: dh.id,
    customerId: customer.id,
    amountPaisa: 800000,
    method: "bkash",
    reference: "SAMPLE-BKASH-1001",
    accountId: cash.id,
    paidOn: todayDhaka(),
    invoiceId: invoice.id,
    notes: "Sample partial payment",
  });
  await saveExpense(ctx, {
    companyId: dh.id,
    description: "Sample office tea and stationery",
    spentOn: todayDhaka(),
    amountPaisa: 75000,
    method: "cash",
    accountId: cash.id,
  });
  const [passport] = await db.insert(passports).values({
    companyId: dh.id,
    customerId: customer.id,
    passportNo: "A00000021",
    nationality: "Bangladeshi",
    expiryDate: "2026-08-20",
  }).returning();
  const [visa] = await db.insert(visaApplications).values({
    companyId: dh.id,
    applicationCode: "DH-V-0001",
    customerId: customer.id,
    passportId: passport.id,
    countryId: countryRows[0].id,
    purpose: "Family tour",
    applicationDate: todayDhaka(),
    appointmentDate: todayDhaka(),
    embassy: "High Commission of Malaysia, Dhaka",
    status: "documents pending",
    assignedUserId: visaUser.id,
    checklist: { Passport: true, Photo: false },
    createdBy: owner.id,
  }).returning();
  await db.insert(visaStatusHistory).values({ applicationId: visa.id, toStatus: "documents pending", note: "Photo still needed", userId: owner.id });
  await db.insert(tasks).values({ companyId: dh.id, title: "Call Nusrat about the missing photo", dueOn: todayDhaka(), priority: "high", status: "open", assignedUserId: visaUser.id, createdBy: owner.id });
  await db.insert(services).values({ companyId: dh.id, name: "Tourist visa processing", category: "Visa", pricePaisa: 800000, description: "Sample service price. Edit before real use." });

  await db.insert(students).values({ companyId: educare.id, name: "Sample Student — Farhana", phone: "01600000031", preferredCountry: "Canada", preferredCourse: "Business", status: "counselling", createdBy: owner.id });
  await db.insert(universities).values({ name: "University of Toronto", country: "Canada", city: "Toronto", website: "https://www.utoronto.ca", notes: "Starter reference. Confirm requirements yourself." });
  const [toy] = await db.insert(products).values({ companyId: wonder.id, sku: "LW-TOY-01", name: "Sample wooden animal set", category: "Educational toys", purchasePaisa: 90000, salePaisa: 160000, stockQty: 3, reorderLevel: 5, description: "Sample product. Stock is intentionally low." }).returning();
  await db.insert(sessionBookings).values({ companyId: club.id, title: "Sample conversation session", sessionType: "session", startAt: new Date(), durationMin: 60, providerName: "Club host", status: "booked", amountPaisa: 150000, createdBy: owner.id });
  await db.insert(tasks).values({ companyId: tourism.id, title: "Sample homestay visit", details: "Community Tourism starter task. Replace with a real project.", dueOn: todayDhaka(), priority: "normal", status: "open", createdBy: owner.id });
  await db.insert(approvals).values({ companyId: dh.id, type: "leave", entity: "leave", status: "pending", requesterId: visaUser.id, reason: "Sample leave request waiting for a decision.", payload: { sample: true } });

  const [check] = await db.select().from(invoices).where(eq(invoices.id, invoice.id));
  if (!check || check.paidPaisa !== 800000 || check.duePaisa !== 1200000 || check.status !== "partial") {
    throw new Error(`Sample payment did not balance. paid=${check?.paidPaisa} due=${check?.duePaisa} status=${check?.status}`);
  }
  const sequences = await db.select().from(customers);
  console.log(`Seed complete. Owner owner@aiodesk.local / Owner#2026. Customers: ${sequences.length}. Invoice ${check.number} due ${check.duePaisa}. Product ${toy.sku}.`);
}

async function numberSequencesSafe(companyId: number) {
  const { numberSequences } = await import("@/db/schema");
  const { sql } = await import("drizzle-orm");
  await db.execute(sql`update number_sequences set next_number = 2 where company_id = ${companyId} and doc_type in ('customer','employee','visa')`);
}

main().then(() => process.exit(0)).catch((error) => {
  console.error(error);
  process.exit(1);
});
