import {
  bigint,
  boolean,
  date,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

function ts() {
  return {
    createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
    updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  };
}

function money(name: string) {
  return bigint(name, { mode: "number" }).notNull().default(0);
}

export const companies = pgTable("companies", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull(),
  businessType: text("business_type").notNull(),
  registrationNo: text("registration_no"),
  address: text("address"),
  city: text("city"),
  phone: text("phone"),
  email: text("email"),
  website: text("website"),
  logoText: text("logo_text"),
  brandColor: text("brand_color").notNull().default("#0f6e68"),
  accentColor: text("accent_color").notNull().default("#a78445"),
  invoicePrefix: text("invoice_prefix").notNull().default("INV"),
  receiptPrefix: text("receipt_prefix").notNull().default("RCT"),
  quotationPrefix: text("quotation_prefix").notNull().default("QT"),
  financialYearStart: text("financial_year_start").notNull().default("07-01"),
  currency: text("currency").notNull().default("BDT"),
  taxName: text("tax_name").notNull().default("VAT"),
  taxRateBps: integer("tax_rate_bps").notNull().default(0),
  active: boolean("active").notNull().default(true),
  notes: text("notes"),
  ...ts(),
}, (t) => [uniqueIndex("companies_short_name_uq").on(t.shortName)]);

export const branches = pgTable("branches", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  address: text("address"),
  phone: text("phone"),
  managerEmployeeId: integer("manager_employee_id"),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const departments = pgTable("departments", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  branchId: integer("branch_id"),
  name: text("name").notNull(),
  managerEmployeeId: integer("manager_employee_id"),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const teams = pgTable("teams", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  departmentId: integer("department_id"),
  name: text("name").notNull(),
  leadEmployeeId: integer("lead_employee_id"),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const teamMembers = pgTable("team_members", {
  teamId: integer("team_id").notNull().references(() => teams.id, { onDelete: "cascade" }),
  employeeId: integer("employee_id").notNull(),
}, (t) => [primaryKey({ columns: [t.teamId, t.employeeId] })]);

export const roles = pgTable("roles", {
  id: serial("id").primaryKey(),
  key: text("key").notNull(),
  name: text("name").notNull(),
  description: text("description"),
  isSystem: boolean("is_system").notNull().default(false),
  permissions: jsonb("permissions").$type<string[]>().notNull(),
  ...ts(),
}, (t) => [uniqueIndex("roles_key_uq").on(t.key)]);

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  passwordHash: text("password_hash").notNull(),
  roleId: integer("role_id").notNull().references(() => roles.id),
  employeeId: integer("employee_id"),
  phone: text("phone"),
  active: boolean("active").notNull().default(true),
  extraPermissions: jsonb("extra_permissions").$type<string[]>().notNull(),
  deniedPermissions: jsonb("denied_permissions").$type<string[]>().notNull(),
  totpSecret: text("totp_secret"),
  totpEnabled: boolean("totp_enabled").notNull().default(false),
  mustChangePassword: boolean("must_change_password").notNull().default(false),
  lastLoginAt: timestamp("last_login_at", { withTimezone: true }),
  ...ts(),
}, (t) => [uniqueIndex("users_email_uq").on(t.email)]);

export const sessions = pgTable("sessions", {
  id: text("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const passwordResets = pgTable("password_resets", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  codeHash: text("code_hash").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  usedAt: timestamp("used_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const userCompanies = pgTable("user_companies", {
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  companyId: integer("company_id").notNull().references(() => companies.id, { onDelete: "cascade" }),
  branchId: integer("branch_id"),
  isDefault: boolean("is_default").notNull().default(false),
  permissions: jsonb("permissions").$type<string[] | null>(),
}, (t) => [primaryKey({ columns: [t.userId, t.companyId] })]);

export const companyModules = pgTable("company_modules", {
  companyId: integer("company_id").notNull().references(() => companies.id, { onDelete: "cascade" }),
  moduleKey: text("module_key").notNull(),
  enabled: boolean("enabled").notNull().default(true),
}, (t) => [primaryKey({ columns: [t.companyId, t.moduleKey] })]);

export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export const employees = pgTable("employees", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  branchId: integer("branch_id"),
  departmentId: integer("department_id"),
  employeeCode: text("employee_code").notNull(),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  designation: text("designation"),
  joiningDate: date("joining_date", { mode: "string" }),
  status: text("status").notNull().default("active"),
  managerId: integer("manager_id"),
  salaryPaisa: money("salary_paisa"),
  commissionRateBps: integer("commission_rate_bps").notNull().default(0),
  shiftId: integer("shift_id"),
  nid: text("nid"),
  address: text("address"),
  bankAccount: text("bank_account"),
  notes: text("notes"),
  ...ts(),
}, (t) => [uniqueIndex("employees_code_uq").on(t.companyId, t.employeeCode)]);

export const shifts = pgTable("shifts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  graceMinutes: integer("grace_minutes").notNull().default(10),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const holidays = pgTable("holidays", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  holidayOn: date("holiday_on", { mode: "string" }).notNull(),
  notes: text("notes"),
  ...ts(),
});

export const attendance = pgTable("attendance", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  employeeId: integer("employee_id").notNull().references(() => employees.id),
  workDate: date("work_date", { mode: "string" }).notNull(),
  status: text("status").notNull(),
  checkIn: text("check_in"),
  checkOut: text("check_out"),
  notes: text("notes"),
  markedBy: integer("marked_by"),
  ...ts(),
}, (t) => [uniqueIndex("attendance_day_uq").on(t.employeeId, t.workDate)]);

export const leaveRequests = pgTable("leave_requests", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  employeeId: integer("employee_id").notNull().references(() => employees.id),
  leaveType: text("leave_type").notNull(),
  startDate: date("start_date", { mode: "string" }).notNull(),
  endDate: date("end_date", { mode: "string" }).notNull(),
  reason: text("reason"),
  status: text("status").notNull().default("pending"),
  approverId: integer("approver_id"),
  decisionNote: text("decision_note"),
  ...ts(),
});

export const payslips = pgTable("payslips", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  employeeId: integer("employee_id").notNull().references(() => employees.id),
  periodKey: text("period_key").notNull(),
  basicPaisa: money("basic_paisa"),
  allowancesPaisa: money("allowances_paisa"),
  deductionsPaisa: money("deductions_paisa"),
  bonusPaisa: money("bonus_paisa"),
  commissionPaisa: money("commission_paisa"),
  advancePaisa: money("advance_paisa"),
  netPaisa: money("net_paisa"),
  status: text("status").notNull().default("draft"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const employeeEvents = pgTable("employee_events", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  employeeId: integer("employee_id").notNull().references(() => employees.id),
  eventType: text("event_type").notNull(),
  eventDate: date("event_date", { mode: "string" }).notNull(),
  amountPaisa: money("amount_paisa"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  employeeId: integer("employee_id").notNull().references(() => employees.id),
  periodKey: text("period_key").notNull(),
  rating: integer("rating").notNull().default(3),
  strengths: text("strengths"),
  improvements: text("improvements"),
  reviewerId: integer("reviewer_id"),
  status: text("status").notNull().default("draft"),
  ...ts(),
});

export const customers = pgTable("customers", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerCode: text("customer_code").notNull(),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  address: text("address"),
  category: text("category").notNull().default("general"),
  source: text("source"),
  status: text("status").notNull().default("active"),
  assignedUserId: integer("assigned_user_id"),
  creditPaisa: money("credit_paisa"),
  notes: text("notes"),
  nationality: text("nationality"),
  occupation: text("occupation"),
  verificationStatus: text("verification_status").notNull().default("verified"),
  createdBy: integer("created_by"),
  ...ts(),
}, (t) => [uniqueIndex("customers_code_uq").on(t.companyId, t.customerCode)]);

export const customerCompanies = pgTable("customer_companies", {
  customerId: integer("customer_id").notNull().references(() => customers.id, { onDelete: "cascade" }),
  companyId: integer("company_id").notNull().references(() => companies.id, { onDelete: "cascade" }),
  relationship: text("relationship").notNull().default("customer"),
}, (t) => [primaryKey({ columns: [t.customerId, t.companyId] })]);

export const leads = pgTable("leads", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  source: text("source").notNull().default("other"),
  status: text("status").notNull().default("new"),
  interestedService: text("interested_service"),
  assignedUserId: integer("assigned_user_id"),
  campaignId: integer("campaign_id"),
  customerId: integer("customer_id"),
  notes: text("notes"),
  lostReason: text("lost_reason"),
  verificationStatus: text("verification_status").notNull().default("verified"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id"),
  leadId: integer("lead_id"),
  activityType: text("activity_type").notNull(),
  summary: text("summary").notNull(),
  body: text("body"),
  userId: integer("user_id"),
  happenedAt: timestamp("happened_at", { withTimezone: true }).defaultNow().notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const followUps = pgTable("follow_ups", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id"),
  leadId: integer("lead_id"),
  dueOn: date("due_on", { mode: "string" }).notNull(),
  assignedUserId: integer("assigned_user_id"),
  status: text("status").notNull().default("open"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  category: text("category"),
  pricePaisa: money("price_paisa"),
  durationMin: integer("duration_min"),
  description: text("description"),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  sku: text("sku").notNull(),
  name: text("name").notNull(),
  category: text("category"),
  variant: text("variant"),
  purchasePaisa: money("purchase_paisa"),
  salePaisa: money("sale_paisa"),
  stockQty: integer("stock_qty").notNull().default(0),
  reorderLevel: integer("reorder_level").notNull().default(5),
  description: text("description"),
  active: boolean("active").notNull().default(true),
  ...ts(),
}, (t) => [uniqueIndex("products_sku_uq").on(t.companyId, t.sku)]);

export const stockMovements = pgTable("stock_movements", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  productId: integer("product_id").notNull().references(() => products.id),
  movementType: text("movement_type").notNull(),
  qty: integer("qty").notNull(),
  reference: text("reference"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const pipelineStages = pgTable("pipeline_stages", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  sortOrder: integer("sort_order").notNull().default(0),
  isWon: boolean("is_won").notNull().default(false),
  isLost: boolean("is_lost").notNull().default(false),
});

export const opportunities = pgTable("opportunities", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id"),
  leadId: integer("lead_id"),
  campaignId: integer("campaign_id"),
  title: text("title").notNull(),
  stage: text("stage").notNull().default("New lead"),
  valuePaisa: money("value_paisa"),
  probability: integer("probability").notNull().default(20),
  assignedUserId: integer("assigned_user_id"),
  expectedClose: date("expected_close", { mode: "string" }),
  lostReason: text("lost_reason"),
  serviceId: integer("service_id"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const quotations = pgTable("quotations", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  number: text("number").notNull(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  opportunityId: integer("opportunity_id"),
  status: text("status").notNull().default("draft"),
  issueDate: date("issue_date", { mode: "string" }).notNull(),
  validUntil: date("valid_until", { mode: "string" }),
  subtotalPaisa: money("subtotal_paisa"),
  discountPaisa: money("discount_paisa"),
  taxPaisa: money("tax_paisa"),
  totalPaisa: money("total_paisa"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
}, (t) => [uniqueIndex("quotations_number_uq").on(t.companyId, t.number)]);

export const quotationItems = pgTable("quotation_items", {
  id: serial("id").primaryKey(),
  quotationId: integer("quotation_id").notNull().references(() => quotations.id, { onDelete: "cascade" }),
  description: text("description").notNull(),
  qty: integer("qty").notNull().default(1),
  unitPaisa: money("unit_paisa"),
  lineTotalPaisa: money("line_total_paisa"),
  kind: text("kind").notNull().default("service"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const invoices = pgTable("invoices", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  number: text("number").notNull(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  quotationId: integer("quotation_id"),
  salesOrderId: integer("sales_order_id"),
  status: text("status").notNull().default("issued"),
  issueDate: date("issue_date", { mode: "string" }).notNull(),
  dueDate: date("due_date", { mode: "string" }),
  subtotalPaisa: money("subtotal_paisa"),
  discountPaisa: money("discount_paisa"),
  taxPaisa: money("tax_paisa"),
  totalPaisa: money("total_paisa"),
  paidPaisa: money("paid_paisa"),
  duePaisa: money("due_paisa"),
  servicePaisa: money("service_paisa"),
  productPaisa: money("product_paisa"),
  thirdPartyPaisa: money("third_party_paisa"),
  fulfillmentStatus: text("fulfillment_status"),
  deliveryAddress: text("delivery_address"),
  notes: text("notes"),
  cancelReason: text("cancel_reason"),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  createdBy: integer("created_by"),
  ...ts(),
}, (t) => [uniqueIndex("invoices_number_uq").on(t.companyId, t.number)]);

export const invoiceItems = pgTable("invoice_items", {
  id: serial("id").primaryKey(),
  invoiceId: integer("invoice_id").notNull().references(() => invoices.id, { onDelete: "cascade" }),
  description: text("description").notNull(),
  qty: integer("qty").notNull().default(1),
  unitPaisa: money("unit_paisa"),
  discountPaisa: money("discount_paisa"),
  taxPaisa: money("tax_paisa"),
  lineTotalPaisa: money("line_total_paisa"),
  kind: text("kind").notNull().default("service"),
  productId: integer("product_id"),
  serviceId: integer("service_id"),
  sortOrder: integer("sort_order").notNull().default(0),
});

export const receipts = pgTable("receipts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  number: text("number").notNull(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  invoiceId: integer("invoice_id"),
  receiptDate: date("receipt_date", { mode: "string" }).notNull(),
  amountPaisa: money("amount_paisa"),
  previousBalancePaisa: money("previous_balance_paisa"),
  remainingBalancePaisa: money("remaining_balance_paisa"),
  method: text("method").notNull(),
  reference: text("reference"),
  receivedBy: integer("received_by"),
  authorisedBy: integer("authorised_by"),
  status: text("status").notNull().default("issued"),
  cancelReason: text("cancel_reason"),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  printCount: integer("print_count").notNull().default(0),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
}, (t) => [uniqueIndex("receipts_number_uq").on(t.companyId, t.number)]);

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id"),
  supplierId: integer("supplier_id"),
  receiptId: integer("receipt_id"),
  invoiceId: integer("invoice_id"),
  amountPaisa: money("amount_paisa"),
  method: text("method").notNull(),
  reference: text("reference"),
  kind: text("kind").notNull(),
  direction: text("direction").notNull(),
  status: text("status").notNull().default("posted"),
  paidOn: date("paid_on", { mode: "string" }).notNull(),
  accountId: integer("account_id"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const paymentAllocations = pgTable("payment_allocations", {
  id: serial("id").primaryKey(),
  paymentId: integer("payment_id").notNull().references(() => payments.id),
  invoiceId: integer("invoice_id").notNull().references(() => invoices.id),
  amountPaisa: money("amount_paisa"),
});

export const numberSequences = pgTable("number_sequences", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  docType: text("doc_type").notNull(),
  prefix: text("prefix").notNull(),
  nextNumber: integer("next_number").notNull().default(1),
  pad: integer("pad").notNull().default(4),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
}, (t) => [uniqueIndex("sequences_uq").on(t.companyId, t.docType)]);

export const expenseCategories = pgTable("expense_categories", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  glCode: text("gl_code").notNull().default("5000"),
  active: boolean("active").notNull().default(true),
});

export const expenses = pgTable("expenses", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  branchId: integer("branch_id"),
  categoryId: integer("category_id"),
  supplierId: integer("supplier_id"),
  description: text("description").notNull(),
  spentOn: date("spent_on", { mode: "string" }).notNull(),
  amountPaisa: money("amount_paisa"),
  method: text("method").notNull().default("cash"),
  accountId: integer("account_id"),
  status: text("status").notNull().default("recorded"),
  attachmentId: integer("attachment_id"),
  enteredBy: integer("entered_by"),
  notes: text("notes"),
  ...ts(),
});

export const moneyAccounts = pgTable("money_accounts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  accountType: text("account_type").notNull(),
  openingPaisa: money("opening_paisa"),
  currentPaisa: money("current_paisa"),
  accountNumber: text("account_number"),
  active: boolean("active").notNull().default(true),
  notes: text("notes"),
  ...ts(),
});

export const accountTransactions = pgTable("account_transactions", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  accountId: integer("account_id").notNull().references(() => moneyAccounts.id),
  txnDate: date("txn_date", { mode: "string" }).notNull(),
  direction: text("direction").notNull(),
  amountPaisa: money("amount_paisa"),
  description: text("description").notNull(),
  reference: text("reference"),
  source: text("source"),
  sourceId: integer("source_id"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const chartOfAccounts = pgTable("chart_of_accounts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  code: text("code").notNull(),
  name: text("name").notNull(),
  accountType: text("account_type").notNull(),
  active: boolean("active").notNull().default(true),
}, (t) => [uniqueIndex("coa_code_uq").on(t.companyId, t.code)]);

export const journalEntries = pgTable("journal_entries", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  entryDate: date("entry_date", { mode: "string" }).notNull(),
  memo: text("memo").notNull(),
  source: text("source"),
  sourceId: integer("source_id"),
  status: text("status").notNull().default("posted"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const journalLines = pgTable("journal_lines", {
  id: serial("id").primaryKey(),
  entryId: integer("entry_id").notNull().references(() => journalEntries.id, { onDelete: "cascade" }),
  glCode: text("gl_code").notNull(),
  accountId: integer("account_id"),
  debitPaisa: money("debit_paisa"),
  creditPaisa: money("credit_paisa"),
  memo: text("memo"),
});

export const suppliers = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  category: text("category"),
  phone: text("phone"),
  email: text("email"),
  address: text("address"),
  payablePaisa: money("payable_paisa"),
  rating: integer("rating"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const purchaseOrders = pgTable("purchase_orders", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  number: text("number").notNull(),
  supplierId: integer("supplier_id").notNull().references(() => suppliers.id),
  status: text("status").notNull().default("requested"),
  orderedOn: date("ordered_on", { mode: "string" }).notNull(),
  expectedOn: date("expected_on", { mode: "string" }),
  totalPaisa: money("total_paisa"),
  notes: text("notes"),
  stockPosted: boolean("stock_posted").notNull().default(false),
  createdBy: integer("created_by"),
  ...ts(),
}, (t) => [uniqueIndex("po_number_uq").on(t.companyId, t.number)]);

export const purchaseItems = pgTable("purchase_items", {
  id: serial("id").primaryKey(),
  purchaseOrderId: integer("purchase_order_id").notNull().references(() => purchaseOrders.id, { onDelete: "cascade" }),
  productId: integer("product_id"),
  description: text("description").notNull(),
  qty: integer("qty").notNull().default(1),
  unitPaisa: money("unit_paisa"),
  lineTotalPaisa: money("line_total_paisa"),
});

export const campaigns = pgTable("campaigns", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  channel: text("channel").notNull(),
  status: text("status").notNull().default("planned"),
  objective: text("objective"),
  budgetPaisa: money("budget_paisa"),
  startDate: date("start_date", { mode: "string" }),
  endDate: date("end_date", { mode: "string" }),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const campaignExpenses = pgTable("campaign_expenses", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").notNull().references(() => campaigns.id, { onDelete: "cascade" }),
  companyId: integer("company_id").notNull().references(() => companies.id),
  spentOn: date("spent_on", { mode: "string" }).notNull(),
  amountPaisa: money("amount_paisa"),
  description: text("description").notNull(),
  expenseId: integer("expense_id"),
});

export const contentPosts = pgTable("content_posts", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  campaignId: integer("campaign_id"),
  title: text("title").notNull(),
  channel: text("channel").notNull(),
  plannedOn: date("planned_on", { mode: "string" }),
  status: text("status").notNull().default("idea"),
  caption: text("caption"),
  assignedUserId: integer("assigned_user_id"),
  ...ts(),
});

export const countries = pgTable("countries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  region: text("region"),
  notes: text("notes"),
}, (t) => [uniqueIndex("countries_code_uq").on(t.code)]);

export const visaCategories = pgTable("visa_categories", {
  id: serial("id").primaryKey(),
  countryId: integer("country_id").notNull().references(() => countries.id),
  name: text("name").notNull(),
  requirements: text("requirements"),
  checklist: jsonb("checklist").$type<string[]>().notNull(),
  processingDays: integer("processing_days"),
  active: boolean("active").notNull().default(true),
});

export const passports = pgTable("passports", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  passportNo: text("passport_no").notNull(),
  nationality: text("nationality"),
  issueDate: date("issue_date", { mode: "string" }),
  expiryDate: date("expiry_date", { mode: "string" }),
  placeOfIssue: text("place_of_issue"),
  documentId: integer("document_id"),
  notes: text("notes"),
  ...ts(),
});

export const visaApplications = pgTable("visa_applications", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  applicationCode: text("application_code").notNull(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  passportId: integer("passport_id"),
  countryId: integer("country_id"),
  visaCategoryId: integer("visa_category_id"),
  purpose: text("purpose"),
  travelStart: date("travel_start", { mode: "string" }),
  travelEnd: date("travel_end", { mode: "string" }),
  assignedUserId: integer("assigned_user_id"),
  applicationDate: date("application_date", { mode: "string" }).notNull(),
  submissionDate: date("submission_date", { mode: "string" }),
  appointmentDate: date("appointment_date", { mode: "string" }),
  embassy: text("embassy"),
  status: text("status").notNull().default("new"),
  decisionDate: date("decision_date", { mode: "string" }),
  visaStart: date("visa_start", { mode: "string" }),
  visaEnd: date("visa_end", { mode: "string" }),
  refusalReason: text("refusal_reason"),
  deliveryDate: date("delivery_date", { mode: "string" }),
  checklist: jsonb("checklist").$type<Record<string, boolean>>().notNull(),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
}, (t) => [uniqueIndex("visa_code_uq").on(t.companyId, t.applicationCode)]);

export const visaStatusHistory = pgTable("visa_status_history", {
  id: serial("id").primaryKey(),
  applicationId: integer("application_id").notNull().references(() => visaApplications.id, { onDelete: "cascade" }),
  fromStatus: text("from_status"),
  toStatus: text("to_status").notNull(),
  note: text("note"),
  userId: integer("user_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const hotels = pgTable("hotels", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  city: text("city"),
  country: text("country"),
  partner: boolean("partner").notNull().default(false),
  phone: text("phone"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const travelBookings = pgTable("travel_bookings", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  bookingType: text("booking_type").notNull(),
  title: text("title").notNull(),
  destination: text("destination"),
  startDate: date("start_date", { mode: "string" }),
  endDate: date("end_date", { mode: "string" }),
  supplierName: text("supplier_name"),
  passengers: text("passengers"),
  status: text("status").notNull().default("enquiry"),
  salePaisa: money("sale_paisa"),
  costPaisa: money("cost_paisa"),
  invoiceId: integer("invoice_id"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const universities = pgTable("universities", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id"),
  name: text("name").notNull(),
  country: text("country"),
  city: text("city"),
  website: text("website"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
});

export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  universityId: integer("university_id").notNull().references(() => universities.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  level: text("level"),
  tuitionNote: text("tuition_note"),
  deadlineNote: text("deadline_note"),
  requirements: text("requirements"),
});

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id"),
  name: text("name").notNull(),
  phone: text("phone"),
  email: text("email"),
  academicBackground: text("academic_background"),
  preferredCountry: text("preferred_country"),
  preferredCourse: text("preferred_course"),
  status: text("status").notNull().default("counselling"),
  counsellorId: integer("counsellor_id"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const educationApplications = pgTable("education_applications", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  studentId: integer("student_id").notNull().references(() => students.id),
  universityId: integer("university_id"),
  courseId: integer("course_id"),
  status: text("status").notNull().default("preparing"),
  submittedOn: date("submitted_on", { mode: "string" }),
  decisionOn: date("decision_on", { mode: "string" }),
  scholarshipNote: text("scholarship_note"),
  offerNote: text("offer_note"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const tourismProjects = pgTable("tourism_projects", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  location: text("location"),
  concept: text("concept"),
  status: text("status").notNull().default("idea"),
  ownerName: text("owner_name"),
  ownerPhone: text("owner_phone"),
  propertyNote: text("property_note"),
  feasibilityNote: text("feasibility_note"),
  proposalNote: text("proposal_note"),
  startDate: date("start_date", { mode: "string" }),
  budgetPaisa: money("budget_paisa"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const partners = pgTable("partners", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  partnerType: text("partner_type").notNull().default("community"),
  phone: text("phone"),
  email: text("email"),
  location: text("location"),
  consentNote: text("consent_note"),
  notes: text("notes"),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const revenueShares = pgTable("revenue_shares", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => tourismProjects.id, { onDelete: "cascade" }),
  partnerId: integer("partner_id").notNull().references(() => partners.id),
  shareBps: integer("share_bps").notNull().default(0),
  notes: text("notes"),
});

export const partnerPayments = pgTable("partner_payments", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  partnerId: integer("partner_id").notNull().references(() => partners.id),
  projectId: integer("project_id"),
  amountPaisa: money("amount_paisa"),
  paidOn: date("paid_on", { mode: "string" }).notNull(),
  method: text("method").notNull().default("bank"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessionBookings = pgTable("session_bookings", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id"),
  serviceId: integer("service_id"),
  title: text("title").notNull(),
  sessionType: text("session_type").notNull().default("session"),
  startAt: timestamp("start_at", { withTimezone: true }).notNull(),
  durationMin: integer("duration_min").notNull().default(60),
  providerName: text("provider_name"),
  status: text("status").notNull().default("booked"),
  amountPaisa: money("amount_paisa"),
  paidPaisa: money("paid_paisa"),
  feedback: text("feedback"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  branchId: integer("branch_id"),
  title: text("title").notNull(),
  details: text("details"),
  assignedUserId: integer("assigned_user_id"),
  dueOn: date("due_on", { mode: "string" }),
  priority: text("priority").notNull().default("normal"),
  status: text("status").notNull().default("open"),
  relatedEntity: text("related_entity"),
  relatedId: integer("related_id"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const meetings = pgTable("meetings", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  title: text("title").notNull(),
  meetingOn: date("meeting_on", { mode: "string" }).notNull(),
  timeText: text("time_text"),
  location: text("location"),
  attendees: text("attendees"),
  agenda: text("agenda"),
  minutes: text("minutes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id"),
  title: text("title").notNull(),
  body: text("body").notNull(),
  audience: text("audience").notNull().default("everyone"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const assets = pgTable("assets", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  assetCode: text("asset_code").notNull(),
  name: text("name").notNull(),
  category: text("category").notNull().default("equipment"),
  location: text("location"),
  condition: text("condition").notNull().default("good"),
  status: text("status").notNull().default("in_use"),
  purchaseDate: date("purchase_date", { mode: "string" }),
  purchasePaisa: money("purchase_paisa"),
  warrantyUntil: date("warranty_until", { mode: "string" }),
  assignedEmployeeId: integer("assigned_employee_id"),
  notes: text("notes"),
  ...ts(),
});

export const assetMaintenance = pgTable("asset_maintenance", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  assetId: integer("asset_id").notNull().references(() => assets.id, { onDelete: "cascade" }),
  maintainedOn: date("maintained_on", { mode: "string" }).notNull(),
  details: text("details").notNull(),
  costPaisa: money("cost_paisa"),
  status: text("status").notNull().default("done"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const supplies = pgTable("supplies", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  unit: text("unit").notNull().default("pcs"),
  stockQty: integer("stock_qty").notNull().default(0),
  reorderLevel: integer("reorder_level").notNull().default(5),
  location: text("location"),
  notes: text("notes"),
  ...ts(),
});

export const supplyLogs = pgTable("supply_logs", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  supplyId: integer("supply_id").notNull().references(() => supplies.id, { onDelete: "cascade" }),
  qtyChange: integer("qty_change").notNull(),
  reason: text("reason"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const supportTickets = pgTable("support_tickets", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  number: text("number").notNull(),
  customerId: integer("customer_id"),
  subject: text("subject").notNull(),
  category: text("category").notNull().default("question"),
  priority: text("priority").notNull().default("normal"),
  status: text("status").notNull().default("open"),
  assignedUserId: integer("assigned_user_id"),
  dueOn: date("due_on", { mode: "string" }),
  description: text("description"),
  resolution: text("resolution"),
  feedback: text("feedback"),
  createdBy: integer("created_by"),
  ...ts(),
}, (t) => [uniqueIndex("tickets_number_uq").on(t.companyId, t.number)]);

export const approvals = pgTable("approvals", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  type: text("type").notNull(),
  entity: text("entity").notNull(),
  entityId: integer("entity_id"),
  status: text("status").notNull().default("pending"),
  requesterId: integer("requester_id"),
  approverId: integer("approver_id"),
  reason: text("reason"),
  comments: text("comments"),
  payload: jsonb("payload").$type<Record<string, unknown> | null>(),
  decidedAt: timestamp("decided_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  companyId: integer("company_id"),
  title: text("title").notNull(),
  body: text("body"),
  href: text("href"),
  dedupeKey: text("dedupe_key"),
  readAt: timestamp("read_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id"),
  userId: integer("user_id"),
  action: text("action").notNull(),
  entity: text("entity").notNull(),
  entityId: integer("entity_id"),
  details: jsonb("details").$type<unknown>(),
  ip: text("ip"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const documents = pgTable("documents", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  ownerEntity: text("owner_entity").notNull(),
  ownerId: integer("owner_id"),
  title: text("title").notNull(),
  fileName: text("file_name").notNull(),
  storagePath: text("storage_path").notNull(),
  mime: text("mime").notNull(),
  size: integer("size").notNull(),
  visibility: text("visibility").notNull().default("standard"),
  verified: boolean("verified").notNull().default(false),
  verifiedBy: integer("verified_by"),
  uploadedBy: integer("uploaded_by"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const templates = pgTable("templates", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  kind: text("kind").notNull(),
  body: text("body").notNull(),
  updatedBy: integer("updated_by"),
  ...ts(),
});

export const targets = pgTable("targets", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  level: text("level").notNull().default("company"),
  branchId: integer("branch_id"),
  departmentId: integer("department_id"),
  userId: integer("user_id"),
  metric: text("metric").notNull(),
  customLabel: text("custom_label"),
  period: text("period").notNull(),
  periodKey: text("period_key").notNull(),
  targetValue: integer("target_value").notNull().default(0),
  unit: text("unit").notNull().default("count"),
  actualOverride: integer("actual_override"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const consentRecords = pgTable("consent_records", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  purpose: text("purpose").notNull(),
  granted: boolean("granted").notNull().default(false),
  grantedOn: date("granted_on", { mode: "string" }),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const questionnaires = pgTable("questionnaires", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  title: text("title").notNull(),
  intro: text("intro"),
  questions: jsonb("questions").$type<{ id: string; prompt: string }[]>().notNull(),
  active: boolean("active").notNull().default(true),
  ...ts(),
});

export const assessments = pgTable("assessments", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  questionnaireId: integer("questionnaire_id"),
  answers: jsonb("answers").$type<Record<string, string>>().notNull(),
  resultSummary: text("result_summary"),
  recommendations: text("recommendations"),
  consentId: integer("consent_id"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const visitors = pgTable("visitors", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  name: text("name").notNull(),
  phone: text("phone"),
  purpose: text("purpose"),
  hostName: text("host_name"),
  visitDate: date("visit_date", { mode: "string" }).notNull(),
  inTime: text("in_time"),
  outTime: text("out_time"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const couriers = pgTable("couriers", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  direction: text("direction").notNull(),
  carrier: text("carrier"),
  referenceNo: text("reference_no"),
  party: text("party"),
  sentOn: date("sent_on", { mode: "string" }).notNull(),
  notes: text("notes"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const incidents = pgTable("incidents", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  title: text("title").notNull(),
  happenedOn: date("happened_on", { mode: "string" }).notNull(),
  severity: text("severity").notNull().default("low"),
  description: text("description"),
  status: text("status").notNull().default("open"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
});

export const salesOrders = pgTable("sales_orders", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  number: text("number").notNull(),
  customerId: integer("customer_id").notNull().references(() => customers.id),
  status: text("status").notNull().default("confirmed"),
  fulfillment: text("fulfillment").notNull().default("pending"),
  orderedOn: date("ordered_on", { mode: "string" }).notNull(),
  totalPaisa: money("total_paisa"),
  invoiceId: integer("invoice_id"),
  notes: text("notes"),
  createdBy: integer("created_by"),
  ...ts(),
}, (t) => [uniqueIndex("sales_orders_number_uq").on(t.companyId, t.number)]);

export const salesOrderItems = pgTable("sales_order_items", {
  id: serial("id").primaryKey(),
  salesOrderId: integer("sales_order_id").notNull().references(() => salesOrders.id, { onDelete: "cascade" }),
  productId: integer("product_id"),
  description: text("description").notNull(),
  qty: integer("qty").notNull().default(1),
  unitPaisa: money("unit_paisa"),
  costPaisa: money("cost_paisa"),
  lineTotalPaisa: money("line_total_paisa"),
});

export const returns = pgTable("returns", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  invoiceId: integer("invoice_id").notNull().references(() => invoices.id),
  productId: integer("product_id"),
  qty: integer("qty").notNull().default(1),
  amountPaisa: money("amount_paisa"),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("completed"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const commissions = pgTable("commissions", {
  id: serial("id").primaryKey(),
  companyId: integer("company_id").notNull().references(() => companies.id),
  userId: integer("user_id"),
  employeeId: integer("employee_id"),
  opportunityId: integer("opportunity_id"),
  invoiceId: integer("invoice_id"),
  rateBps: integer("rate_bps").notNull().default(0),
  amountPaisa: money("amount_paisa"),
  status: text("status").notNull().default("pending"),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const backupLogs = pgTable("backup_logs", {
  id: serial("id").primaryKey(),
  kind: text("kind").notNull(),
  status: text("status").notNull(),
  bytes: integer("bytes"),
  message: text("message"),
  createdBy: integer("created_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sampleMarkers = pgTable("sample_markers", {
  id: serial("id").primaryKey(),
  entity: text("entity").notNull(),
  entityId: integer("entity_id").notNull(),
});
