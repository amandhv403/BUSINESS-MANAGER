import { and, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  approvals,
  attendance,
  commissions,
  employees,
  expenses,
  invoices,
  journalLines,
  leaveRequests,
  opportunities,
  passports,
  payslips,
  products,
  purchaseItems,
  purchaseOrders,
  quotationItems,
  quotations,
  returns,
  salesOrderItems,
  salesOrders,
  stockMovements,
  suppliers,
  users,
  visaApplications,
  visaStatusHistory,
  consentRecords,
  assessments,
} from "@/db/schema";
import { audit, notifyRoles, notifyUser } from "../audit";
import { GL } from "../constants";
import { AppError } from "../errors";
import { assertCan, assertInScope, canApprove, requireCompany } from "../guard";
import { nextNumber, type Writer } from "../sequence";
import type { Ctx, LineInput } from "../types";
import { dateOf, intOf, takaToPaisa, textOf, todayDhaka } from "../utils";
import { applyIncomingPayment, applyRefund, cancelInvoice, createInvoiceTx, paySupplier, postExpense, postJournal, reverseReceipt } from "./finance";

const writer = (tx: unknown) => tx as Writer;

export async function saveQuotation(ctx: Ctx, input: { customerId: number; issueDate: string; validUntil?: string | null; lines: LineInput[]; discountPaisa: number; notes?: string; opportunityId?: number | null }) {
  assertCan(ctx, "sales", "create");
  const companyId = requireCompany(ctx);
  const company = ctx.company;
  const { priceLines } = await import("./finance");
  const priced = priceLines(input.lines, company?.taxRateBps ?? 0, input.discountPaisa);
  const number = await nextNumber(db, companyId, "quotation");
  const [quote] = await db.insert(quotations).values({
    companyId,
    number,
    customerId: input.customerId,
    opportunityId: input.opportunityId ?? null,
    status: "draft",
    issueDate: input.issueDate,
    validUntil: input.validUntil ?? null,
    subtotalPaisa: priced.subtotal,
    discountPaisa: priced.discountPaisa,
    taxPaisa: priced.tax,
    totalPaisa: priced.total,
    notes: input.notes ?? null,
    createdBy: ctx.user.id,
  }).returning();
  await db.insert(quotationItems).values(priced.priced.map((line) => ({
    quotationId: quote.id,
    description: line.description,
    qty: line.qty,
    unitPaisa: line.unitPaisa,
    lineTotalPaisa: line.lineTotalPaisa,
    kind: line.kind,
    sortOrder: line.sortOrder,
  })));
  await audit(db, ctx, "create", "quotation", quote.id, { number }, companyId);
  return quote.id;
}

export async function convertQuotation(ctx: Ctx, quotationId: number) {
  assertCan(ctx, "accounting", "create");
  const companyId = requireCompany(ctx);
  const [quote] = await db.select().from(quotations).where(and(eq(quotations.id, quotationId), eq(quotations.companyId, companyId)));
  if (!quote) throw new AppError("Quotation not found in this company.");
  const items = await db.select().from(quotationItems).where(eq(quotationItems.quotationId, quote.id));
  const invoice = await createInvoiceTx(db, ctx, {
    companyId,
    customerId: quote.customerId,
    issueDate: todayDhaka(),
    lines: items.map((item) => ({ description: item.description, qty: item.qty, unitPaisa: item.unitPaisa, kind: item.kind as LineInput["kind"] })),
    discountPaisa: quote.discountPaisa,
    notes: quote.notes,
    quotationId: quote.id,
    issueNow: true,
  });
  await db.update(quotations).set({ status: "accepted", updatedAt: new Date() }).where(eq(quotations.id, quote.id));
  return invoice.id;
}

export async function moveStage(ctx: Ctx, opportunityId: number, stage: string, lostReason?: string) {
  assertCan(ctx, "sales", "edit");
  const companyId = requireCompany(ctx);
  const [deal] = await db.select().from(opportunities).where(and(eq(opportunities.id, opportunityId), eq(opportunities.companyId, companyId)));
  if (!deal) throw new AppError("That deal is not in the selected company.");
  if (stage === "Lost" && !lostReason?.trim()) throw new AppError("Write why the deal was lost.");
  await db.update(opportunities).set({ stage, lostReason: lostReason || null, updatedAt: new Date() }).where(eq(opportunities.id, deal.id));
  if (stage === "Won" && deal.assignedUserId) {
    const [user] = await db.select().from(users).where(eq(users.id, deal.assignedUserId));
    if (user?.employeeId) {
      const [employee] = await db.select().from(employees).where(eq(employees.id, user.employeeId));
      if (employee && employee.commissionRateBps > 0) {
        await db.insert(commissions).values({
          companyId,
          userId: user.id,
          employeeId: employee.id,
          opportunityId: deal.id,
          rateBps: employee.commissionRateBps,
          amountPaisa: Math.round((deal.valuePaisa * employee.commissionRateBps) / 10000),
          status: "pending",
          notes: "Created when the deal was marked won. Accounts can include it in payroll.",
        });
      }
    }
  }
  await audit(db, ctx, "stage", "opportunity", deal.id, { stage }, companyId);
}

export async function saveVisa(ctx: Ctx, form: FormData) {
  assertCan(ctx, "visa", "create");
  const companyId = requireCompany(ctx);
  const customerId = intOf(form.get("customerId"), "Customer", true);
  if (!customerId) throw new AppError("Choose a customer.");
  const code = await nextNumber(db, companyId, "visa");
  const [row] = await db.insert(visaApplications).values({
    companyId,
    applicationCode: code,
    customerId,
    countryId: intOf(form.get("countryId"), "Country"),
    visaCategoryId: intOf(form.get("visaCategoryId"), "Visa category"),
    purpose: textOf(form.get("purpose"), "Purpose") || null,
    travelStart: dateOf(form.get("travelStart"), "Travel start"),
    travelEnd: dateOf(form.get("travelEnd"), "Travel end"),
    assignedUserId: intOf(form.get("assignedUserId"), "Officer") || ctx.user.id,
    applicationDate: dateOf(form.get("applicationDate"), "Application date", true) || todayDhaka(),
    appointmentDate: dateOf(form.get("appointmentDate"), "Appointment"),
    embassy: textOf(form.get("embassy"), "Embassy") || null,
    status: "new",
    checklist: {},
    notes: textOf(form.get("notes"), "Notes") || null,
    createdBy: ctx.user.id,
  }).returning();
  await db.insert(visaStatusHistory).values({ applicationId: row.id, toStatus: "new", note: "Application opened", userId: ctx.user.id });
  await audit(db, ctx, "create", "visa", row.id, { code }, companyId);
  return row.id;
}

export async function updateVisaStatus(ctx: Ctx, id: number, status: string, note: string) {
  assertCan(ctx, "visa", "edit");
  const [app] = await db.select().from(visaApplications).where(eq(visaApplications.id, id));
  if (!app) throw new AppError("Application not found.");
  assertInScope(ctx, app.companyId);
  if (status === "refused" && !note.trim()) throw new AppError("Write the refusal note.");
  await db.update(visaApplications).set({
    status,
    decisionDate: ["approved", "refused"].includes(status) ? todayDhaka() : app.decisionDate,
    deliveryDate: status === "delivered" ? todayDhaka() : app.deliveryDate,
    refusalReason: status === "refused" ? note : app.refusalReason,
    updatedAt: new Date(),
  }).where(eq(visaApplications.id, id));
  await db.insert(visaStatusHistory).values({ applicationId: id, fromStatus: app.status, toStatus: status, note, userId: ctx.user.id });
  if (app.assignedUserId) await notifyUser(app.assignedUserId, `Visa file ${app.applicationCode}`, `Status is now ${status}.`, `/visa/${id}`, `visa:${id}:${status}`, app.companyId);
  await audit(db, ctx, "status", "visa", id, { status, note }, app.companyId);
}

export async function savePassport(ctx: Ctx, form: FormData) {
  assertCan(ctx, "visa", "create");
  const companyId = requireCompany(ctx);
  const customerId = intOf(form.get("customerId"), "Customer", true);
  if (!customerId) throw new AppError("Choose a customer.");
  const [row] = await db.insert(passports).values({
    companyId,
    customerId,
    passportNo: textOf(form.get("passportNo"), "Passport number", true, 30),
    nationality: textOf(form.get("nationality"), "Nationality") || null,
    issueDate: dateOf(form.get("issueDate"), "Issue date"),
    expiryDate: dateOf(form.get("expiryDate"), "Expiry date"),
    placeOfIssue: textOf(form.get("placeOfIssue"), "Place of issue") || null,
    notes: textOf(form.get("notes"), "Notes") || null,
  }).returning();
  await audit(db, ctx, "create", "passport", row.id, { customerId }, companyId);
  if (form.get("applicationId")) {
    await db.update(visaApplications).set({ passportId: row.id }).where(and(eq(visaApplications.id, Number(form.get("applicationId"))), eq(visaApplications.companyId, companyId)));
  }
  return row.id;
}

export async function shopSale(ctx: Ctx, input: {
  customerId: number;
  lines: { productId: number; qty: number }[];
  discountPaisa: number;
  paidPaisa: number;
  accountId: number | null;
  method: string;
  reference: string;
  fulfillNow: boolean;
  deliveryAddress: string;
}) {
  assertCan(ctx, "ecommerce", "create");
  const companyId = requireCompany(ctx);
  if (!input.lines.length) throw new AppError("Add at least one product.");
  return db.transaction(async (tx) => {
    const w = writer(tx);
    const invoiceLines: LineInput[] = [];
    const costs: { productId: number; qty: number; description: string; unitPaisa: number; costPaisa: number }[] = [];
    let cogs = 0;
    for (const line of input.lines) {
      const [product] = await w.select().from(products).where(and(eq(products.id, line.productId), eq(products.companyId, companyId)));
      if (!product || !product.active) throw new AppError("A selected product is not available in this company.");
      if (line.qty < 1) throw new AppError("Quantity must be at least 1.");
      invoiceLines.push({ description: product.variant ? `${product.name} (${product.variant})` : product.name, qty: line.qty, unitPaisa: product.salePaisa, kind: "product", productId: product.id });
      costs.push({ productId: product.id, qty: line.qty, description: product.name, unitPaisa: product.salePaisa, costPaisa: product.purchasePaisa });
      cogs += line.qty * product.purchasePaisa;
      if (input.fulfillNow) {
        const updated = await w.execute(sql`update products set stock_qty = stock_qty - ${line.qty}, updated_at = now() where id = ${product.id} and company_id = ${companyId} and stock_qty >= ${line.qty} returning id`);
        if (!updated.rows.length) throw new AppError(`${product.name} does not have enough stock.`);
        await w.insert(stockMovements).values({ companyId, productId: product.id, movementType: "sale", qty: -line.qty, createdBy: ctx.user.id, reference: "shop sale" });
      }
    }
    const orderNumber = await nextNumber(w, companyId, "order");
    const [order] = await w.insert(salesOrders).values({
      companyId,
      number: orderNumber,
      customerId: input.customerId,
      status: "confirmed",
      fulfillment: input.fulfillNow ? "delivered" : "pending",
      orderedOn: todayDhaka(),
      totalPaisa: 0,
      notes: input.deliveryAddress || null,
      createdBy: ctx.user.id,
    }).returning();
    await w.insert(salesOrderItems).values(costs.map((line) => ({
      salesOrderId: order.id,
      productId: line.productId,
      description: line.description,
      qty: line.qty,
      unitPaisa: line.unitPaisa,
      costPaisa: line.costPaisa,
      lineTotalPaisa: line.unitPaisa * line.qty,
    })));
    const invoice = await createInvoiceTx(w, ctx, {
      companyId,
      customerId: input.customerId,
      issueDate: todayDhaka(),
      lines: invoiceLines,
      discountPaisa: input.discountPaisa,
      notes: input.deliveryAddress,
      salesOrderId: order.id,
      fulfillmentStatus: input.fulfillNow ? "delivered" : "pending",
      deliveryAddress: input.deliveryAddress,
      issueNow: true,
    });
    await w.update(salesOrders).set({ invoiceId: invoice.id, totalPaisa: invoice.totalPaisa, updatedAt: new Date() }).where(eq(salesOrders.id, order.id));
    if (input.fulfillNow && cogs > 0) {
      await postJournal(w, {
        companyId,
        entryDate: todayDhaka(),
        memo: `Product cost for ${orderNumber}`,
        source: "cogs",
        sourceId: order.id,
        createdBy: ctx.user.id,
        lines: [
          { glCode: GL.cogs, debitPaisa: cogs },
          { glCode: GL.inventory, creditPaisa: cogs },
        ],
      });
    }
    if (input.paidPaisa > 0) {
      await applyIncomingPayment(w, ctx, {
        companyId,
        customerId: input.customerId,
        amountPaisa: input.paidPaisa,
        method: input.method,
        reference: input.reference || null,
        accountId: input.accountId,
        paidOn: todayDhaka(),
        invoiceId: invoice.id,
        notes: `Shop sale ${orderNumber}`,
      });
    }
    await audit(w, ctx, "sale", "sales_order", order.id, { invoice: invoice.number }, companyId);
    return { orderId: order.id, invoiceId: invoice.id, number: invoice.number };
  });
}

export async function saveAttendance(ctx: Ctx, workDate: string, rows: { employeeId: number; status: string; checkIn?: string; checkOut?: string }[]) {
  assertCan(ctx, "hrm", "edit");
  const companyId = requireCompany(ctx);
  for (const row of rows) {
    if (!row.status) continue;
    const [employee] = await db.select().from(employees).where(and(eq(employees.id, row.employeeId), eq(employees.companyId, companyId)));
    if (!employee) continue;
    if (ctx.branchId && employee.branchId && employee.branchId !== ctx.branchId) continue;
    await db.insert(attendance).values({
      companyId,
      employeeId: row.employeeId,
      workDate,
      status: row.status,
      checkIn: row.checkIn || null,
      checkOut: row.checkOut || null,
      markedBy: ctx.user.id,
    }).onConflictDoUpdate({
      target: [attendance.employeeId, attendance.workDate],
      set: { status: row.status, checkIn: row.checkIn || null, checkOut: row.checkOut || null, markedBy: ctx.user.id, updatedAt: new Date() },
    });
  }
  await audit(db, ctx, "attendance", "attendance", null, { workDate, count: rows.length }, companyId);
}

export async function saveLeave(ctx: Ctx, form: FormData) {
  const companyId = requireCompany(ctx);
  const ownEmployee = ctx.user.employeeId;
  const employeeId = intOf(form.get("employeeId"), "Employee") || ownEmployee;
  if (!employeeId) throw new AppError("Choose an employee.");
  if (employeeId !== ownEmployee) assertCan(ctx, "hrm", "create");
  const [employee] = await db.select().from(employees).where(and(eq(employees.id, employeeId), eq(employees.companyId, companyId)));
  if (!employee) throw new AppError("That employee is not in the selected company.");
  const [leave] = await db.insert(leaveRequests).values({
    companyId,
    employeeId,
    leaveType: textOf(form.get("leaveType"), "Leave type", true, 40),
    startDate: dateOf(form.get("startDate"), "Start", true) || todayDhaka(),
    endDate: dateOf(form.get("endDate"), "End", true) || todayDhaka(),
    reason: textOf(form.get("reason"), "Reason") || null,
    status: "pending",
  }).returning();
  await db.insert(approvals).values({
    companyId,
    type: "leave",
    entity: "leave",
    entityId: leave.id,
    requesterId: ctx.user.id,
    reason: leave.reason,
    payload: { leaveId: leave.id },
  });
  await notifyRoles(companyId, ["hr", "company_admin", "super_admin", "branch_manager"], "Leave request", `${employee.name} asked for leave.`, "/leave");
  return leave.id;
}

export async function saveEmployee(ctx: Ctx, form: FormData) {
  assertCan(ctx, "hrm", "create");
  const companyId = requireCompany(ctx);
  const id = Number(form.get("id") || 0);
  const salaryPaisa = takaToPaisa(form.get("salary"), "Salary");
  const values = {
    name: textOf(form.get("name"), "Name", true, 160),
    phone: textOf(form.get("phone"), "Phone") || null,
    email: textOf(form.get("email"), "Email") || null,
    designation: textOf(form.get("designation"), "Designation") || null,
    joiningDate: dateOf(form.get("joiningDate"), "Joining date"),
    status: textOf(form.get("status"), "Status") || "active",
    branchId: intOf(form.get("branchId"), "Branch"),
    departmentId: intOf(form.get("departmentId"), "Department"),
    managerId: intOf(form.get("managerId"), "Manager"),
    commissionRateBps: Math.round(Number(form.get("commissionPercent") || 0) * 100),
    nid: textOf(form.get("nid"), "National ID") || null,
    address: textOf(form.get("address"), "Address") || null,
    bankAccount: textOf(form.get("bankAccount"), "Bank account") || null,
    notes: textOf(form.get("notes"), "Notes") || null,
    updatedAt: new Date(),
  };
  if (id) {
    const [existing] = await db.select().from(employees).where(and(eq(employees.id, id), eq(employees.companyId, companyId)));
    if (!existing) throw new AppError("Employee not found in this company.");
    if (salaryPaisa !== existing.salaryPaisa && !canApprove(ctx, "payroll")) {
      await db.insert(approvals).values({
        companyId,
        type: "salary",
        entity: "employee",
        entityId: id,
        requesterId: ctx.user.id,
        reason: "Salary change",
        payload: { employeeId: id, salaryPaisa },
      });
      await db.update(employees).set(values).where(eq(employees.id, id));
      throw new AppError("The profile was saved. The salary change is waiting for approval.");
    }
    await db.update(employees).set({ ...values, salaryPaisa }).where(eq(employees.id, id));
    await audit(db, ctx, "update", "employee", id, { name: values.name }, companyId);
    return id;
  }
  const code = await nextNumber(db, companyId, "employee");
  const [row] = await db.insert(employees).values({ ...values, companyId, employeeCode: code, salaryPaisa: canApprove(ctx, "payroll") ? salaryPaisa : 0 }).returning();
  if (!canApprove(ctx, "payroll") && salaryPaisa > 0) {
    await db.insert(approvals).values({ companyId, type: "salary", entity: "employee", entityId: row.id, requesterId: ctx.user.id, reason: "Starting salary", payload: { employeeId: row.id, salaryPaisa } });
  }
  await audit(db, ctx, "create", "employee", row.id, { code }, companyId);
  return row.id;
}

export async function savePayslip(ctx: Ctx, form: FormData) {
  assertCan(ctx, "payroll", "create");
  const companyId = requireCompany(ctx);
  const employeeId = intOf(form.get("employeeId"), "Employee", true);
  if (!employeeId) throw new AppError("Choose an employee.");
  const [employee] = await db.select().from(employees).where(and(eq(employees.id, employeeId), eq(employees.companyId, companyId)));
  if (!employee) throw new AppError("Employee not found in this company.");
  const basic = takaToPaisa(form.get("basic"), "Basic salary") || employee.salaryPaisa;
  const allowances = takaToPaisa(form.get("allowances"), "Allowances");
  const deductions = takaToPaisa(form.get("deductions"), "Deductions");
  const bonus = takaToPaisa(form.get("bonus"), "Bonus");
  const commission = takaToPaisa(form.get("commission"), "Commission");
  const advance = takaToPaisa(form.get("advance"), "Advance recovery");
  const net = basic + allowances + bonus + commission - deductions - advance;
  if (net < 0) throw new AppError("Net pay cannot be negative. Check the deductions and advance.");
  const [row] = await db.insert(payslips).values({
    companyId,
    employeeId,
    periodKey: textOf(form.get("periodKey"), "Pay period", true, 20),
    basicPaisa: basic,
    allowancesPaisa: allowances,
    deductionsPaisa: deductions,
    bonusPaisa: bonus,
    commissionPaisa: commission,
    advancePaisa: advance,
    netPaisa: net,
    status: canApprove(ctx, "payroll") ? "approved" : "draft",
    notes: textOf(form.get("notes"), "Notes") || null,
    createdBy: ctx.user.id,
  }).returning();
  await audit(db, ctx, "create", "payslip", row.id, { employeeId, net }, companyId);
  return row.id;
}

export async function receivePurchase(ctx: Ctx, purchaseId: number, payNow: boolean, accountId?: number) {
  assertCan(ctx, "procurement", "edit");
  const companyId = requireCompany(ctx);
  let supplierId = 0;
  let totalPaisa = 0;
  await db.transaction(async (tx) => {
    const w = writer(tx);
    const [order] = await w.select().from(purchaseOrders).where(and(eq(purchaseOrders.id, purchaseId), eq(purchaseOrders.companyId, companyId))).for("update");
    if (!order) throw new AppError("Purchase order not found.");
    if (order.stockPosted) throw new AppError("Goods for this order were already received.");
    supplierId = order.supplierId;
    totalPaisa = order.totalPaisa;
    if (!["approved", "ordered", "requested"].includes(order.status) && !canApprove(ctx, "procurement")) {
      throw new AppError("This purchase still needs approval.");
    }
    const items = await w.select().from(purchaseItems).where(eq(purchaseItems.purchaseOrderId, order.id));
    let inventory = 0;
    for (const item of items) {
      inventory += item.lineTotalPaisa;
      if (item.productId) {
        await w.execute(sql`update products set stock_qty = stock_qty + ${item.qty}, purchase_paisa = ${item.unitPaisa}, updated_at = now() where id = ${item.productId} and company_id = ${companyId}`);
        await w.insert(stockMovements).values({ companyId, productId: item.productId, movementType: "purchase", qty: item.qty, reference: order.number, createdBy: ctx.user.id });
      }
    }
    if (inventory) {
      await w.update(suppliers).set({ payablePaisa: sql`${suppliers.payablePaisa} + ${order.totalPaisa}`, updatedAt: new Date() }).where(eq(suppliers.id, order.supplierId));
      await postJournal(w, {
        companyId,
        entryDate: todayDhaka(),
        memo: `Goods received ${order.number}`,
        source: "purchase",
        sourceId: order.id,
        createdBy: ctx.user.id,
        lines: [
          { glCode: GL.inventory, debitPaisa: inventory },
          { glCode: GL.ap, creditPaisa: inventory },
        ],
      });
    }
    if (payNow && !accountId) throw new AppError("Choose the account that paid the supplier.");
    await w.update(purchaseOrders).set({ status: "received", stockPosted: true, updatedAt: new Date() }).where(eq(purchaseOrders.id, order.id));
    await audit(w, ctx, "receive", "purchase", order.id, null, companyId);
  });
  if (payNow && accountId && totalPaisa > 0) {
    await paySupplier(ctx, { supplierId, amountPaisa: totalPaisa, accountId, method: "bank", paidOn: todayDhaka(), notes: "Paid when goods were received" });
  }
}

export async function returnToStock(ctx: Ctx, invoiceId: number, productId: number, qty: number, reason: string) {
  assertCan(ctx, "ecommerce", "edit");
  const companyId = requireCompany(ctx);
  if (qty < 1) throw new AppError("Quantity must be at least 1.");
  if (!reason.trim()) throw new AppError("Write why the item is coming back.");
  const [invoice] = await db.select().from(invoices).where(and(eq(invoices.id, invoiceId), eq(invoices.companyId, companyId)));
  if (!invoice) throw new AppError("That invoice is not in the selected company.");
  const [product] = await db.select().from(products).where(and(eq(products.id, productId), eq(products.companyId, companyId)));
  if (!product) throw new AppError("That product is not in the selected company.");
  await db.transaction(async (tx) => {
    const w = writer(tx);
    await w.execute(sql`update products set stock_qty = stock_qty + ${qty}, updated_at = now() where id = ${productId} and company_id = ${companyId}`);
    await w.insert(stockMovements).values({ companyId, productId, movementType: "return", qty, reference: invoice.number, notes: reason, createdBy: ctx.user.id });
    await w.insert(returns).values({ companyId, invoiceId, productId, qty, amountPaisa: product.salePaisa * qty, reason, createdBy: ctx.user.id });
    await audit(w, ctx, "return", "invoice", invoiceId, { productId, qty }, companyId);
  });
}

export async function savePurchase(ctx: Ctx, form: FormData) {
  assertCan(ctx, "procurement", "create");
  const companyId = requireCompany(ctx);
  const supplierId = intOf(form.get("supplierId"), "Supplier", true);
  if (!supplierId) throw new AppError("Choose a supplier.");
  const description = textOf(form.get("description"), "What are you buying?", true, 300);
  const qty = intOf(form.get("qty"), "Quantity", true) || 1;
  const unit = takaToPaisa(form.get("unit"), "Unit cost");
  const total = qty * unit;
  const number = await nextNumber(db, companyId, "purchase");
  const status = canApprove(ctx, "procurement") ? "approved" : "requested";
  const [order] = await db.insert(purchaseOrders).values({
    companyId,
    number,
    supplierId,
    status,
    orderedOn: dateOf(form.get("orderedOn"), "Date") || todayDhaka(),
    expectedOn: dateOf(form.get("expectedOn"), "Expected"),
    totalPaisa: total,
    notes: textOf(form.get("notes"), "Notes") || null,
    createdBy: ctx.user.id,
  }).returning();
  await db.insert(purchaseItems).values({ purchaseOrderId: order.id, productId: intOf(form.get("productId"), "Product"), description, qty, unitPaisa: unit, lineTotalPaisa: total });
  if (status === "requested") {
    await db.insert(approvals).values({ companyId, type: "purchase", entity: "purchase", entityId: order.id, requesterId: ctx.user.id, reason: description, payload: { purchaseId: order.id } });
  }
  await audit(db, ctx, "create", "purchase", order.id, { number }, companyId);
  return order.id;
}

export async function saveAssessment(ctx: Ctx, form: FormData) {
  assertCan(ctx, "sensitive", "create");
  const companyId = requireCompany(ctx);
  const customerId = intOf(form.get("customerId"), "Customer", true);
  if (!customerId) throw new AppError("Choose a customer.");
  const purpose = textOf(form.get("purpose"), "Purpose", true, 160);
  const [consent] = await db.select().from(consentRecords).where(and(eq(consentRecords.companyId, companyId), eq(consentRecords.customerId, customerId), eq(consentRecords.purpose, purpose), eq(consentRecords.granted, true)));
  if (!consent) throw new AppError("Save a granted consent for this purpose before storing private answers.");
  const answers: Record<string, string> = {};
  for (const [key, value] of form.entries()) {
    if (String(key).startsWith("q_")) answers[String(key).slice(2)] = String(value);
  }
  const [row] = await db.insert(assessments).values({
    companyId,
    customerId,
    answers,
    resultSummary: textOf(form.get("resultSummary"), "Result") || null,
    recommendations: textOf(form.get("recommendations"), "Recommendations") || null,
    consentId: consent.id,
    createdBy: ctx.user.id,
  }).returning();
  await audit(db, ctx, "create", "assessment", row.id, { customerId }, companyId);
  return row.id;
}

export async function decideApproval(ctx: Ctx, id: number, decision: "approved" | "rejected", comments: string) {
  if (decision === "approved") assertCan(ctx, "approvals", "approve");
  else assertCan(ctx, "approvals", "reject");
  const [approval] = await db.select().from(approvals).where(eq(approvals.id, id));
  if (!approval || approval.status !== "pending") throw new AppError("This request is no longer waiting.");
  assertInScope(ctx, approval.companyId);
  const payload = (approval.payload ?? {}) as Record<string, unknown>;
  if (decision === "rejected") {
    await db.update(approvals).set({ status: "rejected", approverId: ctx.user.id, comments, decidedAt: new Date() }).where(eq(approvals.id, id));
    if (approval.type === "expense" && approval.entityId) await db.update(expenses).set({ status: "rejected", updatedAt: new Date() }).where(eq(expenses.id, approval.entityId));
    if (approval.type === "leave" && approval.entityId) await db.update(leaveRequests).set({ status: "rejected", approverId: ctx.user.id, decisionNote: comments, updatedAt: new Date() }).where(eq(leaveRequests.id, approval.entityId));
    if (approval.requesterId) await notifyUser(approval.requesterId, "Request declined", comments || approval.type, "/approvals");
    await audit(db, ctx, "reject", "approval", id, { type: approval.type }, approval.companyId);
    return;
  }
  if (approval.type === "expense" && approval.entityId) await db.transaction(async (tx) => postExpense(writer(tx), ctx, approval.entityId!));
  if (approval.type === "refund") await db.transaction(async (tx) => applyRefund(writer(tx), ctx, payload as never));
  if (approval.type === "receipt_cancellation") await db.transaction(async (tx) => reverseReceipt(writer(tx), ctx, Number(payload.receiptId), String(payload.reason || comments)));
  if (approval.type === "invoice_cancellation") await cancelInvoice(ctx, Number(payload.invoiceId), String(payload.reason || comments));
  if (approval.type === "leave" && approval.entityId) await db.update(leaveRequests).set({ status: "approved", approverId: ctx.user.id, decisionNote: comments, updatedAt: new Date() }).where(eq(leaveRequests.id, approval.entityId));
  if (approval.type === "purchase" && approval.entityId) await db.update(purchaseOrders).set({ status: "approved", updatedAt: new Date() }).where(eq(purchaseOrders.id, approval.entityId));
  if (approval.type === "salary") await db.update(employees).set({ salaryPaisa: Number(payload.salaryPaisa || 0), updatedAt: new Date() }).where(eq(employees.id, Number(payload.employeeId)));
  if (approval.type === "discount" && approval.entityId) {
    const [invoice] = await db.select().from(invoices).where(eq(invoices.id, approval.entityId));
    if (invoice && invoice.status === "pending_approval") {
      await postJournal(db, {
        companyId: invoice.companyId,
        entryDate: invoice.issueDate,
        memo: `Invoice ${invoice.number} approved`,
        source: "invoice",
        sourceId: invoice.id,
        createdBy: ctx.user.id,
        lines: [
          { glCode: GL.ar, debitPaisa: invoice.totalPaisa },
          ...(invoice.servicePaisa ? [{ glCode: GL.serviceRevenue, creditPaisa: invoice.servicePaisa }] : []),
          ...(invoice.productPaisa ? [{ glCode: GL.productRevenue, creditPaisa: invoice.productPaisa }] : []),
          ...(invoice.thirdPartyPaisa ? [{ glCode: GL.thirdParty, creditPaisa: invoice.thirdPartyPaisa }] : []),
          ...(invoice.taxPaisa ? [{ glCode: GL.tax, creditPaisa: invoice.taxPaisa }] : []),
          ...(invoice.discountPaisa ? [{ glCode: GL.discount, debitPaisa: invoice.discountPaisa }] : []),
        ],
      });
      await db.update(invoices).set({ status: "issued", updatedAt: new Date() }).where(eq(invoices.id, invoice.id));
    }
  }
  await db.update(approvals).set({ status: "approved", approverId: ctx.user.id, comments, decidedAt: new Date() }).where(eq(approvals.id, id));
  if (approval.requesterId) await notifyUser(approval.requesterId, "Request approved", comments || approval.type, "/approvals");
  await audit(db, ctx, "approve", "approval", id, { type: approval.type }, approval.companyId);
  void journalLines;
  void inArray;
}

export async function saveOpportunity(ctx: Ctx, form: FormData) {
  assertCan(ctx, "sales", "create");
  const companyId = requireCompany(ctx);
  const id = Number(form.get("id") || 0);
  const values = {
    title: textOf(form.get("title"), "Deal name", true, 160),
    customerId: intOf(form.get("customerId"), "Customer"),
    leadId: intOf(form.get("leadId"), "Lead"),
    campaignId: intOf(form.get("campaignId"), "Campaign"),
    stage: textOf(form.get("stage"), "Stage") || "New lead",
    valuePaisa: takaToPaisa(form.get("value"), "Expected value"),
    probability: Number(form.get("probability") || 20),
    assignedUserId: intOf(form.get("assignedUserId"), "Owner") || ctx.user.id,
    expectedClose: dateOf(form.get("expectedClose"), "Expected close"),
    lostReason: textOf(form.get("lostReason"), "Lost reason") || null,
    notes: textOf(form.get("notes"), "Notes") || null,
    updatedAt: new Date(),
  };
  if (values.stage === "Lost" && !values.lostReason) throw new AppError("Write why the deal was lost.");
  if (id) {
    const [existing] = await db.select().from(opportunities).where(and(eq(opportunities.id, id), eq(opportunities.companyId, companyId)));
    if (!existing) throw new AppError("Deal not found.");
    await db.update(opportunities).set(values).where(eq(opportunities.id, id));
    if (values.stage !== existing.stage) await moveStage(ctx, id, values.stage, values.lostReason || undefined);
    return id;
  }
  const [row] = await db.insert(opportunities).values({ ...values, companyId, createdBy: ctx.user.id }).returning();
  await audit(db, ctx, "create", "opportunity", row.id, { title: values.title }, companyId);
  return row.id;
}
