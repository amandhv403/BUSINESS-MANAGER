import { and, eq, or, sql } from "drizzle-orm";
import { mkdir, writeFile } from "fs/promises";
import path from "path";
import { randomBytes } from "crypto";
import { db } from "@/db";
import {
  chartOfAccounts,
  companies,
  companyModules,
  customerCompanies,
  customers,
  documents,
  expenseCategories,
  leads,
  moneyAccounts,
  numberSequences,
  pipelineStages,
  roles,
  userCompanies,
  users,
} from "@/db/schema";
import { audit, notifyUser } from "../audit";
import { hashPassword, assertPasswordStrength } from "../auth";
import { BUSINESS_TYPES, CHART, MODULE_KEYS, PIPELINE, rolePresets } from "../constants";
import { AppError } from "../errors";
import { assertCan, assertInScope, requireCompany } from "../guard";
import { ENTITIES, type EntityDef } from "../registry";
import { nextNumber, type Writer } from "../sequence";
import type { Ctx } from "../types";
import { dateOf, intOf, takaToPaisa, textOf, todayDhaka } from "../utils";

export async function provisionCompany(tx: Writer, company: { id: number; shortName: string; invoicePrefix: string; receiptPrefix: string; quotationPrefix: string; businessType: string }) {
  const sequences = [
    ["invoice", company.invoicePrefix],
    ["receipt", company.receiptPrefix],
    ["quotation", company.quotationPrefix || `${company.shortName}-QT`],
    ["customer", `${company.shortName}-C`],
    ["employee", `${company.shortName}-E`],
    ["visa", `${company.shortName}-V`],
    ["ticket", `${company.shortName}-T`],
    ["order", `${company.shortName}-SO`],
    ["purchase", `${company.shortName}-PO`],
    ["refund", `${company.shortName}-RF`],
  ];
  await tx.insert(numberSequences).values(sequences.map(([docType, prefix]) => ({ companyId: company.id, docType, prefix, nextNumber: 1, pad: 4 })));
  await tx.insert(chartOfAccounts).values(CHART.map((row) => ({ ...row, companyId: company.id })));
  await tx.insert(moneyAccounts).values([
    { companyId: company.id, name: "Cash in hand", accountType: "cash", openingPaisa: 0, currentPaisa: 0 },
    { companyId: company.id, name: "Bank account", accountType: "bank", openingPaisa: 0, currentPaisa: 0 },
    { companyId: company.id, name: "bKash", accountType: "mfs", openingPaisa: 0, currentPaisa: 0 },
  ]);
  const enabled = new Set(BUSINESS_TYPES[company.businessType]?.modules ?? MODULE_KEYS);
  await tx.insert(companyModules).values(MODULE_KEYS.map((moduleKey) => ({ companyId: company.id, moduleKey, enabled: enabled.has(moduleKey) })));
  await tx.insert(pipelineStages).values(PIPELINE.map((name, index) => ({ companyId: company.id, name, sortOrder: index, isWon: name === "Won", isLost: name === "Lost" })));
  await tx.insert(expenseCategories).values(["Office", "Marketing", "Travel", "Utilities", "Salary", "Supplier", "Other"].map((name) => ({ companyId: company.id, name, glCode: "5000" })));
}

function readEntity(def: EntityDef, form: FormData) {
  const values: Record<string, unknown> = {};
  for (const field of def.fields) {
    const raw = form.get(field.key);
    if (field.kind === "bool") {
      values[field.key] = raw === "on" || raw === "true" || raw === "1";
      continue;
    }
    if (field.kind === "money") {
      values[field.key] = takaToPaisa(raw, field.label);
      continue;
    }
    if (field.kind === "int") {
      values[field.key] = intOf(raw, field.label, field.required);
      continue;
    }
    if (field.kind === "date") {
      values[field.key] = dateOf(raw, field.label, field.required);
      continue;
    }
    if (field.kind === "datetime") {
      const value = textOf(raw, field.label, field.required, 40);
      values[field.key] = value ? new Date(value) : null;
      continue;
    }
    const max = field.kind === "long" ? 8000 : 400;
    const value = textOf(raw, field.label, field.required, max);
    values[field.key] = value || null;
  }
  if (def.timestamps !== false) values.updatedAt = new Date();
  return values;
}

export async function saveGeneric(ctx: Ctx, entity: string, form: FormData) {
  const def = ENTITIES[entity];
  if (!def) throw new AppError("That form is not available.");
  const id = Number(form.get("id") || 0);
  assertCan(ctx, def.module, id ? "edit" : "create");
  const companyId = def.scope === "company" ? requireCompany(ctx) : null;
  const values = readEntity(def, form);
  if (companyId) values.companyId = companyId;
  const table = def.table as any;
  if (id) {
    const [existing] = await db.select().from(table).where(eq(table.id, id));
    if (!existing) throw new AppError("That record could not be found.");
    if (def.scope === "company") assertInScope(ctx, Number(existing.companyId));
    delete values.companyId;
    await db.update(table).set(values).where(eq(table.id, id));
    await audit(db, ctx, "update", entity, id, { keys: Object.keys(values) }, companyId);
    return id;
  }
  if (def.createdBy) values.createdBy = ctx.user.id;
  if (def.numberType && companyId) {
    values[def.numberKey || "number"] = await nextNumber(db, companyId, def.numberType);
  }
  const inserted = (await db.insert(table).values(values).returning()) as { id: number }[];
  const newId = Number(inserted[0]?.id);
  await audit(db, ctx, "create", entity, newId, { title: values.name || values.title || values.subject }, companyId);
  if (values.assignedUserId) {
    await notifyUser(Number(values.assignedUserId), "New work assigned", String(values.title || values.subject || values.name || "Open AIO Desk"), "/office", undefined, companyId);
  }
  return newId;
}

export async function archiveGeneric(ctx: Ctx, entity: string, id: number) {
  const def = ENTITIES[entity];
  if (!def) throw new AppError("That record type cannot be archived.");
  assertCan(ctx, def.module, "delete");
  const table = def.table as any;
  const [existing] = await db.select().from(table).where(eq(table.id, id));
  if (!existing) throw new AppError("That record could not be found.");
  const row = existing as { companyId?: number; active?: boolean };
  if (def.scope === "company" && row.companyId) assertInScope(ctx, row.companyId);
  if ("active" in (existing as object)) {
    await db.update(table).set({ active: false, ...(def.timestamps === false ? {} : { updatedAt: new Date() }) }).where(eq(table.id, id));
  } else if (def.statusKey) {
    await db.update(table).set({ [def.statusKey]: "archived", updatedAt: new Date() }).where(eq(table.id, id));
  } else {
    throw new AppError("This record is kept for history and cannot be deleted. Change its status instead.");
  }
  await audit(db, ctx, "archive", entity, id, null, row.companyId ?? null);
}

export async function saveCustomer(ctx: Ctx, form: FormData) {
  const id = Number(form.get("id") || 0);
  assertCan(ctx, "crm", id ? "edit" : "create");
  const companyId = requireCompany(ctx);
  const name = textOf(form.get("name"), "Name", true, 160);
  const phone = textOf(form.get("phone"), "Phone", false, 40);
  const email = textOf(form.get("email"), "Email", false, 160);
  const allowDuplicate = form.get("allowDuplicate") === "on";
  if (phone || email) {
    const matches = await db
      .select()
      .from(customers)
      .where(and(eq(customers.companyId, companyId), or(...[phone ? eq(customers.phone, phone) : undefined, email ? eq(customers.email, email) : undefined].filter(Boolean) as never[])));
    const others = matches.filter((row) => row.id !== id);
    if (others.length && !allowDuplicate) {
      throw new AppError(`This looks like an existing customer: ${others[0].name} (${others[0].customerCode}). Open that record, or tick “Save anyway” if this is a different person.`);
    }
  }
  const values = {
    name,
    phone: phone || null,
    email: email || null,
    address: textOf(form.get("address"), "Address", false, 500) || null,
    category: textOf(form.get("category"), "Category", false, 80) || "general",
    source: textOf(form.get("source"), "Source", false, 80) || null,
    status: textOf(form.get("status"), "Status", false, 40) || "active",
    assignedUserId: intOf(form.get("assignedUserId"), "Assigned user"),
    notes: textOf(form.get("notes"), "Notes", false, 4000) || null,
    nationality: textOf(form.get("nationality"), "Nationality", false, 80) || null,
    occupation: textOf(form.get("occupation"), "Occupation", false, 120) || null,
    updatedAt: new Date(),
  };
  if (id) {
    const [existing] = await db.select().from(customers).where(and(eq(customers.id, id), eq(customers.companyId, companyId)));
    if (!existing) throw new AppError("That customer is not in the selected company.");
    await db.update(customers).set(values).where(eq(customers.id, id));
    await audit(db, ctx, "update", "customer", id, { name }, companyId);
    return id;
  }
  const code = await nextNumber(db, companyId, "customer");
  const [row] = await db.insert(customers).values({
    ...values,
    companyId,
    customerCode: code,
    verificationStatus: ctx.can("crm", "verify") || ctx.can("crm", "manage") ? "verified" : "pending",
    createdBy: ctx.user.id,
  }).returning();
  await db.insert(customerCompanies).values({ customerId: row.id, companyId, relationship: "primary" }).onConflictDoNothing();
  await audit(db, ctx, "create", "customer", row.id, { code }, companyId);
  return row.id;
}

export async function convertLead(ctx: Ctx, leadId: number) {
  assertCan(ctx, "crm", "create");
  const companyId = requireCompany(ctx);
  const [lead] = await db.select().from(leads).where(and(eq(leads.id, leadId), eq(leads.companyId, companyId)));
  if (!lead) throw new AppError("That lead is not in the selected company.");
  if (lead.customerId) return lead.customerId;
  const code = await nextNumber(db, companyId, "customer");
  const [customer] = await db.insert(customers).values({
    companyId,
    customerCode: code,
    name: lead.name,
    phone: lead.phone,
    email: lead.email,
    source: lead.source,
    status: "active",
    assignedUserId: lead.assignedUserId,
    notes: lead.notes,
    createdBy: ctx.user.id,
    verificationStatus: "verified",
  }).returning();
  await db.insert(customerCompanies).values({ customerId: customer.id, companyId, relationship: "converted lead" });
  await db.update(leads).set({ customerId: customer.id, status: "converted", updatedAt: new Date() }).where(eq(leads.id, lead.id));
  await audit(db, ctx, "convert", "lead", lead.id, { customerId: customer.id }, companyId);
  return customer.id;
}

export async function importCustomers(ctx: Ctx, csv: string) {
  assertCan(ctx, "crm", "create");
  const companyId = requireCompany(ctx);
  const lines = csv.split(/\r?\n/).map((line) => line.trim()).filter(Boolean);
  if (lines.length < 2) throw new AppError("The file needs a heading row and at least one customer.");
  const headers = lines[0].split(",").map((h) => h.trim().toLowerCase());
  const index = (name: string) => headers.indexOf(name);
  if (index("name") < 0) throw new AppError("The file must include a name column.");
  let created = 0;
  let skipped = 0;
  const errors: string[] = [];
  for (let i = 1; i < lines.length; i++) {
    const cells = lines[i].split(",").map((cell) => cell.trim().replace(/^"|"$/g, ""));
    const name = cells[index("name")] || "";
    const phone = index("phone") >= 0 ? cells[index("phone")] : "";
    const email = index("email") >= 0 ? cells[index("email")] : "";
    if (!name) {
      errors.push(`Row ${i + 1}: name is missing.`);
      continue;
    }
    if (phone) {
      const dup = await db.select({ id: customers.id }).from(customers).where(and(eq(customers.companyId, companyId), eq(customers.phone, phone))).limit(1);
      if (dup.length) {
        skipped += 1;
        errors.push(`Row ${i + 1}: ${name} skipped because the phone already exists.`);
        continue;
      }
    }
    const code = await nextNumber(db, companyId, "customer");
    await db.insert(customers).values({
      companyId,
      customerCode: code,
      name,
      phone: phone || null,
      email: email || null,
      address: index("address") >= 0 ? cells[index("address")] || null : null,
      source: index("source") >= 0 ? cells[index("source")] || "import" : "import",
      category: index("category") >= 0 ? cells[index("category")] || "general" : "general",
      verificationStatus: "pending",
      createdBy: ctx.user.id,
    });
    created += 1;
  }
  await audit(db, ctx, "import", "customer", null, { created, skipped }, companyId);
  return { created, skipped, errors };
}

export async function saveCompany(ctx: Ctx, form: FormData) {
  const id = Number(form.get("id") || 0);
  assertCan(ctx, "companies", id ? "edit" : "manage");
  const values = {
    name: textOf(form.get("name"), "Company name", true, 160),
    shortName: textOf(form.get("shortName"), "Short code", true, 12).toUpperCase().replace(/[^A-Z0-9]/g, ""),
    businessType: textOf(form.get("businessType"), "Business type", true, 40),
    registrationNo: textOf(form.get("registrationNo"), "Registration", false, 80) || null,
    address: textOf(form.get("address"), "Address", false, 400) || null,
    city: textOf(form.get("city"), "City", false, 80) || null,
    phone: textOf(form.get("phone"), "Phone", false, 40) || null,
    email: textOf(form.get("email"), "Email", false, 160) || null,
    website: textOf(form.get("website"), "Website", false, 160) || null,
    logoText: textOf(form.get("logoText"), "Logo text", false, 40) || null,
    brandColor: textOf(form.get("brandColor"), "Colour", false, 20) || "#0f6e68",
    accentColor: textOf(form.get("accentColor"), "Accent", false, 20) || "#a78445",
    invoicePrefix: textOf(form.get("invoicePrefix"), "Invoice prefix", false, 20) || "INV",
    receiptPrefix: textOf(form.get("receiptPrefix"), "Receipt prefix", false, 20) || "RCT",
    quotationPrefix: textOf(form.get("quotationPrefix"), "Quotation prefix", false, 20) || "QT",
    financialYearStart: textOf(form.get("financialYearStart"), "Financial year start", false, 5) || "07-01",
    currency: "BDT",
    taxName: textOf(form.get("taxName"), "Tax name", false, 40) || "VAT",
    taxRateBps: Math.round(Number(form.get("taxPercent") || 0) * 100),
    notes: textOf(form.get("notes"), "Notes", false, 2000) || null,
    active: form.get("active") !== "off",
    updatedAt: new Date(),
  };
  if (!values.shortName) throw new AppError("Short code should use letters or numbers, for example DH.");
  if (id) {
    if (!ctx.permissions.includes("*") && !ctx.companyIds.includes(id) && !ctx.can("companies", "manage")) {
      throw new AppError("You cannot edit that company.");
    }
    await db.update(companies).set(values).where(eq(companies.id, id));
    await audit(db, ctx, "update", "company", id, { name: values.name }, id);
    return id;
  }
  if (!ctx.permissions.includes("*") && !ctx.can("companies", "manage")) throw new AppError("Only the owner or a group administrator can add a company.");
  const [company] = await db.insert(companies).values(values).returning();
  await db.transaction(async (tx) => provisionCompany(tx as Writer, company));
  await db.insert(userCompanies).values({ userId: ctx.user.id, companyId: company.id, isDefault: false });
  await audit(db, ctx, "create", "company", company.id, { name: company.name }, company.id);
  return company.id;
}

export async function toggleModule(ctx: Ctx, companyId: number, moduleKey: string, enabled: boolean) {
  assertCan(ctx, "companies", "manage");
  if (!ctx.permissions.includes("*") && !ctx.companyIds.includes(companyId) && !ctx.can("group", "view")) {
    assertInScope(ctx, companyId);
  }
  await db
    .insert(companyModules)
    .values({ companyId, moduleKey, enabled })
    .onConflictDoUpdate({ target: [companyModules.companyId, companyModules.moduleKey], set: { enabled } });
  await audit(db, ctx, "module", "company", companyId, { moduleKey, enabled }, companyId);
}

export async function saveUser(ctx: Ctx, form: FormData) {
  assertCan(ctx, "settings", "manage");
  const id = Number(form.get("id") || 0);
  const name = textOf(form.get("name"), "Name", true, 120);
  const email = textOf(form.get("email"), "Email", true, 160).toLowerCase();
  const roleId = intOf(form.get("roleId"), "Role", true);
  if (!roleId) throw new AppError("Choose a role.");
  const [role] = await db.select().from(roles).where(eq(roles.id, roleId));
  if (!role) throw new AppError("That role does not exist.");
  if (role.key === "super_admin" && !ctx.permissions.includes("*")) throw new AppError("Only the owner can assign the owner role.");
  const password = String(form.get("password") || "");
  const companyIds = form.getAll("companyId").map(Number).filter(Boolean);
  if (!companyIds.length && role.key !== "super_admin") throw new AppError("Choose at least one company for this person.");
  if (id) {
    const patch: Record<string, unknown> = { name, email, roleId, phone: textOf(form.get("phone"), "Phone") || null, active: form.get("active") !== "off", updatedAt: new Date() };
    if (password) {
      assertPasswordStrength(password);
      patch.passwordHash = hashPassword(password);
      patch.mustChangePassword = true;
    }
    await db.update(users).set(patch).where(eq(users.id, id));
    await db.delete(userCompanies).where(eq(userCompanies.userId, id));
  } else {
    if (!password) throw new AppError("Set a starting password.");
    assertPasswordStrength(password);
    const [user] = await db.insert(users).values({
      name,
      email,
      passwordHash: hashPassword(password),
      roleId,
      phone: textOf(form.get("phone"), "Phone") || null,
      active: true,
      extraPermissions: [],
      deniedPermissions: [],
      mustChangePassword: true,
    }).returning();
    await replaceCompanies(user.id, companyIds);
    await audit(db, ctx, "create", "user", user.id, { email });
    return user.id;
  }
  await replaceCompanies(id, companyIds);
  await audit(db, ctx, "update", "user", id, { email });
  return id;
}

async function replaceCompanies(userId: number, companyIds: number[]) {
  if (!companyIds.length) return;
  await db.insert(userCompanies).values(companyIds.map((companyId, index) => ({ userId, companyId, isDefault: index === 0 })));
}

export async function saveRole(ctx: Ctx, form: FormData) {
  if (!ctx.permissions.includes("*")) throw new AppError("Only the owner can create roles.");
  const name = textOf(form.get("name"), "Role name", true, 80);
  const key = name.toLowerCase().replace(/[^a-z0-9]+/g, "_").replace(/^_|_$/g, "");
  const permissions = form.getAll("permission").map(String);
  if (!permissions.length) throw new AppError("Tick at least one permission.");
  await db.insert(roles).values({ key, name, description: textOf(form.get("description"), "Description") || null, isSystem: false, permissions });
  await audit(db, ctx, "create", "role", null, { key });
}

export async function uploadDocument(ctx: Ctx, form: FormData) {
  assertCan(ctx, "documents", "create");
  const companyId = requireCompany(ctx);
  const file = form.get("file");
  if (!(file instanceof File) || file.size === 0) throw new AppError("Choose a file to upload.");
  if (file.size > 8 * 1024 * 1024) throw new AppError("This file is larger than 8 MB.");
  const allowed = new Set(["application/pdf", "image/jpeg", "image/png", "image/webp", "image/gif", "text/plain", "text/csv", "application/msword", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/vnd.ms-excel", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"]);
  if (file.type && !allowed.has(file.type)) throw new AppError("Use a PDF, image, Word, Excel, CSV, or text file.");
  const original = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
  const stored = `${randomBytes(16).toString("hex")}-${original || "file"}`;
  const relative = path.join(String(companyId), stored);
  const dir = path.join(process.cwd(), "storage", "uploads", String(companyId));
  await mkdir(dir, { recursive: true });
  await writeFile(path.join(dir, stored), Buffer.from(await file.arrayBuffer()));
  const visibility = form.get("visibility") === "restricted" ? "restricted" : "standard";
  const [doc] = await db.insert(documents).values({
    companyId,
    ownerEntity: textOf(form.get("ownerEntity"), "Linked to", false, 40) || "library",
    ownerId: intOf(form.get("ownerId"), "Record number"),
    title: textOf(form.get("title"), "Title", false, 160) || original || "Document",
    fileName: original || "file",
    storagePath: relative,
    mime: file.type || "application/octet-stream",
    size: file.size,
    visibility,
    uploadedBy: ctx.user.id,
    notes: textOf(form.get("notes"), "Notes") || null,
  }).returning();
  await audit(db, ctx, "upload", "document", doc.id, { title: doc.title, visibility }, companyId);
  return doc.id;
}

export async function verifyDocument(ctx: Ctx, id: number, verified: boolean) {
  assertCan(ctx, "documents", "verify");
  const [doc] = await db.select().from(documents).where(eq(documents.id, id));
  if (!doc) throw new AppError("Document not found.");
  assertInScope(ctx, doc.companyId);
  await db.update(documents).set({ verified, verifiedBy: ctx.user.id }).where(eq(documents.id, id));
  await audit(db, ctx, verified ? "verify" : "unverify", "document", id, null, doc.companyId);
}

export async function markSample(entity: string, entityId: number) {
  await db.execute(sql`insert into sample_markers (entity, entity_id) values (${entity}, ${entityId})`);
}

export { rolePresets, todayDhaka };
