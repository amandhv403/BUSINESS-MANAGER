import { and, asc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  accountTransactions,
  approvals,
  customers,
  expenseCategories,
  expenses,
  invoiceItems,
  invoices,
  journalEntries,
  journalLines,
  moneyAccounts,
  paymentAllocations,
  payments,
  products,
  receipts,
  stockMovements,
  suppliers,
} from "@/db/schema";
import { audit } from "../audit";
import { GL } from "../constants";
import { AppError } from "../errors";
import { assertCan, assertInScope, canApprove, requireCompany } from "../guard";
import { nextNumber } from "../sequence";
import type { Ctx, LineInput } from "../types";
import { glForAccountType, todayDhaka } from "../utils";
import type { Writer } from "../sequence";

type Tx = Writer;

export function priceLines(lines: LineInput[], taxRateBps: number, discountPaisa: number) {
  const clean = lines.filter((line) => line.description.trim());
  if (!clean.length) throw new AppError("Add at least one line with a description and price.");
  const priced = clean.map((line, index) => {
    if (line.qty < 1) throw new AppError("Quantity must be at least 1.");
    if (line.unitPaisa < 0) throw new AppError("Price cannot be negative.");
    const kind = line.kind || "service";
    const gross = line.qty * line.unitPaisa;
    const tax = kind === "third_party" ? 0 : Math.round((gross * taxRateBps) / 10000);
    return {
      description: line.description.trim(),
      qty: line.qty,
      unitPaisa: line.unitPaisa,
      kind,
      productId: line.productId ?? null,
      serviceId: line.serviceId ?? null,
      gross,
      tax,
      lineTotalPaisa: gross + tax,
      sortOrder: index,
    };
  });
  const subtotal = priced.reduce((sum, line) => sum + line.gross, 0);
  const tax = priced.reduce((sum, line) => sum + line.tax, 0);
  if (discountPaisa < 0 || discountPaisa > subtotal) throw new AppError("Discount cannot be more than the subtotal.");
  return {
    priced,
    subtotal,
    tax,
    discountPaisa,
    service: priced.filter((l) => l.kind === "service").reduce((s, l) => s + l.gross, 0),
    product: priced.filter((l) => l.kind === "product").reduce((s, l) => s + l.gross, 0),
    third: priced.filter((l) => l.kind === "third_party").reduce((s, l) => s + l.gross, 0),
    total: subtotal + tax - discountPaisa,
  };
}

export async function postJournal(
  tx: Tx,
  input: {
    companyId: number;
    entryDate: string;
    memo: string;
    source?: string | null;
    sourceId?: number | null;
    createdBy?: number | null;
    lines: { glCode: string; accountId?: number | null; debitPaisa?: number; creditPaisa?: number; memo?: string | null }[];
  },
) {
  const lines = input.lines
    .map((line) => ({
      glCode: line.glCode,
      accountId: line.accountId ?? null,
      debitPaisa: line.debitPaisa || 0,
      creditPaisa: line.creditPaisa || 0,
      memo: line.memo ?? null,
    }))
    .filter((line) => line.debitPaisa || line.creditPaisa);
  const debit = lines.reduce((sum, line) => sum + line.debitPaisa, 0);
  const credit = lines.reduce((sum, line) => sum + line.creditPaisa, 0);
  if (debit !== credit) throw new AppError("The books did not balance, so this was not saved.");
  if (!lines.length) return null;
  const [entry] = await tx
    .insert(journalEntries)
    .values({
      companyId: input.companyId,
      entryDate: input.entryDate,
      memo: input.memo,
      source: input.source ?? null,
      sourceId: input.sourceId ?? null,
      createdBy: input.createdBy ?? null,
    })
    .returning();
  await tx.insert(journalLines).values(lines.map((line) => ({ ...line, entryId: entry.id })));
  return entry;
}

async function accountDelta(tx: Tx, accountId: number, companyId: number, delta: number, info: {
  date: string;
  description: string;
  reference?: string | null;
  source?: string | null;
  sourceId?: number | null;
  userId?: number | null;
}) {
  const updated = await tx.execute(sql`
    UPDATE money_accounts
    SET current_paisa = current_paisa + ${delta}, updated_at = now()
    WHERE id = ${accountId} AND company_id = ${companyId} AND active = true AND current_paisa + ${delta} >= 0
    RETURNING id, name, account_type
  `);
  const row = updated.rows[0] as { id: number; name: string; account_type: string } | undefined;
  if (!row) throw new AppError("That cash, bank, or mobile account is missing, inactive, or does not have enough money.");
  await tx.insert(accountTransactions).values({
    companyId,
    accountId,
    txnDate: info.date,
    direction: delta >= 0 ? "in" : "out",
    amountPaisa: Math.abs(delta),
    description: info.description,
    reference: info.reference ?? null,
    source: info.source ?? null,
    sourceId: info.sourceId ?? null,
    createdBy: info.userId ?? null,
  });
  return row;
}

function invoiceJournalLines(priced: ReturnType<typeof priceLines>) {
  const lines: { glCode: string; debitPaisa?: number; creditPaisa?: number; memo?: string }[] = [
    { glCode: GL.ar, debitPaisa: priced.total, memo: "Customer amount" },
  ];
  if (priced.service) lines.push({ glCode: GL.serviceRevenue, creditPaisa: priced.service });
  if (priced.product) lines.push({ glCode: GL.productRevenue, creditPaisa: priced.product });
  if (priced.third) lines.push({ glCode: GL.thirdParty, creditPaisa: priced.third });
  if (priced.tax) lines.push({ glCode: GL.tax, creditPaisa: priced.tax });
  if (priced.discountPaisa) lines.push({ glCode: GL.discount, debitPaisa: priced.discountPaisa, memo: "Discount" });
  return lines;
}

export async function createInvoiceTx(
  tx: Tx,
  ctx: Ctx,
  input: {
    companyId: number;
    customerId: number;
    issueDate: string;
    dueDate?: string | null;
    lines: LineInput[];
    discountPaisa: number;
    notes?: string | null;
    quotationId?: number | null;
    salesOrderId?: number | null;
    fulfillmentStatus?: string | null;
    deliveryAddress?: string | null;
    issueNow: boolean;
  },
) {
  const company = ctx.companies.find((item) => item.id === input.companyId) ?? ctx.company;
  const taxRate = company?.taxRateBps ?? 0;
  const priced = priceLines(input.lines, taxRate, input.discountPaisa);
  const discountRate = priced.subtotal ? priced.discountPaisa / priced.subtotal : 0;
  const needsDiscountApproval = discountRate > 0.1 && !canApprove(ctx, "accounting");
  const number = await nextNumber(tx, input.companyId, "invoice");
  const status = !input.issueNow ? "draft" : needsDiscountApproval ? "pending_approval" : "issued";
  const [invoice] = await tx
    .insert(invoices)
    .values({
      companyId: input.companyId,
      number,
      customerId: input.customerId,
      quotationId: input.quotationId ?? null,
      salesOrderId: input.salesOrderId ?? null,
      status,
      issueDate: input.issueDate,
      dueDate: input.dueDate ?? null,
      subtotalPaisa: priced.subtotal,
      discountPaisa: priced.discountPaisa,
      taxPaisa: priced.tax,
      totalPaisa: priced.total,
      paidPaisa: 0,
      duePaisa: status === "issued" ? priced.total : priced.total,
      servicePaisa: priced.service,
      productPaisa: priced.product,
      thirdPartyPaisa: priced.third,
      fulfillmentStatus: input.fulfillmentStatus ?? null,
      deliveryAddress: input.deliveryAddress ?? null,
      notes: input.notes ?? null,
      createdBy: ctx.user.id,
    })
    .returning();
  if (priced.priced.length) {
    await tx.insert(invoiceItems).values(
      priced.priced.map((line) => ({
        invoiceId: invoice.id,
        description: line.description,
        qty: line.qty,
        unitPaisa: line.unitPaisa,
        discountPaisa: 0,
        taxPaisa: line.tax,
        lineTotalPaisa: line.lineTotalPaisa,
        kind: line.kind,
        productId: line.productId,
        serviceId: line.serviceId,
        sortOrder: line.sortOrder,
      })),
    );
  }
  if (status === "issued") {
    await postJournal(tx, {
      companyId: input.companyId,
      entryDate: input.issueDate,
      memo: `Invoice ${number}`,
      source: "invoice",
      sourceId: invoice.id,
      createdBy: ctx.user.id,
      lines: invoiceJournalLines(priced),
    });
  }
  if (status === "pending_approval") {
    await tx.insert(approvals).values({
      companyId: input.companyId,
      type: "discount",
      entity: "invoice",
      entityId: invoice.id,
      requesterId: ctx.user.id,
      reason: "Discount is above 10%.",
      payload: { invoiceId: invoice.id },
    });
  }
  await audit(tx, ctx, "create", "invoice", invoice.id, { number, status, total: priced.total }, input.companyId);
  return invoice;
}

export async function saveInvoice(ctx: Ctx, input: Parameters<typeof createInvoiceTx>[2]) {
  assertCan(ctx, "accounting", "create");
  assertInScope(ctx, input.companyId);
  return db.transaction(async (tx) => createInvoiceTx(tx as unknown as Tx, ctx, input));
}

async function openInvoices(tx: Tx, companyId: number, customerId: number, invoiceId?: number | null) {
  if (invoiceId) {
    const rows = await tx
      .select()
      .from(invoices)
      .where(and(eq(invoices.id, invoiceId), eq(invoices.companyId, companyId), eq(invoices.customerId, customerId)))
      .for("update");
    return (rows as { status: string; duePaisa: number; id: number; paidPaisa: number; totalPaisa: number; issueDate: string }[]).filter((row) => row.status === "issued" || row.status === "partial");
  }
  return tx
    .select()
    .from(invoices)
    .where(and(eq(invoices.companyId, companyId), eq(invoices.customerId, customerId), inArray(invoices.status, ["issued", "partial"])))
    .orderBy(asc(invoices.issueDate), asc(invoices.id))
    .for("update");
}

export async function applyIncomingPayment(
  tx: Tx,
  ctx: Ctx,
  input: {
    companyId: number;
    customerId: number;
    amountPaisa: number;
    method: string;
    reference?: string | null;
    accountId?: number | null;
    paidOn: string;
    invoiceId?: number | null;
    allocateOldest?: boolean;
    notes?: string | null;
    fromCredit?: boolean;
  },
) {
  if (input.amountPaisa <= 0) throw new AppError("Enter an amount greater than zero.");
  const [customer] = await tx
    .select()
    .from(customers)
    .where(and(eq(customers.id, input.customerId), eq(customers.companyId, input.companyId)))
    .for("update");
  if (!customer) throw new AppError("That customer is not in the selected company.");
  if (input.reference) {
    const dup = await tx
      .select({ id: payments.id })
      .from(payments)
      .where(and(eq(payments.companyId, input.companyId), eq(payments.reference, input.reference), eq(payments.status, "posted")));
    if (dup.length) throw new AppError("This transaction reference was already used, so the payment was not recorded again.");
  }
  if (input.fromCredit && customer.creditPaisa < input.amountPaisa) {
    throw new AppError("The customer advance is smaller than the amount you want to use.");
  }
  const candidates = input.invoiceId || input.allocateOldest ? await openInvoices(tx, input.companyId, input.customerId, input.allocateOldest ? null : input.invoiceId) : [];
  if (input.invoiceId && !candidates.length) throw new AppError("That invoice is not open for payment.");
  const previousDue = candidates.reduce((sum: number, row: { duePaisa: number }) => sum + row.duePaisa, 0);
  let left = input.amountPaisa;
  const allocations: { invoiceId: number; amount: number }[] = [];
  for (const invoice of candidates) {
    if (left <= 0) break;
    const take = Math.min(left, invoice.duePaisa);
    if (take <= 0) continue;
    allocations.push({ invoiceId: invoice.id, amount: take });
    const due = invoice.duePaisa - take;
    await tx
      .update(invoices)
      .set({
        paidPaisa: invoice.paidPaisa + take,
        duePaisa: due,
        status: due === 0 ? "paid" : "partial",
        updatedAt: new Date(),
      })
      .where(eq(invoices.id, invoice.id));
    left -= take;
  }
  const allocated = input.amountPaisa - left;
  const advance = input.fromCredit ? 0 : left;
  if (input.fromCredit) {
    await tx
      .update(customers)
      .set({ creditPaisa: customer.creditPaisa - input.amountPaisa, updatedAt: new Date() })
      .where(eq(customers.id, customer.id));
  } else if (advance) {
    await tx
      .update(customers)
      .set({ creditPaisa: customer.creditPaisa + advance, updatedAt: new Date() })
      .where(eq(customers.id, customer.id));
  }
  let receiptId: number | null = null;
  let receiptNumber: string | null = null;
  if (!input.fromCredit) {
    receiptNumber = await nextNumber(tx, input.companyId, "receipt");
    const [receipt] = await tx
      .insert(receipts)
      .values({
        companyId: input.companyId,
        number: receiptNumber,
        customerId: input.customerId,
        invoiceId: allocations[0]?.invoiceId ?? input.invoiceId ?? null,
        receiptDate: input.paidOn,
        amountPaisa: input.amountPaisa,
        previousBalancePaisa: previousDue,
        remainingBalancePaisa: Math.max(previousDue - allocated, 0),
        method: input.method,
        reference: input.reference ?? null,
        receivedBy: ctx.user.id,
        authorisedBy: canApprove(ctx, "accounting") ? ctx.user.id : null,
        notes: input.notes ?? null,
        createdBy: ctx.user.id,
      })
      .returning();
    receiptId = receipt.id;
    if (!input.accountId) throw new AppError("Choose the cash, bank, or mobile account that received the money.");
    const account = await accountDelta(tx, input.accountId, input.companyId, input.amountPaisa, {
      date: input.paidOn,
      description: `Receipt ${receiptNumber}`,
      reference: input.reference,
      source: "receipt",
      sourceId: receipt.id,
      userId: ctx.user.id,
    });
    await postJournal(tx, {
      companyId: input.companyId,
      entryDate: input.paidOn,
      memo: `Receipt ${receiptNumber}`,
      source: "receipt",
      sourceId: receipt.id,
      createdBy: ctx.user.id,
      lines: [
        { glCode: glForAccountType(account.account_type), accountId: account.id, debitPaisa: input.amountPaisa },
        ...(allocated ? [{ glCode: GL.ar, creditPaisa: allocated }] : []),
        ...(advance ? [{ glCode: GL.advances, creditPaisa: advance }] : []),
      ],
    });
  } else {
    await postJournal(tx, {
      companyId: input.companyId,
      entryDate: input.paidOn,
      memo: `Advance used for ${customer.name}`,
      source: "credit",
      sourceId: customer.id,
      createdBy: ctx.user.id,
      lines: [
        { glCode: GL.advances, debitPaisa: input.amountPaisa },
        { glCode: GL.ar, creditPaisa: input.amountPaisa },
      ],
    });
  }
  const [payment] = await tx
    .insert(payments)
    .values({
      companyId: input.companyId,
      customerId: input.customerId,
      receiptId,
      invoiceId: allocations[0]?.invoiceId ?? null,
      amountPaisa: input.amountPaisa,
      method: input.fromCredit ? "advance" : input.method,
      reference: input.reference ?? null,
      kind: input.fromCredit ? "adjustment" : advance === input.amountPaisa ? "advance" : "payment",
      direction: "in",
      paidOn: input.paidOn,
      accountId: input.accountId ?? null,
      notes: input.notes ?? null,
      createdBy: ctx.user.id,
    })
    .returning();
  if (allocations.length) {
    await tx.insert(paymentAllocations).values(allocations.map((row) => ({ paymentId: payment.id, invoiceId: row.invoiceId, amountPaisa: row.amount })));
  }
  await audit(tx, ctx, "payment", "payment", payment.id, { amount: input.amountPaisa, receiptNumber }, input.companyId);
  return { paymentId: payment.id, receiptId, receiptNumber, allocated, advance };
}

export async function recordPayment(ctx: Ctx, input: Parameters<typeof applyIncomingPayment>[2]) {
  assertCan(ctx, "accounting", "create");
  assertInScope(ctx, input.companyId);
  return db.transaction(async (tx) => applyIncomingPayment(tx as unknown as Tx, ctx, input));
}

export async function applyRefund(
  tx: Tx,
  ctx: Ctx,
  input: { companyId: number; customerId: number; amountPaisa: number; accountId: number; method: string; reference?: string | null; invoiceId?: number | null; notes?: string | null; paidOn: string },
) {
  if (input.amountPaisa <= 0) throw new AppError("Enter a refund amount greater than zero.");
  const [customer] = await tx.select().from(customers).where(and(eq(customers.id, input.customerId), eq(customers.companyId, input.companyId))).for("update");
  if (!customer) throw new AppError("That customer is not in the selected company.");
  if (input.invoiceId) {
    const [invoice] = await tx.select().from(invoices).where(and(eq(invoices.id, input.invoiceId), eq(invoices.companyId, input.companyId))).for("update");
    if (!invoice || invoice.paidPaisa < input.amountPaisa) throw new AppError("You cannot refund more than the customer has paid on that invoice.");
    const paid = invoice.paidPaisa - input.amountPaisa;
    const due = invoice.duePaisa + input.amountPaisa;
    await tx.update(invoices).set({ paidPaisa: paid, duePaisa: due, status: due === invoice.totalPaisa ? "issued" : "partial", updatedAt: new Date() }).where(eq(invoices.id, invoice.id));
    await postJournal(tx, {
      companyId: input.companyId,
      entryDate: input.paidOn,
      memo: `Refund on ${invoice.number}`,
      source: "refund",
      sourceId: invoice.id,
      createdBy: ctx.user.id,
      lines: [
        { glCode: GL.ar, debitPaisa: input.amountPaisa },
        { glCode: glForAccountType((await accountDelta(tx, input.accountId, input.companyId, -input.amountPaisa, { date: input.paidOn, description: `Refund ${invoice.number}`, reference: input.reference, source: "refund", sourceId: invoice.id, userId: ctx.user.id })).account_type), creditPaisa: input.amountPaisa, accountId: input.accountId },
      ],
    });
  } else {
    if (customer.creditPaisa < input.amountPaisa) throw new AppError("The customer advance is not large enough for this refund.");
    await tx.update(customers).set({ creditPaisa: customer.creditPaisa - input.amountPaisa, updatedAt: new Date() }).where(eq(customers.id, customer.id));
    const account = await accountDelta(tx, input.accountId, input.companyId, -input.amountPaisa, {
      date: input.paidOn,
      description: `Advance refund for ${customer.name}`,
      reference: input.reference,
      source: "refund",
      sourceId: customer.id,
      userId: ctx.user.id,
    });
    await postJournal(tx, {
      companyId: input.companyId,
      entryDate: input.paidOn,
      memo: `Advance refund for ${customer.name}`,
      source: "refund",
      sourceId: customer.id,
      createdBy: ctx.user.id,
      lines: [
        { glCode: GL.advances, debitPaisa: input.amountPaisa },
        { glCode: glForAccountType(account.account_type), accountId: account.id, creditPaisa: input.amountPaisa },
      ],
    });
  }
  const number = await nextNumber(tx, input.companyId, "refund");
  const [payment] = await tx.insert(payments).values({
    companyId: input.companyId,
    customerId: input.customerId,
    invoiceId: input.invoiceId ?? null,
    amountPaisa: input.amountPaisa,
    method: input.method,
    reference: input.reference ?? null,
    kind: "refund",
    direction: "out",
    paidOn: input.paidOn,
    accountId: input.accountId,
    notes: input.notes ?? null,
    createdBy: ctx.user.id,
  }).returning();
  await audit(tx, ctx, "refund", "payment", payment.id, { number, amount: input.amountPaisa }, input.companyId);
  return payment;
}

export async function requestOrRefund(ctx: Ctx, input: Parameters<typeof applyRefund>[2]) {
  assertCan(ctx, "accounting", "create");
  assertInScope(ctx, input.companyId);
  if (!input.notes?.trim()) throw new AppError("Write a reason for the refund.");
  if (!canApprove(ctx, "accounting")) {
    await db.insert(approvals).values({
      companyId: input.companyId,
      type: "refund",
      entity: "customer",
      entityId: input.customerId,
      requesterId: ctx.user.id,
      reason: input.notes,
      payload: input,
    });
    await audit(db, ctx, "request", "refund", input.customerId, input, input.companyId);
    return { pending: true };
  }
  const payment = await db.transaction(async (tx) => applyRefund(tx as unknown as Tx, ctx, input));
  return { pending: false, payment };
}

export async function cancelReceipt(ctx: Ctx, receiptId: number, reason: string) {
  assertCan(ctx, "accounting", "edit");
  if (!reason.trim()) throw new AppError("A cancellation reason is required.");
  const [receipt] = await db.select().from(receipts).where(eq(receipts.id, receiptId));
  if (!receipt) throw new AppError("Receipt not found.");
  assertInScope(ctx, receipt.companyId);
  if (receipt.status === "cancelled") throw new AppError("This receipt is already cancelled. Its number will not be used again.");
  if (!canApprove(ctx, "accounting")) {
    await db.insert(approvals).values({
      companyId: receipt.companyId,
      type: "receipt_cancellation",
      entity: "receipt",
      entityId: receipt.id,
      requesterId: ctx.user.id,
      reason,
      payload: { receiptId, reason },
    });
    return { pending: true };
  }
  await db.transaction(async (tx) => reverseReceipt(tx as unknown as Tx, ctx, receiptId, reason));
  return { pending: false };
}

export async function reverseReceipt(tx: Tx, ctx: Ctx, receiptId: number, reason: string) {
  const [receipt] = await tx.select().from(receipts).where(eq(receipts.id, receiptId)).for("update");
  if (!receipt || receipt.status === "cancelled") throw new AppError("This receipt is already cancelled.");
  const [payment] = await tx.select().from(payments).where(eq(payments.receiptId, receipt.id)).for("update");
  if (!payment || payment.status !== "posted") throw new AppError("The payment behind this receipt cannot be reversed.");
  const allocations = await tx.select().from(paymentAllocations).where(eq(paymentAllocations.paymentId, payment.id));
  const allocated = allocations.reduce((sum: number, row: { amountPaisa: number }) => sum + row.amountPaisa, 0);
  const creditAdded = payment.amountPaisa - allocated;
  const [customer] = await tx.select().from(customers).where(eq(customers.id, receipt.customerId)).for("update");
  if (creditAdded > 0 && (customer?.creditPaisa ?? 0) < creditAdded) {
    throw new AppError("This receipt cannot be cancelled because its advance has already been used. Record an adjustment instead.");
  }
  for (const allocation of allocations) {
    const [invoice] = await tx.select().from(invoices).where(eq(invoices.id, allocation.invoiceId)).for("update");
    if (!invoice) continue;
    const paid = invoice.paidPaisa - allocation.amountPaisa;
    const due = invoice.duePaisa + allocation.amountPaisa;
    await tx.update(invoices).set({
      paidPaisa: paid,
      duePaisa: due,
      status: invoice.status === "cancelled" ? "cancelled" : due === invoice.totalPaisa ? "issued" : "partial",
      updatedAt: new Date(),
    }).where(eq(invoices.id, invoice.id));
  }
  if (creditAdded && customer) {
    await tx.update(customers).set({ creditPaisa: customer.creditPaisa - creditAdded, updatedAt: new Date() }).where(eq(customers.id, customer.id));
  }
  if (payment.accountId) {
    const account = await accountDelta(tx, payment.accountId, receipt.companyId, -payment.amountPaisa, {
      date: todayDhaka(),
      description: `Cancel receipt ${receipt.number}`,
      reference: receipt.number,
      source: "receipt_cancel",
      sourceId: receipt.id,
      userId: ctx.user.id,
    });
    await postJournal(tx, {
      companyId: receipt.companyId,
      entryDate: todayDhaka(),
      memo: `Cancel receipt ${receipt.number}: ${reason}`,
      source: "receipt_cancel",
      sourceId: receipt.id,
      createdBy: ctx.user.id,
      lines: [
        ...(allocated ? [{ glCode: GL.ar, debitPaisa: allocated }] : []),
        ...(creditAdded ? [{ glCode: GL.advances, debitPaisa: creditAdded }] : []),
        { glCode: glForAccountType(account.account_type), accountId: account.id, creditPaisa: payment.amountPaisa },
      ],
    });
  }
  await tx.update(receipts).set({ status: "cancelled", cancelReason: reason, cancelledAt: new Date(), updatedAt: new Date() }).where(eq(receipts.id, receipt.id));
  await tx.update(payments).set({ status: "cancelled" }).where(eq(payments.id, payment.id));
  await audit(tx, ctx, "cancel", "receipt", receipt.id, { reason, number: receipt.number }, receipt.companyId);
}

export async function cancelInvoice(ctx: Ctx, invoiceId: number, reason: string) {
  assertCan(ctx, "accounting", "edit");
  if (!reason.trim()) throw new AppError("A cancellation reason is required.");
  const [invoice] = await db.select().from(invoices).where(eq(invoices.id, invoiceId));
  if (!invoice) throw new AppError("Invoice not found.");
  assertInScope(ctx, invoice.companyId);
  if (invoice.status === "cancelled") throw new AppError("This invoice is already cancelled. Its number will not be used again.");
  if (invoice.paidPaisa > 0) throw new AppError("Cancel the related receipts before cancelling this invoice.");
  if (!canApprove(ctx, "accounting")) {
    await db.insert(approvals).values({
      companyId: invoice.companyId,
      type: "invoice_cancellation",
      entity: "invoice",
      entityId: invoice.id,
      requesterId: ctx.user.id,
      reason,
      payload: { invoiceId, reason },
    });
    return { pending: true };
  }
  await db.transaction(async (tx) => {
    const writer = tx as unknown as Tx;
    if (invoice.status === "issued" || invoice.status === "partial") {
      const original = await writer.select().from(journalEntries).where(and(eq(journalEntries.source, "invoice"), eq(journalEntries.sourceId, invoice.id)));
      for (const entry of original) {
        const lines = await writer.select().from(journalLines).where(eq(journalLines.entryId, entry.id));
        await postJournal(writer, {
          companyId: invoice.companyId,
          entryDate: todayDhaka(),
          memo: `Cancel invoice ${invoice.number}: ${reason}`,
          source: "invoice_cancel",
          sourceId: invoice.id,
          createdBy: ctx.user.id,
          lines: lines.map((line: { glCode: string; accountId: number | null; creditPaisa: number; debitPaisa: number }) => ({
            glCode: line.glCode,
            accountId: line.accountId,
            debitPaisa: line.creditPaisa,
            creditPaisa: line.debitPaisa,
          })),
        });
      }
    }
    await writer.update(invoices).set({ status: "cancelled", cancelReason: reason, cancelledAt: new Date(), duePaisa: 0, updatedAt: new Date() }).where(eq(invoices.id, invoice.id));
    await audit(writer, ctx, "cancel", "invoice", invoice.id, { reason }, invoice.companyId);
  });
  return { pending: false };
}

export async function saveExpense(ctx: Ctx, input: {
  companyId: number;
  categoryId?: number | null;
  supplierId?: number | null;
  description: string;
  spentOn: string;
  amountPaisa: number;
  method: string;
  accountId?: number | null;
  notes?: string | null;
}) {
  assertCan(ctx, "accounting", "create");
  assertInScope(ctx, input.companyId);
  if (input.amountPaisa <= 0) throw new AppError("Enter an expense amount greater than zero.");
  const approved = canApprove(ctx, "accounting");
  return db.transaction(async (tx) => {
    const [expense] = await tx.insert(expenses).values({
      companyId: input.companyId,
      categoryId: input.categoryId ?? null,
      supplierId: input.supplierId ?? null,
      description: input.description,
      spentOn: input.spentOn,
      amountPaisa: input.amountPaisa,
      method: input.method,
      accountId: input.accountId ?? null,
      status: "pending_approval",
      enteredBy: ctx.user.id,
      notes: input.notes ?? null,
    }).returning();
    const writer = tx as unknown as Tx;
    if (!approved) {
      await writer.insert(approvals).values({
        companyId: input.companyId,
        type: "expense",
        entity: "expense",
        entityId: expense.id,
        requesterId: ctx.user.id,
        reason: input.description,
        payload: { expenseId: expense.id },
      });
    } else {
      await postExpense(writer, ctx, expense.id);
    }
    await audit(writer, ctx, "create", "expense", expense.id, { amount: input.amountPaisa }, input.companyId);
    return { ...expense, status: approved ? "recorded" : "pending_approval" };
  });
}

export async function postExpense(tx: Tx, ctx: Ctx, expenseId: number) {
  const [expense] = await tx.select().from(expenses).where(eq(expenses.id, expenseId)).for("update");
  if (!expense || expense.status === "recorded") return;
  if (!expense.accountId) throw new AppError("Choose the account that paid this expense.");
  const [category] = expense.categoryId ? await tx.select().from(expenseCategories).where(eq(expenseCategories.id, expense.categoryId)) : [undefined];
  const account = await accountDelta(tx, expense.accountId, expense.companyId, -expense.amountPaisa, {
    date: expense.spentOn,
    description: expense.description,
    source: "expense",
    sourceId: expense.id,
    userId: ctx.user.id,
  });
  await postJournal(tx, {
    companyId: expense.companyId,
    entryDate: expense.spentOn,
    memo: expense.description,
    source: "expense",
    sourceId: expense.id,
    createdBy: ctx.user.id,
    lines: [
      { glCode: category?.glCode || GL.expense, debitPaisa: expense.amountPaisa },
      { glCode: glForAccountType(account.account_type), accountId: account.id, creditPaisa: expense.amountPaisa },
    ],
  });
  await tx.update(expenses).set({ status: "recorded", updatedAt: new Date() }).where(eq(expenses.id, expense.id));
}

export async function transferFunds(ctx: Ctx, input: { fromId: number; toId: number; amountPaisa: number; date: string; notes?: string }) {
  assertCan(ctx, "accounting", "manage");
  const companyId = requireCompany(ctx);
  if (input.fromId === input.toId) throw new AppError("Choose two different accounts.");
  if (input.amountPaisa <= 0) throw new AppError("Enter an amount greater than zero.");
  await db.transaction(async (tx) => {
    const writer = tx as unknown as Tx;
    const from = await accountDelta(writer, input.fromId, companyId, -input.amountPaisa, { date: input.date, description: input.notes || "Transfer out", source: "transfer", userId: ctx.user.id });
    const to = await accountDelta(writer, input.toId, companyId, input.amountPaisa, { date: input.date, description: input.notes || "Transfer in", source: "transfer", userId: ctx.user.id });
    await postJournal(writer, {
      companyId,
      entryDate: input.date,
      memo: input.notes || `Transfer ${from.name} to ${to.name}`,
      source: "transfer",
      createdBy: ctx.user.id,
      lines: [
        { glCode: glForAccountType(to.account_type), accountId: to.id, debitPaisa: input.amountPaisa },
        { glCode: glForAccountType(from.account_type), accountId: from.id, creditPaisa: input.amountPaisa },
      ],
    });
    await audit(writer, ctx, "transfer", "account", input.fromId, input, companyId);
  });
}

export async function paySupplier(ctx: Ctx, input: { supplierId: number; amountPaisa: number; accountId: number; method: string; paidOn: string; reference?: string; notes?: string }) {
  assertCan(ctx, "procurement", "create");
  const companyId = requireCompany(ctx);
  if (input.amountPaisa <= 0) throw new AppError("Enter an amount greater than zero.");
  await db.transaction(async (tx) => {
    const writer = tx as unknown as Tx;
    const [supplier] = await writer.select().from(suppliers).where(and(eq(suppliers.id, input.supplierId), eq(suppliers.companyId, companyId))).for("update");
    if (!supplier) throw new AppError("That supplier is not in the selected company.");
    if (supplier.payablePaisa < input.amountPaisa) throw new AppError("You cannot pay more than the supplier balance.");
    const account = await accountDelta(writer, input.accountId, companyId, -input.amountPaisa, {
      date: input.paidOn,
      description: `Supplier payment ${supplier.name}`,
      reference: input.reference,
      source: "supplier_payment",
      sourceId: supplier.id,
      userId: ctx.user.id,
    });
    await writer.update(suppliers).set({ payablePaisa: supplier.payablePaisa - input.amountPaisa, updatedAt: new Date() }).where(eq(suppliers.id, supplier.id));
    await postJournal(writer, {
      companyId,
      entryDate: input.paidOn,
      memo: `Supplier payment ${supplier.name}`,
      source: "supplier_payment",
      sourceId: supplier.id,
      createdBy: ctx.user.id,
      lines: [
        { glCode: GL.ap, debitPaisa: input.amountPaisa },
        { glCode: glForAccountType(account.account_type), accountId: account.id, creditPaisa: input.amountPaisa },
      ],
    });
    await writer.insert(payments).values({
      companyId,
      supplierId: supplier.id,
      amountPaisa: input.amountPaisa,
      method: input.method,
      reference: input.reference ?? null,
      kind: "supplier",
      direction: "out",
      paidOn: input.paidOn,
      accountId: input.accountId,
      notes: input.notes ?? null,
      createdBy: ctx.user.id,
    });
    await audit(writer, ctx, "pay", "supplier", supplier.id, { amount: input.amountPaisa }, companyId);
  });
}

export async function adjustStock(ctx: Ctx, productId: number, qtyChange: number, reason: string) {
  assertCan(ctx, "inventory", "edit");
  const companyId = requireCompany(ctx);
  if (!qtyChange) throw new AppError("Enter a quantity change.");
  await db.transaction(async (tx) => {
    const writer = tx as unknown as Tx;
    const [product] = await writer.select().from(products).where(and(eq(products.id, productId), eq(products.companyId, companyId))).for("update");
    if (!product) throw new AppError("Product not found in this company.");
    if (product.stockQty + qtyChange < 0) throw new AppError("Stock cannot go below zero.");
    await writer.update(products).set({ stockQty: product.stockQty + qtyChange, updatedAt: new Date() }).where(eq(products.id, product.id));
    await writer.insert(stockMovements).values({
      companyId,
      productId,
      movementType: qtyChange > 0 ? "adjust_in" : "adjust_out",
      qty: qtyChange,
      notes: reason,
      createdBy: ctx.user.id,
    });
    await audit(writer, ctx, "stock", "product", product.id, { qtyChange, reason }, companyId);
  });
}

export async function openingBalance(tx: Tx, ctx: Ctx, accountId: number, amountPaisa: number, date: string) {
  if (amountPaisa <= 0) return;
  const [account] = await tx.select().from(moneyAccounts).where(eq(moneyAccounts.id, accountId));
  if (!account) return;
  await tx.update(moneyAccounts).set({ openingPaisa: amountPaisa, currentPaisa: account.currentPaisa + amountPaisa, updatedAt: new Date() }).where(eq(moneyAccounts.id, accountId));
  await tx.insert(accountTransactions).values({
    companyId: account.companyId,
    accountId,
    txnDate: date,
    direction: "in",
    amountPaisa,
    description: "Opening balance",
    source: "opening",
    sourceId: accountId,
    createdBy: ctx.user.id,
  });
  await postJournal(tx, {
    companyId: account.companyId,
    entryDate: date,
    memo: `Opening balance ${account.name}`,
    source: "opening",
    sourceId: accountId,
    createdBy: ctx.user.id,
    lines: [
      { glCode: glForAccountType(account.accountType), accountId, debitPaisa: amountPaisa },
      { glCode: "3000", creditPaisa: amountPaisa, memo: "Owner equity" },
    ],
  });
}
