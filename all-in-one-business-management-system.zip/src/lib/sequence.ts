import { sql } from "drizzle-orm";
import { AppError } from "./errors";

// Shared loosely so both the root client and a transaction can be passed through.
export type Writer = any;

export async function nextNumber(tx: Writer, companyId: number, docType: string) {
  const result = await tx.execute(sql`
    UPDATE number_sequences
    SET next_number = next_number + 1, updated_at = now()
    WHERE company_id = ${companyId} AND doc_type = ${docType}
    RETURNING prefix, next_number, pad
  `);
  const row = result.rows[0] as { prefix: string; next_number: number | string; pad: number | string } | undefined;
  if (!row) throw new AppError("Numbering is not set up for this company yet. Open the company and save it once.");
  const used = Number(row.next_number) - 1;
  return `${row.prefix}-${String(used).padStart(Number(row.pad) || 4, "0")}`;
}
