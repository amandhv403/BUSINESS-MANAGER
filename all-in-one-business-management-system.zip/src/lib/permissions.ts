export function allows(permissions: string[], module: string, action: string) {
  if (permissions.includes("*")) return true;
  if (permissions.includes(`${module}:manage`)) return true;
  if (permissions.includes(`${module}:${action}`)) return true;
  if (action !== "view" && permissions.includes(`${module}:manage`)) return true;
  return false;
}

export function assertAllowed(permissions: string[], module: string, action: string, message?: string) {
  if (!allows(permissions, module, action)) {
    throw new Error(message ?? "You do not have permission to do that.");
  }
}
