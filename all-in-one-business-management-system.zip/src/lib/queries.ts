import { and, asc, desc, eq, gte, ilike, inArray, lte, or, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  activities,
  approvals,
  attendance,
  auditLogs,
  assessments,
  backupLogs,
  campaigns,
  chartOfAccounts,
  companies,
  companyModules,
  consentRecords,
  countries,
  customers,
  documents,
  employees,
  expenseCategories,
  expenses,
  followUps,
  invoiceItems,
  invoices,
  journalEntries,
  journalLines,
  leads,
  leaveRequests,
  moneyAccounts,
  notifications,
  numberSequences,
  opportunities,
  passports,
  payments,
  payslips,
  products,
  receipts,
  roles,
  services,
  suppliers,
  universities,
  sampleMarkers,
  supportTickets,
  tasks,
  users,
  visaApplications,
  visaStatusHistory,
} from "@/db/schema";
import { ENTITIES } from "./registry";
import type { Ctx } from "./types";
import { addDays, likeTerm, monthKey, todayDhaka } from "./utils";

const money = (value: unknown) => Number(value ?? 0);

export async function lookups(ctx: Ctx) {
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const [customerRows, employeeRows, accountRows, productRows, countryRows, categoryRows, userRows, supplierRows, serviceRows, universityRows] = await Promise.all([
    db.select({ id: customers.id, name: customers.name, code: customers.customerCode, phone: customers.phone, creditPaisa: customers.creditPaisa }).from(customers).where(inArray(customers.companyId, ids)).orderBy(asc(customers.name)).limit(300),
    db.select({ id: employees.id, name: employees.name, code: employees.employeeCode, designation: employees.designation, companyId: employees.companyId, salaryPaisa: employees.salaryPaisa }).from(employees).where(inArray(employees.companyId, ids)).orderBy(asc(employees.name)),
    db.select().from(moneyAccounts).where(and(inArray(moneyAccounts.companyId, ids), eq(moneyAccounts.active, true))).orderBy(asc(moneyAccounts.name)),
    db.select().from(products).where(and(inArray(products.companyId, ids), eq(products.active, true))).orderBy(asc(products.name)).limit(300),
    db.select().from(countries).orderBy(asc(countries.name)),
    db.select().from(expenseCategories).where(inArray(expenseCategories.companyId, ids)),
    db.select({ id: users.id, name: users.name, email: users.email }).from(users).where(eq(users.active, true)).orderBy(asc(users.name)),
    db.select({ id: suppliers.id, name: suppliers.name }).from(suppliers).where(inArray(suppliers.companyId, ids)).orderBy(asc(suppliers.name)),
    db.select({ id: services.id, name: services.name }).from(services).where(inArray(services.companyId, ids)).orderBy(asc(services.name)),
    db.select({ id: universities.id, name: universities.name, country: universities.country }).from(universities).orderBy(asc(universities.name)),
  ]);
  return { customers: customerRows, employees: employeeRows, accounts: accountRows, products: productRows, countries: countryRows, categories: categoryRows, users: userRows, suppliers: supplierRows, services: serviceRows, universities: universityRows };
}

export async function dashboardData(ctx: Ctx) {
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const today = todayDhaka();
  const month = monthKey(today);
  const companyFilter = inArray(payments.companyId, ids);
  const [todayIn, monthIn, monthOut, outstanding, cash, pipeline, leadCount, visaCount, taskCount, lowStock, pendingApprovals, followDue, expiring, recent, comparison, backup] = await Promise.all([
    db.select({ v: sql<number>`coalesce(sum(${payments.amountPaisa}),0)::float8` }).from(payments).where(and(companyFilter, eq(payments.status, "posted"), eq(payments.direction, "in"), eq(payments.paidOn, today), inArray(payments.kind, ["payment", "advance"]))),
    db.select({ v: sql<number>`coalesce(sum(${payments.amountPaisa}),0)::float8` }).from(payments).where(and(companyFilter, eq(payments.status, "posted"), eq(payments.direction, "in"), sql`${payments.paidOn}::text like ${month + "%"}`, inArray(payments.kind, ["payment", "advance"]))),
    db.select({ v: sql<number>`coalesce(sum(${expenses.amountPaisa}),0)::float8` }).from(expenses).where(and(inArray(expenses.companyId, ids), eq(expenses.status, "recorded"), sql`${expenses.spentOn}::text like ${month + "%"}`)),
    db.select({ v: sql<number>`coalesce(sum(${invoices.duePaisa}),0)::float8` }).from(invoices).where(and(inArray(invoices.companyId, ids), inArray(invoices.status, ["issued", "partial"]))),
    db.select({ type: moneyAccounts.accountType, v: sql<number>`coalesce(sum(${moneyAccounts.currentPaisa}),0)::float8` }).from(moneyAccounts).where(and(inArray(moneyAccounts.companyId, ids), eq(moneyAccounts.active, true))).groupBy(moneyAccounts.accountType),
    db.select({ stage: opportunities.stage, n: sql<number>`count(*)::int` }).from(opportunities).where(inArray(opportunities.companyId, ids)).groupBy(opportunities.stage),
    db.select({ n: sql<number>`count(*)::int` }).from(leads).where(and(inArray(leads.companyId, ids), inArray(leads.status, ["new", "contacted", "interested", "follow-up"]))),
    db.select({ n: sql<number>`count(*)::int` }).from(visaApplications).where(and(inArray(visaApplications.companyId, ids), inArray(visaApplications.status, ["new", "consultation", "documents pending", "documents received", "under preparation", "ready for submission", "submitted", "embassy processing", "additional documents requested"]))),
    db.select({ n: sql<number>`count(*)::int` }).from(tasks).where(and(inArray(tasks.companyId, ids), inArray(tasks.status, ["open", "doing"]), lte(tasks.dueOn, today))),
    db.select({ n: sql<number>`count(*)::int` }).from(products).where(and(inArray(products.companyId, ids), sql`${products.stockQty} <= ${products.reorderLevel}`)),
    db.select({ n: sql<number>`count(*)::int` }).from(approvals).where(and(inArray(approvals.companyId, ids), eq(approvals.status, "pending"))),
    db.select().from(followUps).where(and(inArray(followUps.companyId, ids), eq(followUps.status, "open"), lte(followUps.dueOn, today))).orderBy(asc(followUps.dueOn)).limit(6),
    db.select({ id: passports.id, customerId: passports.customerId, expiryDate: passports.expiryDate, passportNo: passports.passportNo }).from(passports).where(and(inArray(passports.companyId, ids), lte(passports.expiryDate, addDays(today, 180)), gte(passports.expiryDate, addDays(today, -30)))).limit(6),
    db.select().from(activities).where(inArray(activities.companyId, ids)).orderBy(desc(activities.happenedAt)).limit(8),
    db.select({ companyId: payments.companyId, v: sql<number>`coalesce(sum(${payments.amountPaisa}),0)::float8` }).from(payments).where(and(companyFilter, eq(payments.status, "posted"), eq(payments.direction, "in"), sql`${payments.paidOn}::text like ${month + "%"}`)).groupBy(payments.companyId),
    db.select().from(backupLogs).where(eq(backupLogs.status, "verified")).orderBy(desc(backupLogs.createdAt)).limit(1),
  ]);
  const samples = await db.select({ n: sql<number>`count(*)::int` }).from(sampleMarkers);
  return {
    today: money(todayIn[0]?.v),
    monthIn: money(monthIn[0]?.v),
    monthOut: money(monthOut[0]?.v),
    outstanding: money(outstanding[0]?.v),
    cash: cash.map((row) => ({ type: row.type, amount: money(row.v) })),
    pipeline,
    leads: leadCount[0]?.n ?? 0,
    visas: visaCount[0]?.n ?? 0,
    tasks: taskCount[0]?.n ?? 0,
    lowStock: lowStock[0]?.n ?? 0,
    approvals: pendingApprovals[0]?.n ?? 0,
    followDue,
    expiring,
    recent,
    comparison: comparison.map((row) => ({ companyId: row.companyId, amount: money(row.v) })),
    lastBackup: backup[0] ?? null,
    sampleCount: samples[0]?.n ?? 0,
    todayDate: today,
  };
}

export async function listCustomers(ctx: Ctx, q: string, status: string, page: number) {
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const filters = [inArray(customers.companyId, ids)];
  if (status) filters.push(eq(customers.status, status));
  if (q) filters.push(or(ilike(customers.name, likeTerm(q)), ilike(customers.phone, likeTerm(q)), ilike(customers.email, likeTerm(q)), ilike(customers.customerCode, likeTerm(q)))!);
  const where = and(...filters);
  const rows = await db.select().from(customers).where(where).orderBy(desc(customers.id)).limit(15).offset((page - 1) * 15);
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(customers).where(where);
  return { rows, total: n };
}

export async function customerFile(ctx: Ctx, id: number) {
  const [customer] = await db.select().from(customers).where(eq(customers.id, id));
  if (!customer || !ctx.companyIds.includes(customer.companyId)) return null;
  const [timeline, bills, visas, dues, follows, tickets] = await Promise.all([
    db.select().from(activities).where(eq(activities.customerId, id)).orderBy(desc(activities.happenedAt)).limit(30),
    db.select().from(invoices).where(eq(invoices.customerId, id)).orderBy(desc(invoices.id)).limit(20),
    db.select().from(visaApplications).where(eq(visaApplications.customerId, id)).orderBy(desc(visaApplications.id)),
    db.select({ v: sql<number>`coalesce(sum(${invoices.duePaisa}),0)::float8` }).from(invoices).where(and(eq(invoices.customerId, id), inArray(invoices.status, ["issued", "partial"]))),
    db.select().from(followUps).where(eq(followUps.customerId, id)).orderBy(desc(followUps.dueOn)).limit(10),
    db.select().from(supportTickets).where(eq(supportTickets.customerId, id)).orderBy(desc(supportTickets.id)).limit(10),
  ]);
  return { customer, timeline, bills, visas, due: money(dues[0]?.v), follows, tickets };
}

export async function listInvoices(ctx: Ctx, q: string, page: number) {
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const filters = [inArray(invoices.companyId, ids)];
  if (q) filters.push(or(ilike(invoices.number, likeTerm(q)), sql`cast(${invoices.customerId} as text) = ${q}`)!);
  const where = and(...filters);
  const rows = await db.select().from(invoices).where(where).orderBy(desc(invoices.id)).limit(15).offset((page - 1) * 15);
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(invoices).where(where);
  return { rows, total: n };
}

export async function invoiceFile(ctx: Ctx, id: number) {
  const [invoice] = await db.select().from(invoices).where(eq(invoices.id, id));
  if (!invoice || !ctx.companyIds.includes(invoice.companyId)) return null;
  const [items, pays, customer, company, receiptRows] = await Promise.all([
    db.select().from(invoiceItems).where(eq(invoiceItems.invoiceId, invoice.id)),
    db.select().from(payments).where(eq(payments.invoiceId, invoice.id)).orderBy(desc(payments.id)),
    db.select().from(customers).where(eq(customers.id, invoice.customerId)),
    db.select().from(companies).where(eq(companies.id, invoice.companyId)),
    db.select().from(receipts).where(eq(receipts.invoiceId, invoice.id)),
  ]);
  return { invoice, items, pays, customer: customer[0], company: company[0], receipts: receiptRows };
}

export async function searchAll(ctx: Ctx, q: string) {
  if (!q || q.length < 2) return { customers: [], invoices: [], visas: [], employees: [] };
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const term = likeTerm(q);
  const [people, bills, visas, staff] = await Promise.all([
    db.select().from(customers).where(and(inArray(customers.companyId, ids), or(ilike(customers.name, term), ilike(customers.phone, term), ilike(customers.customerCode, term)))).limit(8),
    db.select().from(invoices).where(and(inArray(invoices.companyId, ids), ilike(invoices.number, term))).limit(8),
    db.select().from(visaApplications).where(and(inArray(visaApplications.companyId, ids), ilike(visaApplications.applicationCode, term))).limit(8),
    ctx.can("hrm", "view") ? db.select().from(employees).where(and(inArray(employees.companyId, ids), or(ilike(employees.name, term), ilike(employees.employeeCode, term)))).limit(8) : Promise.resolve([]),
  ]);
  return { customers: people, invoices: bills, visas, employees: staff };
}

export async function reportData(ctx: Ctx) {
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const month = monthKey();
  const [collections, expenseRows, outstanding, visaRows, leadRows, trial, campaignsRows] = await Promise.all([
    db.select({ companyId: payments.companyId, v: sql<number>`coalesce(sum(${payments.amountPaisa}),0)::float8` }).from(payments).where(and(inArray(payments.companyId, ids), eq(payments.status, "posted"), eq(payments.direction, "in"), sql`${payments.paidOn}::text like ${month + "%"}`)).groupBy(payments.companyId),
    db.select({ companyId: expenses.companyId, v: sql<number>`coalesce(sum(${expenses.amountPaisa}),0)::float8` }).from(expenses).where(and(inArray(expenses.companyId, ids), eq(expenses.status, "recorded"), sql`${expenses.spentOn}::text like ${month + "%"}`)).groupBy(expenses.companyId),
    db.select({ companyId: invoices.companyId, v: sql<number>`coalesce(sum(${invoices.duePaisa}),0)::float8` }).from(invoices).where(and(inArray(invoices.companyId, ids), inArray(invoices.status, ["issued", "partial"]))).groupBy(invoices.companyId),
    db.select({ status: visaApplications.status, n: sql<number>`count(*)::int` }).from(visaApplications).where(inArray(visaApplications.companyId, ids)).groupBy(visaApplications.status),
    db.select({ source: leads.source, n: sql<number>`count(*)::int` }).from(leads).where(inArray(leads.companyId, ids)).groupBy(leads.source),
    db.select({ glCode: journalLines.glCode, debit: sql<number>`coalesce(sum(${journalLines.debitPaisa}),0)::float8`, credit: sql<number>`coalesce(sum(${journalLines.creditPaisa}),0)::float8` }).from(journalLines).innerJoin(journalEntries, eq(journalEntries.id, journalLines.entryId)).where(inArray(journalEntries.companyId, ids)).groupBy(journalLines.glCode),
    db.select().from(campaigns).where(inArray(campaigns.companyId, ids)).limit(12),
  ]);
  const accounts = await db.select().from(chartOfAccounts).where(inArray(chartOfAccounts.companyId, ids));
  return {
    collections: collections.map((r) => ({ companyId: r.companyId, amount: money(r.v) })),
    expenses: expenseRows.map((r) => ({ companyId: r.companyId, amount: money(r.v) })),
    outstanding: outstanding.map((r) => ({ companyId: r.companyId, amount: money(r.v) })),
    visas: visaRows,
    leads: leadRows,
    trial: trial.map((r) => ({ glCode: r.glCode, debit: money(r.debit), credit: money(r.credit), name: accounts.find((a) => a.code === r.glCode)?.name || r.glCode, type: accounts.find((a) => a.code === r.glCode)?.accountType || "" })),
    campaigns: campaignsRows,
  };
}

export async function listEntity(ctx: Ctx, key: string, q: string, page: number, status: string) {
  const def = ENTITIES[key];
  if (!def) return { rows: [], total: 0, def: null };
  const table = def.table as any;
  const filters = [];
  if (def.scope === "company") filters.push(inArray(table.companyId, ctx.companyIds.length ? ctx.companyIds : [-1]));
  if (status && def.statusKey) filters.push(eq(table[def.statusKey], status));
  if (q && def.search[0]) filters.push(ilike(table[def.search[0]], likeTerm(q)));
  const where = filters.length ? and(...filters) : undefined;
  const rows = await db.select().from(table).where(where).orderBy(desc(table.id)).limit(15).offset((page - 1) * 15);
  const [{ n }] = await db.select({ n: sql<number>`count(*)::int` }).from(table).where(where);
  return { rows, total: n ?? 0, def };
}

export async function myDesk(ctx: Ctx) {
  const employeeId = ctx.user.employeeId;
  if (!employeeId) return { employee: null, attendance: [], leaves: [], slips: [], tasks: [] };
  const [employee] = await db.select().from(employees).where(eq(employees.id, employeeId));
  if (!employee || !ctx.companyIds.includes(employee.companyId) && !ctx.permissions.includes("*")) {
    if (employee && !ctx.permissions.includes("*") && !ctx.companyIds.includes(employee.companyId)) return { employee: null, attendance: [], leaves: [], slips: [], tasks: [] };
  }
  const [marks, leaves, slips, work] = await Promise.all([
    db.select().from(attendance).where(eq(attendance.employeeId, employeeId)).orderBy(desc(attendance.workDate)).limit(14),
    db.select().from(leaveRequests).where(eq(leaveRequests.employeeId, employeeId)).orderBy(desc(leaveRequests.id)).limit(10),
    ctx.can("payroll", "view") || true ? db.select().from(payslips).where(eq(payslips.employeeId, employeeId)).orderBy(desc(payslips.id)).limit(12) : Promise.resolve([]),
    db.select().from(tasks).where(eq(tasks.assignedUserId, ctx.user.id)).orderBy(desc(tasks.id)).limit(12),
  ]);
  return { employee, attendance: marks, leaves, slips, tasks: work };
}

export async function unreadCount(userId: number) {
  const [row] = await db.select({ n: sql<number>`count(*)::int` }).from(notifications).where(and(eq(notifications.userId, userId), sql`${notifications.readAt} is null`));
  return row?.n ?? 0;
}

export async function settingsData(ctx: Ctx) {
  const [roleRows, userRows, moduleRows, sequences] = await Promise.all([
    db.select().from(roles).orderBy(asc(roles.name)),
    ctx.can("settings", "view") || ctx.permissions.includes("*") ? db.select({ id: users.id, name: users.name, email: users.email, roleId: users.roleId, active: users.active, mustChangePassword: users.mustChangePassword }).from(users).orderBy(asc(users.name)) : Promise.resolve([]),
    ctx.company ? db.select().from(companyModules).where(eq(companyModules.companyId, ctx.company.id)) : Promise.resolve([]),
    ctx.company ? db.select().from(numberSequences).where(eq(numberSequences.companyId, ctx.company.id)) : Promise.resolve([]),
  ]);
  return { roles: roleRows, users: userRows, modules: moduleRows as { moduleKey: string; enabled: boolean }[], sequences };
}

export async function visaFile(ctx: Ctx, id: number) {
  const [app] = await db.select().from(visaApplications).where(eq(visaApplications.id, id));
  if (!app || !ctx.companyIds.includes(app.companyId)) return null;
  const [history, docs, passport, customer] = await Promise.all([
    db.select().from(visaStatusHistory).where(eq(visaStatusHistory.applicationId, id)).orderBy(desc(visaStatusHistory.id)),
    db.select().from(documents).where(and(eq(documents.ownerEntity, "visa"), eq(documents.ownerId, id))),
    app.passportId ? db.select().from(passports).where(eq(passports.id, app.passportId)) : Promise.resolve([]),
    db.select().from(customers).where(eq(customers.id, app.customerId)),
  ]);
  return { app, history, docs, passport: passport[0] ?? null, customer: customer[0] };
}

export async function pendingApprovals(ctx: Ctx) {
  return db.select().from(approvals).where(and(inArray(approvals.companyId, ctx.companyIds.length ? ctx.companyIds : [-1]), eq(approvals.status, "pending"))).orderBy(desc(approvals.id)).limit(50);
}

export async function auditRows(ctx: Ctx) {
  if (!ctx.can("audit", "view")) return [];
  return db.select().from(auditLogs).where(ctx.allMode ? undefined : inArray(auditLogs.companyId, ctx.companyIds)).orderBy(desc(auditLogs.id)).limit(80);
}

export async function privateRows(ctx: Ctx) {
  if (!ctx.can("sensitive", "view")) return { consents: [], assessments: [] };
  const ids = ctx.companyIds.length ? ctx.companyIds : [-1];
  const [consents, rows] = await Promise.all([
    db.select().from(consentRecords).where(inArray(consentRecords.companyId, ids)).orderBy(desc(consentRecords.id)).limit(30),
    db.select({ id: assessments.id, customerId: assessments.customerId, resultSummary: assessments.resultSummary, createdAt: assessments.createdAt }).from(assessments).where(inArray(assessments.companyId, ids)).orderBy(desc(assessments.id)).limit(30),
  ]);
  return { consents, assessments: rows };
}

export { quotations, purchaseOrders, sessionBookings, students, travelBookings, supportTickets, tasks, leads, opportunities } from "@/db/schema";
