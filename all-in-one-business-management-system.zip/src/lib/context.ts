import { cache } from "react";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { companies, companyModules, roles, sessions, userCompanies, users } from "@/db/schema";
import { readCompanyCookie, readSessionToken } from "./auth";
import { allows } from "./permissions";
import type { Ctx, SessionUser } from "./types";

export const getCurrentUser = cache(async (): Promise<SessionUser | null> => {
  const token = await readSessionToken();
  if (!token) return null;
  const [session] = await db.select().from(sessions).where(eq(sessions.id, token)).limit(1);
  if (!session || session.expiresAt < new Date()) return null;
  const [row] = await db
    .select({
      id: users.id,
      name: users.name,
      email: users.email,
      roleId: users.roleId,
      employeeId: users.employeeId,
      active: users.active,
      totpEnabled: users.totpEnabled,
      phone: users.phone,
      extra: users.extraPermissions,
      denied: users.deniedPermissions,
      roleKey: roles.key,
      roleName: roles.name,
      rolePerms: roles.permissions,
    })
    .from(users)
    .innerJoin(roles, eq(roles.id, users.roleId))
    .where(eq(users.id, session.userId))
    .limit(1);
  if (!row?.active) return null;
  const permissions = new Set([...(row.rolePerms ?? []), ...(row.extra ?? [])]);
  for (const denied of row.denied ?? []) permissions.delete(denied);
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    roleId: row.roleId,
    roleKey: row.roleKey,
    roleName: row.roleName,
    permissions: [...permissions],
    employeeId: row.employeeId,
    active: row.active,
    totpEnabled: row.totpEnabled,
    phone: row.phone,
  };
});

export const getContext = cache(async (): Promise<Ctx> => {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const access = await db.select().from(userCompanies).where(eq(userCompanies.userId, user.id));
  const isOwner = user.permissions.includes("*");
  const ids = access.map((row) => row.companyId);
  const visible = isOwner
    ? await db.select().from(companies).orderBy(companies.name)
    : ids.length
      ? await db.select().from(companies).where(inArray(companies.id, ids)).orderBy(companies.name)
      : [];
  if (!visible.length) {
    redirect("/login?error=" + encodeURIComponent("Your sign-in works, but you are not assigned to a company yet."));
  }
  const selected = await readCompanyCookie();
  const canAll = isOwner || allows(user.permissions, "group", "view");
  const allMode = selected === "all" && canAll;
  const fallback = visible.find((c) => access.some((a) => a.companyId === c.id && a.isDefault)) ?? visible[0];
  const company = allMode ? null : visible.find((c) => String(c.id) === selected) ?? fallback;
  const companyIds = allMode ? visible.filter((c) => c.active).map((c) => c.id) : company ? [company.id] : [];
  const moduleRows = companyIds.length
    ? await db.select().from(companyModules).where(inArray(companyModules.companyId, companyIds))
    : [];
  const modules = new Set<string>();
  for (const row of moduleRows) {
    if (!row.enabled) continue;
    if (allMode || row.companyId === company?.id) modules.add(row.moduleKey);
  }
  const accessRow = company ? access.find((a) => a.companyId === company.id) : undefined;
  const permissions = !isOwner && accessRow?.permissions?.length ? accessRow.permissions : user.permissions;
  const h = await headers();
  const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || "local";
  return {
    user,
    companies: visible.map((c) => ({
      id: c.id,
      name: c.name,
      shortName: c.shortName,
      businessType: c.businessType,
      brandColor: c.brandColor,
      accentColor: c.accentColor,
      city: c.city,
      currency: c.currency,
      taxName: c.taxName,
      taxRateBps: c.taxRateBps,
      address: c.address,
      phone: c.phone,
      email: c.email,
      logoText: c.logoText,
      invoicePrefix: c.invoicePrefix,
      receiptPrefix: c.receiptPrefix,
      active: c.active,
    })),
    company: company
      ? {
          id: company.id,
          name: company.name,
          shortName: company.shortName,
          businessType: company.businessType,
          brandColor: company.brandColor,
          accentColor: company.accentColor,
          city: company.city,
          currency: company.currency,
          taxName: company.taxName,
          taxRateBps: company.taxRateBps,
          address: company.address,
          phone: company.phone,
          email: company.email,
          logoText: company.logoText,
          invoicePrefix: company.invoicePrefix,
          receiptPrefix: company.receiptPrefix,
          active: company.active,
        }
      : null,
    companyIds,
    allMode,
    modules,
    branchId: allMode ? null : accessRow?.branchId ?? null,
    permissions,
    can: (module: string, action: string) => allows(permissions, module, action),
    ip,
  };
});

export function moduleEnabled(ctx: Ctx, module: string) {
  if (["dashboard", "companies", "settings", "audit"].includes(module)) return true;
  if (ctx.user.permissions.includes("*") && ctx.allMode) return true;
  return ctx.modules.has(module);
}
