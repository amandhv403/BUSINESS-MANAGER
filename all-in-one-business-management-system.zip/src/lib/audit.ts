import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs, notifications, roles, userCompanies, users } from "@/db/schema";
import type { Ctx } from "./types";
import type { Writer } from "./sequence";

export async function audit(
  writer: Writer,
  ctx: Ctx,
  action: string,
  entity: string,
  entityId: number | null,
  details?: unknown,
  companyId?: number | null,
) {
  await writer.insert(auditLogs).values({
    companyId: companyId === undefined ? ctx.company?.id ?? null : companyId,
    userId: ctx.user.id,
    action,
    entity,
    entityId,
    details: details ?? null,
    ip: ctx.ip,
  });
}

export async function notifyUser(
  userId: number,
  title: string,
  body: string,
  href?: string,
  dedupeKey?: string,
  companyId?: number | null,
) {
  if (!userId) return;
  if (dedupeKey) {
    const existing = await db
      .select({ id: notifications.id })
      .from(notifications)
      .where(and(eq(notifications.userId, userId), eq(notifications.dedupeKey, dedupeKey)))
      .limit(1);
    if (existing.length) return;
  }
  await db.insert(notifications).values({ userId, companyId: companyId ?? null, title, body, href, dedupeKey });
}

export async function notifyRoles(companyId: number, roleKeys: string[], title: string, body: string, href?: string) {
  const rows = await db
    .select({ id: users.id })
    .from(users)
    .innerJoin(userCompanies, eq(userCompanies.userId, users.id))
    .innerJoin(roles, eq(roles.id, users.roleId))
    .where(and(eq(userCompanies.companyId, companyId), eq(users.active, true)));
  const wanted = new Set(roleKeys);
  const roleRows = await db.select({ id: roles.id, key: roles.key }).from(roles);
  const roleIds = new Set(roleRows.filter((r) => wanted.has(r.key)).map((r) => r.id));
  const usersInRoles = await db
    .select({ id: users.id, roleId: users.roleId })
    .from(users)
    .innerJoin(userCompanies, eq(userCompanies.userId, users.id))
    .where(and(eq(userCompanies.companyId, companyId), eq(users.active, true)));
  for (const row of usersInRoles) {
    if (roleIds.has(row.roleId)) await notifyUser(row.id, title, body, href, undefined, companyId);
  }
  void rows;
}
