export type ActionState = { ok: false; message: string } | null;

export type SessionUser = {
  id: number;
  name: string;
  email: string;
  roleId: number;
  roleKey: string;
  roleName: string;
  permissions: string[];
  employeeId: number | null;
  active: boolean;
  totpEnabled: boolean;
  phone: string | null;
};

export type CompanyAccess = {
  companyId: number;
  branchId: number | null;
  isDefault: boolean;
  permissions: string[] | null;
};

export type Ctx = {
  user: SessionUser;
  companies: {
    id: number;
    name: string;
    shortName: string;
    businessType: string;
    brandColor: string;
    accentColor: string;
    city: string | null;
    currency: string;
    taxName: string;
    taxRateBps: number;
    address: string | null;
    phone: string | null;
    email: string | null;
    logoText: string | null;
    invoicePrefix: string;
    receiptPrefix: string;
    active: boolean;
  }[];
  company: Ctx["companies"][number] | null;
  companyIds: number[];
  allMode: boolean;
  modules: Set<string>;
  branchId: number | null;
  permissions: string[];
  can: (module: string, action: string) => boolean;
  ip: string;
};

export type LineInput = {
  description: string;
  qty: number;
  unitPaisa: number;
  kind: "service" | "product" | "third_party";
  productId?: number | null;
  serviceId?: number | null;
};

export type SearchParams = Record<string, string | string[] | undefined>;
