import { AppError } from "./errors";
import type { Ctx } from "./types";

export function requireCompany(ctx: Ctx) {
  if (!ctx.company) {
    throw new AppError("Choose one company in the top bar before adding a record. The group view is for looking across companies.");
  }
  if (!ctx.company.active) throw new AppError("This company is inactive. Activate it before adding records.");
  return ctx.company.id;
}

export function assertInScope(ctx: Ctx, companyId: number) {
  if (!ctx.companyIds.includes(companyId)) {
    throw new AppError("That record belongs to a company you cannot access.");
  }
}

export function assertCan(ctx: Ctx, module: string, action: string) {
  if (!ctx.can(module, action)) {
    throw new AppError("You do not have permission to do that. Ask the owner if you need access.");
  }
}

export function canApprove(ctx: Ctx, module: string) {
  return ctx.can(module, "approve") || ctx.can(module, "manage") || ctx.permissions.includes("*");
}
