export const APP_NAME = "AIO Desk";
export const APP_FULL_NAME = "All-in-One Business Management System";

export const MODULES = [
  { key: "crm", label: "Customers and leads", blurb: "People who enquire, buy, or need follow-up." },
  { key: "sales", label: "Sales", blurb: "Pipeline, quotations, and deal tracking." },
  { key: "marketing", label: "Marketing", blurb: "Campaigns, content plans, and marketing spend." },
  { key: "accounting", label: "Money", blurb: "Invoices, receipts, expenses, cash, and bank." },
  { key: "visa", label: "Visa", blurb: "Passports, applications, documents, and status." },
  { key: "travel", label: "Travel", blurb: "Tickets, hotels, tours, and transport." },
  { key: "education", label: "Education", blurb: "Students, universities, and admissions." },
  { key: "tourism", label: "Tourism projects", blurb: "Community, culture, homestay, and partners." },
  { key: "ecommerce", label: "Shop", blurb: "Products, stock, orders, and deliveries." },
  { key: "bookings", label: "Bookings", blurb: "Sessions, experiences, and appointments." },
  { key: "hrm", label: "People", blurb: "Employees, attendance, leave, and reviews." },
  { key: "payroll", label: "Payroll", blurb: "Salary, payslips, advances, and settlements." },
  { key: "office", label: "Office", blurb: "Tasks, meetings, visitors, and notices." },
  { key: "procurement", label: "Buying", blurb: "Suppliers, purchase orders, and supplier payments." },
  { key: "inventory", label: "Stock and assets", blurb: "Products, stationery, equipment, and maintenance." },
  { key: "support", label: "Support", blurb: "Complaints, tickets, and feedback." },
  { key: "targets", label: "Targets", blurb: "Goals for companies, teams, and people." },
  { key: "documents", label: "Documents", blurb: "Files, letter templates, and verification." },
  { key: "reports", label: "Reports", blurb: "Figures from the records in the database." },
  { key: "approvals", label: "Approvals", blurb: "Requests waiting for a yes or no." },
  { key: "sensitive", label: "Private records", blurb: "Questionnaires, consent, and companion notes." },
] as const;

export const MODULE_KEYS = MODULES.map((m) => m.key);

export const BUSINESS_TYPES: Record<string, { label: string; modules: string[] }> = {
  travel: {
    label: "Travel and visa",
    modules: ["crm", "sales", "marketing", "accounting", "visa", "travel", "support", "office", "targets", "documents", "reports", "approvals", "procurement", "hrm", "payroll", "inventory"],
  },
  education: {
    label: "Education consultancy",
    modules: ["crm", "sales", "marketing", "accounting", "education", "visa", "support", "office", "targets", "documents", "reports", "approvals", "hrm", "payroll"],
  },
  tourism: {
    label: "Tourism projects",
    modules: ["crm", "sales", "tourism", "travel", "accounting", "support", "office", "targets", "documents", "reports", "approvals", "hrm", "payroll"],
  },
  ecommerce: {
    label: "Shop and products",
    modules: ["crm", "sales", "marketing", "ecommerce", "inventory", "procurement", "accounting", "support", "office", "targets", "reports", "approvals", "hrm", "payroll"],
  },
  services: {
    label: "Sessions and memberships",
    modules: ["crm", "sales", "bookings", "accounting", "support", "office", "targets", "documents", "reports", "approvals", "hrm", "payroll", "marketing"],
  },
  assessment: {
    label: "Private assessments",
    modules: ["crm", "bookings", "accounting", "documents", "sensitive", "support", "office", "reports", "approvals", "hrm"],
  },
  companion: {
    label: "Companion service",
    modules: ["crm", "bookings", "accounting", "support", "sensitive", "documents", "office", "reports", "approvals"],
  },
};

export const LEAD_SOURCES = ["Facebook", "Instagram", "WhatsApp", "Website", "Phone call", "Walk-in", "Referral", "Existing customer", "Other"];
export const LEAD_STATUSES = ["new", "contacted", "interested", "consultation", "quotation", "follow-up", "converted", "lost", "not interested"];
export const PIPELINE = ["New lead", "Contacted", "Consultation", "Quotation", "Negotiation", "Won", "Lost"];
export const VISA_STATUSES = ["new", "consultation", "documents pending", "documents received", "under preparation", "ready for submission", "submitted", "embassy processing", "additional documents requested", "approved", "refused", "passport ready", "delivered", "cancelled"];
export const PAYMENT_METHODS = ["cash", "bank", "bkash", "nagad", "rocket", "card", "other"];
export const INVOICE_KINDS = [
  { value: "service", label: "Our service fee" },
  { value: "product", label: "Product" },
  { value: "third_party", label: "Third-party money (not our income)" },
];

export const GL = {
  cash: "1000",
  bank: "1010",
  mfs: "1020",
  inventory: "1300",
  ar: "1100",
  ap: "2000",
  advances: "2100",
  tax: "2200",
  thirdParty: "2300",
  serviceRevenue: "4000",
  productRevenue: "4100",
  expense: "5000",
  cogs: "5100",
  discount: "4900",
} as const;

export const CHART = [
  { code: "1000", name: "Cash", accountType: "asset" },
  { code: "1010", name: "Bank", accountType: "asset" },
  { code: "1020", name: "Mobile financial services", accountType: "asset" },
  { code: "1100", name: "Customer amounts due", accountType: "asset" },
  { code: "1300", name: "Inventory", accountType: "asset" },
  { code: "2000", name: "Supplier amounts payable", accountType: "liability" },
  { code: "2100", name: "Customer advances", accountType: "liability" },
  { code: "2200", name: "Tax payable", accountType: "liability" },
  { code: "2300", name: "Third-party money held", accountType: "liability" },
  { code: "3000", name: "Owner equity", accountType: "equity" },
  { code: "4000", name: "Service income", accountType: "income" },
  { code: "4100", name: "Product income", accountType: "income" },
  { code: "4900", name: "Discounts given", accountType: "income" },
  { code: "5000", name: "Operating expenses", accountType: "expense" },
  { code: "5100", name: "Cost of products sold", accountType: "expense" },
];

export const NAV = [
  { group: "Today", href: "/dashboard", label: "Dashboard", module: "dashboard" },
  { group: "Today", href: "/me", label: "My desk", module: "dashboard" },
  { group: "Today", href: "/data-entry", label: "Data entry", module: "dashboard" },
  { group: "Today", href: "/approvals", label: "Approvals", module: "approvals" },
  { group: "Today", href: "/notifications", label: "Notifications", module: "dashboard" },
  { group: "Customers", href: "/crm", label: "Customers", module: "crm" },
  { group: "Customers", href: "/leads", label: "Leads", module: "crm" },
  { group: "Customers", href: "/sales", label: "Sales", module: "sales" },
  { group: "Customers", href: "/support", label: "Support", module: "support" },
  { group: "Operations", href: "/visa", label: "Visa", module: "visa" },
  { group: "Operations", href: "/travel", label: "Travel", module: "travel" },
  { group: "Operations", href: "/education", label: "Education", module: "education" },
  { group: "Operations", href: "/tourism", label: "Tourism", module: "tourism" },
  { group: "Operations", href: "/bookings", label: "Bookings", module: "bookings" },
  { group: "Operations", href: "/shop", label: "Shop", module: "ecommerce" },
  { group: "Money", href: "/accounting", label: "Invoices & receipts", module: "accounting" },
  { group: "Money", href: "/expenses", label: "Expenses", module: "accounting" },
  { group: "Money", href: "/cash", label: "Cash & bank", module: "accounting" },
  { group: "Money", href: "/buying", label: "Buying", module: "procurement" },
  { group: "Money", href: "/marketing", label: "Marketing", module: "marketing" },
  { group: "People", href: "/people", label: "Employees", module: "hrm" },
  { group: "People", href: "/attendance", label: "Attendance", module: "hrm" },
  { group: "People", href: "/leave", label: "Leave", module: "hrm" },
  { group: "People", href: "/payroll", label: "Payroll", module: "payroll" },
  { group: "People", href: "/targets", label: "Targets", module: "targets" },
  { group: "People", href: "/office", label: "Office", module: "office" },
  { group: "People", href: "/stock", label: "Stock & assets", module: "inventory" },
  { group: "Control", href: "/reports", label: "Reports", module: "reports" },
  { group: "Control", href: "/documents", label: "Documents", module: "documents" },
  { group: "Control", href: "/private", label: "Private records", module: "sensitive" },
  { group: "Control", href: "/companies", label: "Companies", module: "companies" },
  { group: "Control", href: "/settings", label: "Settings", module: "settings" },
  { group: "Control", href: "/audit", label: "Audit log", module: "audit" },
  { group: "Control", href: "/help", label: "Help", module: "dashboard" },
] as const;

export function rolePresets(): Record<string, { name: string; description: string; permissions: string[] }> {
  const manage = (mods: string[]) => mods.flatMap((m) => [`${m}:manage`]);
  const view = (mods: string[]) => mods.map((m) => `${m}:view`);
  const viewCreate = (mods: string[]) => mods.flatMap((m) => [`${m}:view`, `${m}:create`]);
  return {
    super_admin: {
      name: "Owner / Super admin",
      description: "Full access to every company and setting.",
      permissions: ["*"],
    },
    group_admin: {
      name: "Group administrator",
      description: "Runs the group, but cannot replace the owner role.",
      permissions: ["group:view", ...manage(MODULE_KEYS), "companies:manage", "settings:view", "audit:view", "audit:export"],
    },
    company_admin: {
      name: "Company administrator",
      description: "Full access inside assigned companies.",
      permissions: manage(MODULE_KEYS.filter((m) => m !== "sensitive")),
    },
    branch_manager: {
      name: "Branch manager",
      description: "Sees one branch and approves everyday work, not payroll.",
      permissions: [...view(["crm", "sales", "accounting", "visa", "travel", "education", "support", "office", "reports", "inventory"]), "crm:create", "crm:edit", "sales:create", "sales:edit", "office:manage", "approvals:approve", "hrm:view", "hrm:approve", "support:manage"],
    },
    department_manager: {
      name: "Department manager",
      description: "Manages a team’s work and leave.",
      permissions: ["crm:view", "crm:edit", "sales:view", "office:manage", "hrm:view", "hrm:approve", "targets:view", "support:view"],
    },
    sales: {
      name: "Sales executive",
      description: "Leads, quotations, and follow-up. Cannot change confirmed money records.",
      permissions: ["crm:view", "crm:create", "crm:edit", "sales:manage", "targets:view", "support:create", "accounting:view"],
    },
    marketing: {
      name: "Marketing executive",
      description: "Campaigns, content, and lead sources.",
      permissions: ["marketing:manage", "crm:view", "crm:create", "reports:view", "targets:view"],
    },
    crm: {
      name: "CRM officer",
      description: "Customer records, follow-up, and history.",
      permissions: ["crm:manage", "support:view", "sales:view"],
    },
    customer_service: {
      name: "Customer service officer",
      description: "Tickets, bookings, and customer lookup.",
      permissions: ["support:manage", "crm:view", "bookings:view", "bookings:create", "bookings:edit"],
    },
    visa_officer: {
      name: "Visa officer",
      description: "Visa files and documents. No payroll.",
      permissions: ["visa:manage", "documents:view", "documents:create", "documents:verify", "crm:view", "travel:view", "travel:create"],
    },
    education_consultant: {
      name: "Education consultant",
      description: "Students, applications, and related visa progress.",
      permissions: ["education:manage", "visa:view", "crm:view", "crm:create", "documents:view", "documents:create"],
    },
    document_officer: {
      name: "Document officer",
      description: "Uploads and verifies documents.",
      permissions: ["documents:manage", "visa:view", "education:view"],
    },
    accounts: {
      name: "Accounts officer",
      description: "Money records and reports. No confidential HR salary file unless granted.",
      permissions: ["accounting:manage", "procurement:view", "procurement:create", "procurement:approve", "reports:view", "reports:export", "approvals:approve", "crm:view"],
    },
    hr: {
      name: "HR officer",
      description: "Employees, attendance, leave, and payroll. No customer money records.",
      permissions: ["hrm:manage", "payroll:manage", "office:view", "targets:view", "documents:view"],
    },
    data_entry: {
      name: "Data entry operator",
      description: "Can add records for checking. Cannot approve or delete money records.",
      permissions: viewCreate(["crm", "visa", "travel", "education", "tourism", "ecommerce", "bookings", "support", "office", "procurement", "documents", "accounting"]),
    },
    readonly: {
      name: "Read-only user",
      description: "Can look, not change.",
      permissions: view(["crm", "sales", "marketing", "accounting", "visa", "travel", "education", "tourism", "ecommerce", "bookings", "office", "support", "reports", "inventory"]),
    },
    auditor: {
      name: "Auditor",
      description: "Can review and export finance and audit history. Cannot edit.",
      permissions: ["accounting:view", "accounting:export", "reports:view", "reports:export", "audit:view", "audit:export", "approvals:view", "documents:view"],
    },
  };
}
