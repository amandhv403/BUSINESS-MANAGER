import { AppError } from "./errors";

export function todayDhaka(date = new Date()) {
  return new Intl.DateTimeFormat("en-CA", { timeZone: "Asia/Dhaka" }).format(date);
}

export function formatDate(value?: string | null) {
  if (!value) return "—";
  const [y, m, d] = value.slice(0, 10).split("-");
  if (!y || !m || !d) return value;
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${d} ${months[Number(m) - 1] ?? m} ${y}`;
}

export function formatDateTime(value?: Date | string | null) {
  if (!value) return "—";
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Dhaka",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

export function formatBdt(value?: number | string | null) {
  const paisa = Math.round(Number(value ?? 0));
  const sign = paisa < 0 ? "-" : "";
  const abs = Math.abs(paisa);
  const taka = Math.floor(abs / 100);
  const frac = String(abs % 100).padStart(2, "0");
  return `${sign}৳${taka.toLocaleString("en-US")}.${frac}`;
}

export function formatBdtPlain(value?: number | string | null) {
  return `BDT ${formatBdt(value).replace("৳", "")}`;
}

export function takaToPaisa(input: unknown, label = "Amount") {
  const clean = String(input ?? "").replace(/,/g, "").trim();
  if (!clean) return 0;
  if (!/^\d+(\.\d{1,2})?$/.test(clean)) {
    throw new AppError(`${label} must be a number with up to 2 decimal places.`);
  }
  const [whole, frac = ""] = clean.split(".");
  return Number(whole) * 100 + Number(frac.padEnd(2, "0"));
}

export function textOf(input: unknown, label: string, required = false, max = 500) {
  const value = String(input ?? "").trim();
  if (!value && required) throw new AppError(`${label} is required.`);
  if (value.length > max) throw new AppError(`${label} is too long.`);
  return value;
}

export function intOf(input: unknown, label: string, required = false) {
  const raw = String(input ?? "").trim();
  if (!raw) {
    if (required) throw new AppError(`${label} is required.`);
    return null;
  }
  const n = Number(raw);
  if (!Number.isInteger(n)) throw new AppError(`${label} must be a whole number.`);
  return n;
}

export function dateOf(input: unknown, label: string, required = false) {
  const value = String(input ?? "").trim();
  if (!value) {
    if (required) throw new AppError(`${label} is required.`);
    return null;
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new AppError(`${label} must be a real date.`);
  return value;
}

export function likeTerm(q: string) {
  return `%${q.replace(/[\\%_]/g, "\\$&")}%`;
}

export function spOne(sp: Record<string, string | string[] | undefined>, key: string) {
  const value = sp[key];
  return Array.isArray(value) ? value[0] ?? "" : value ?? "";
}

export function pageOf(sp: Record<string, string | string[] | undefined>) {
  const n = Number(spOne(sp, "page") || 1);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 1;
}

export function qs(sp: Record<string, string | string[] | undefined>, updates: Record<string, string | null>) {
  const params = new URLSearchParams();
  for (const [key, value] of Object.entries(sp)) {
    if (typeof value === "string" && value) params.set(key, value);
  }
  for (const [key, value] of Object.entries(updates)) {
    if (!value) params.delete(key);
    else params.set(key, value);
  }
  const s = params.toString();
  return s ? `?${s}` : "";
}

export function maskPassport(value?: string | null) {
  if (!value) return "—";
  if (value.length <= 3) return "•••";
  return `${"•".repeat(Math.max(4, value.length - 3))}${value.slice(-3)}`;
}

export function csvCell(value: unknown) {
  let s = String(value ?? "");
  if (/^[=+\-@]/.test(s)) s = `'${s}`;
  return `"${s.replace(/"/g, '""')}"`;
}

export function addDays(iso: string, days: number) {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1));
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}

export function monthKey(iso = todayDhaka()) {
  return iso.slice(0, 7);
}

export function percent(part: number, total: number) {
  if (!total) return 0;
  return Math.round((part / total) * 100);
}

export function safeNext(input: unknown) {
  const value = String(input ?? "");
  if (!value.startsWith("/") || value.startsWith("//") || value.startsWith("/\\")) return "/dashboard";
  return value;
}

export function glForAccountType(type: string) {
  if (type === "bank") return "1010";
  if (type === "mfs") return "1020";
  return "1000";
}
