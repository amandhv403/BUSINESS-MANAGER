# Architecture

AIO Desk is one Next.js website with one PostgreSQL database. It is not a set of separate apps.

## Parts

- Pages live in `src/app`. The signed-in desk is one route that opens the right screen.
- Business rules live in `src/lib/services`. Money changes run in database transactions.
- Permissions are checked on the server in `src/lib/guard.ts`.
- Tables live in `src/db/schema.ts`.
- The browser never receives the database password.

## Company model

An owner can see every company. Other people only see companies listed on their user. Each company can turn modules on or off. A travel company does not have to show the shop. A shop does not have to show visa files.

## Money model

Invoices, receipts, payments, expenses, cash accounts, and journal entries are stored separately and updated together.

- Service fees go to service income.
- Product sales go to product income.
- Embassy or supplier money collected for a client goes to a third-party liability, not to income.
- Customer advances are a liability until used or refunded.
- Journal debits and credits must match or the save is refused.

This is the base for a later full general ledger. It is not a completed statutory accounting product.

## Files

Uploads go to `storage/uploads`, outside the public website folder. Download links check the signed-in user and the company.

## What is intentionally not connected

Facebook, Instagram, WhatsApp, email, SMS, airline booking systems, and payment gateways. Those need your own API permission. Campaigns and bookings can be recorded by hand until then.
