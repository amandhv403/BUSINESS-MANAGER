# Security notes

## What is in place

- Passwords are stored with scrypt and a random salt. They are not stored as plain text.
- Sign-in uses a random httpOnly cookie. The cookie is not readable by page scripts.
- Too many failed sign-ins are slowed down.
- Optional authenticator codes can be turned on by each person.
- Every important action checks permission on the server.
- Company records are filtered on the server.
- Payroll and private questionnaire pages have extra checks.
- Uploaded files are outside the public folder and are served only after a permission check.
- SVG uploads are not allowed, because they can carry scripts.
- File size is limited to 8 MB.
- CSV export prefixes cells that start with `=`, `+`, `-`, or `@` so Excel does not treat them as formulas.
- Confirmed financial rows are cancelled, not deleted.
- Duplicate payment references are refused.
- Audit log records who did important actions.
- Secrets belong in `.env`, which is not part of the ZIP.

## What you must still do

- Change starter passwords.
- Keep backups private.
- Use HTTPS when the site is on the internet.
- Do not put the database password in the browser code or in GitHub.
- Connect a private file store before you rely on passport uploads on a temporary host.
- Review who has the owner role. Only one or two people should have it.

## What is not claimed

This installation has not had an independent security audit. It is built with ordinary careful controls for a small office, not certified for a bank.
