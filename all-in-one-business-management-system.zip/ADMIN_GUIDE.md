# Administrator guide

This is for the owner.

## First day

1. Sign in as `owner@aiodesk.local`.
2. Open **Settings** and change the starter password.
3. Open **Companies** and check the 11 starter companies. Edit addresses, phones, colours, and VAT if you use it.
4. Turn modules off for work a company does not do.
5. Add real staff in **Settings**. Give each person only the companies they should see.
6. Give each person a starting password and ask them to change it.
7. Download a backup from **Settings** and keep the file private.

## Roles already included

Owner, group administrator, company administrator, branch manager, sales, marketing, CRM, customer service, visa, education, documents, accounts, HR, data entry, read-only, and auditor.

Accounts staff cannot open payroll unless you give them that permission. Visa staff cannot open payroll. HR cannot open customer money records.

You can add a custom role. Only the owner can do that.

## Password reset without email

1. Open **Settings**.
2. Next to the person, choose **Reset code**.
3. Read the code on the screen and tell them in person or by a trusted phone call.
4. They open **I have a reset code** on the sign-in page.

Email reset is not connected yet. Do not expect a message to arrive in their inbox.

## Extra sign-in security

In **Settings**, start authenticator setup, add the secret to an app such as Google Authenticator, then enter a code to turn it on. Do not send the secret by public social media.

## Sample records

The first installation includes clearly labelled sample customers, an invoice, a visa file, and a low-stock toy. They are for learning. Replace them with real records before you rely on the figures.

## What this money section is

It records invoices, receipts, expenses, cash, bank, bKash, supplier balances, and a simple journal. It is ready to grow into fuller accounts later. It is not a substitute for your auditor or tax filing.
