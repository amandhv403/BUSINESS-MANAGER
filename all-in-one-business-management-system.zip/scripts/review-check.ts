import "dotenv/config";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { companies, customers, invoices, journalLines, moneyAccounts, receipts, roles, users, userCompanies } from "@/db/schema";
import { hashPassword, totpCode, verifyPassword, verifyTotp, generateTotpSecret } from "@/lib/auth";
import { allows } from "@/lib/permissions";
import { rolePresets } from "@/lib/constants";
import type { Ctx } from "@/lib/types";
import { todayDhaka } from "@/lib/utils";
import { cancelReceipt, recordPayment, saveInvoice } from "@/lib/services/finance";
import { AppError } from "@/lib/errors";

function fail(message: string): never {
  throw new Error(message);
}

async function main() {
  const results: string[] = [];
  const pass = (name: string) => results.push(`PASS ${name}`);

  const [owner] = await db.select().from(users).where(eq(users.email, "owner@aiodesk.local"));
  if (!owner || !verifyPassword("Owner#2026", owner.passwordHash)) fail("Owner password check failed.");
  pass("owner password");

  const secret = generateTotpSecret();
  const code = totpCode(secret);
  if (!verifyTotp(secret, code)) fail("Authenticator code did not match.");
  pass("authenticator code");

  const presets = rolePresets();
  if (allows(presets.visa_officer.permissions, "payroll", "view")) fail("Visa officer can see payroll.");
  if (allows(presets.accounts.permissions, "payroll", "view")) fail("Accounts officer can see payroll.");
  if (!allows(presets.hr.permissions, "payroll", "view")) fail("HR cannot see payroll.");
  if (!allows(presets.sales.permissions, "sales", "create")) fail("Sales cannot create deals.");
  if (allows(presets.sales.permissions, "accounting", "approve")) fail("Sales can approve money.");
  pass("role permissions");

  const [company] = await db.select().from(companies).where(eq(companies.shortName, "DH"));
  if (!company) fail("Dhaka Holiday missing.");
  const visaAccess = await db.select().from(userCompanies).innerJoin(users, eq(users.id, userCompanies.userId)).where(eq(users.email, "visa@aiodesk.local"));
  if (visaAccess.some((row) => row.user_companies.companyId !== company.id && row.user_companies.companyId === 0)) fail("unexpected");
  const visaCompanies = visaAccess.map((row) => row.user_companies.companyId);
  const allCompanies = await db.select({ id: companies.id, shortName: companies.shortName }).from(companies);
  const little = allCompanies.find((row) => row.shortName === "LW");
  if (!little || visaCompanies.includes(little.id)) fail("Visa officer can open Little Wonder.");
  pass("company separation");

  const [customer] = await db.select().from(customers).where(eq(customers.companyId, company.id)).limit(1);
  const [cash] = await db.select().from(moneyAccounts).where(and(eq(moneyAccounts.companyId, company.id), eq(moneyAccounts.accountType, "cash"))).limit(1);
  if (!customer || !cash) fail("Sample customer or cash account missing.");

  const ctx: Ctx = {
    user: { id: owner.id, name: owner.name, email: owner.email, roleId: owner.roleId, roleKey: "super_admin", roleName: "Owner", permissions: ["*"], employeeId: owner.employeeId, active: true, totpEnabled: false, phone: owner.phone },
    companies: [],
    company: { id: company.id, name: company.name, shortName: company.shortName, businessType: company.businessType, brandColor: company.brandColor, accentColor: company.accentColor, city: company.city, currency: company.currency, taxName: company.taxName, taxRateBps: company.taxRateBps, address: company.address, phone: company.phone, email: company.email, logoText: company.logoText, invoicePrefix: company.invoicePrefix, receiptPrefix: company.receiptPrefix, active: company.active },
    companyIds: [company.id],
    allMode: false,
    modules: new Set(["accounting"]),
    branchId: null,
    permissions: ["*"],
    can: () => true,
    ip: "review",
  };

  const invoice = await saveInvoice(ctx, {
    companyId: company.id,
    customerId: customer.id,
    issueDate: todayDhaka(),
    lines: [{ description: "Review check service", qty: 1, unitPaisa: 100000, kind: "service" }],
    discountPaisa: 0,
    notes: "REVIEW-CHECK",
    issueNow: true,
  });
  const reviewRef = `REVIEW-${Date.now()}`;
  const firstPay = await recordPayment(ctx, {
    companyId: company.id,
    customerId: customer.id,
    amountPaisa: 40000,
    method: "cash",
    reference: reviewRef,
    accountId: cash.id,
    paidOn: todayDhaka(),
    invoiceId: invoice.id,
  });
  const [afterPay] = await db.select().from(invoices).where(eq(invoices.id, invoice.id));
  if (afterPay.paidPaisa !== 40000 || afterPay.duePaisa !== 60000 || afterPay.status !== "partial") fail(`Partial payment wrong: ${afterPay.paidPaisa}/${afterPay.duePaisa}/${afterPay.status}`);
  pass("partial payment");

  let duplicateBlocked = false;
  try {
    await recordPayment(ctx, {
      companyId: company.id,
      customerId: customer.id,
      amountPaisa: 1000,
      method: "cash",
      reference: reviewRef,
      accountId: cash.id,
      paidOn: todayDhaka(),
      invoiceId: invoice.id,
    });
  } catch (error) {
    duplicateBlocked = error instanceof AppError;
  }
  if (!duplicateBlocked) fail("Duplicate payment reference was accepted.");
  pass("duplicate payment blocked");

  const beforeNumbers = await db.select({ number: receipts.number }).from(receipts).where(eq(receipts.companyId, company.id));
  await cancelReceipt(ctx, firstPay.receiptId!, "Review check cancellation");
  const [cancelled] = await db.select().from(receipts).where(eq(receipts.id, firstPay.receiptId!));
  if (cancelled.status !== "cancelled") fail("Receipt was not cancelled.");
  const [restored] = await db.select().from(invoices).where(eq(invoices.id, invoice.id));
  if (restored.duePaisa !== 100000 || restored.paidPaisa !== 0) fail("Cancellation did not restore the invoice balance.");
  const second = await recordPayment(ctx, {
    companyId: company.id,
    customerId: customer.id,
    amountPaisa: 10000,
    method: "cash",
    reference: `REVIEW2-${Date.now()}`,
    accountId: cash.id,
    paidOn: todayDhaka(),
    invoiceId: invoice.id,
  });
  const [newReceipt] = await db.select().from(receipts).where(eq(receipts.id, second.receiptId!));
  if (beforeNumbers.some((row) => row.number === newReceipt.number) || newReceipt.number === cancelled.number) fail("A cancelled receipt number was reused.");
  pass("cancelled number not reused");

  const [books] = await db.select({ debit: sql<number>`coalesce(sum(${journalLines.debitPaisa}),0)::float8`, credit: sql<number>`coalesce(sum(${journalLines.creditPaisa}),0)::float8` }).from(journalLines);
  if (Number(books.debit) !== Number(books.credit)) fail(`Journals do not balance: ${books.debit} vs ${books.credit}`);
  pass("journal balance");

  const roleRows = await db.select().from(roles);
  if (roleRows.length < 16) fail(`Expected the starter roles, found ${roleRows.length}.`);
  pass("starter roles present");

  console.log(results.join("\n"));
  console.log(`REVIEW_OK ${results.length} checks`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
