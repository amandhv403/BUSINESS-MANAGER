#!/bin/sh
set -eu
if [ -z "${DATABASE_URL:-}" ]; then
  echo "DATABASE_URL is not set. A backup was not created."
  exit 1
fi
mkdir -p backups
stamp=$(date +%F-%H%M)
dbfile="backups/db-$stamp.dump"
pg_dump "$DATABASE_URL" -Fc -f "$dbfile"
if [ ! -s "$dbfile" ]; then
  echo "Database backup file is empty. Do not treat this backup as successful."
  exit 1
fi
if [ -d storage/uploads ]; then
  tar -czf "backups/files-$stamp.tar.gz" storage/uploads
fi
echo "Backup written and size checked: $dbfile"
ls -l "$dbfile"
