# Testing report

Reviewed twice on this installation. These are real checks, not a claim that every future edge case is covered.

## Review pass 1 and pass 2

The same automated check was run twice with `npx tsx scripts/review-check.ts`. Both passes printed `REVIEW_OK 9 checks`.

| Check | Pass 1 | Pass 2 |
| --- | --- | --- |
| Owner password matches the seeded hash | Pass | Pass |
| Authenticator code matches its secret | Pass | Pass |
| Visa and accounts roles cannot view payroll | Pass | Pass |
| HR can view payroll. Sales cannot approve money | Pass | Pass |
| Visa officer is not linked to Little Wonder Co. | Pass | Pass |
| Partial payment updates paid and due amounts | Pass | Pass |
| The same bank reference cannot be posted twice | Pass | Pass |
| A cancelled receipt number is not reused | Pass | Pass |
| Journal debits equal journal credits | Pass | Pass |
| Starter roles are present | Pass | Pass |

## Code review findings that were fixed

- Recording an expense marked it saved but did not update cash or the journal. Fixed and rechecked.
- Using a customer advance could fail because the date field was required but not on that form. Fixed.
- Cancel receipt and refund existed in the server but had no buttons. Buttons were added on the invoice screen.
- Buying asked for a supplier number instead of a supplier list. It now uses a list.
- Database setup no longer depends on a hardcoded local address. `drizzle.config.ts` reads `DATABASE_URL`.

## Still not finished

- Email, WhatsApp, SMS, and social media posting
- Public GitHub and Vercel deployment. This computer has no login for those accounts.
- Full statutory accounts and bank reconciliation
- A scheduled backup. The owner download and `scripts/backup.sh` work when run.

## How another person can repeat the check

```bash
npm install
npx drizzle-kit push
npx tsx src/db/seed.ts
npx tsx scripts/review-check.ts
npm run build
```

Then start the site and open `/api/health`.
