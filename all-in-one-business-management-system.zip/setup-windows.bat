@echo off
echo AIO Desk local setup
echo This does not deploy the public website.
if not exist .env (
  echo Copy .env.example to .env and set DATABASE_URL first.
  exit /b 1
)
call npm install
if errorlevel 1 exit /b 1
call npx drizzle-kit push
if errorlevel 1 exit /b 1
call npx tsx src/db/seed.ts
if errorlevel 1 exit /b 1
call npm run build
if errorlevel 1 exit /b 1
echo.
echo Setup finished. Start the site with: npm run start
echo Then open http://localhost:3000
