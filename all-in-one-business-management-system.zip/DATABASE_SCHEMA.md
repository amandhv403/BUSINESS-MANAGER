# Database schema

The live table definitions are in `src/db/schema.ts`. This page explains them in plain English.

## Organisation

Companies, branches, departments, teams, users, roles, sessions, and company module switches.

## People

Employees, shifts, holidays, attendance, leave, payslips, reviews, and employee events such as warnings or training.

## Customers and sales

Customers, leads, activities, follow-ups, services, opportunities, pipeline stages, quotations, and commissions.

## Money

Invoices and lines, receipts, payments, allocations, expenses, cash/bank/mobile accounts, account transactions, chart of accounts, journal entries, suppliers, and purchase orders.

Numbers come from `number_sequences`. The next number only moves forward.

## Operations

Visa countries, categories, passports, applications, and status history. Travel bookings and hotels. Students, universities, courses, and admission applications. Tourism projects and partners. Session bookings. Shop products, stock movements, sales orders, and returns.

## Office

Tasks, meetings, notices, visitors, couriers, incidents, assets, supplies, support tickets, documents, templates, targets, approvals, notifications, audit log, consent, and assessments.

## Rules

- Money is stored as whole paisa.
- Company id is stored on operational records.
- Passport files are not in the public folder.
- Sample starter rows are marked in `sample_markers`.
