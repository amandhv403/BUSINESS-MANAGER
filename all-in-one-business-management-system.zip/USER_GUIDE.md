# User guide

You do not need to understand programming to use AIO Desk.

## Sign in

1. Open the website in Chrome, Edge, or your phone browser.
2. Type your email and password.
3. If extra security is on, also type the 6-digit code from your authenticator app.

## Choose the company

The company list is at the top. Always check the name before you save a record.

- **One company** — use this to add customers, invoices, visa files, and stock.
- **All companies** — the owner can look across the group. Do not add new records in that view.

A customer of Dhaka Holiday is not automatically a customer of Little Wonder Co.

## Everyday paths

- **Customers** — add a person once. Open their name to see history.
- **Leads** — enquiries. Use **Make customer** when they are ready. Do not type the same person twice.
- **Sales** — deals and quotations. A quotation can become an invoice.
- **Invoices & receipts** — bill the customer, then record the money received.
- **Visa** — open a file, add the passport, upload scans, update the status.
- **Shop** — sell a product and reduce stock when it is handed over.
- **My desk** — your attendance, leave request, payslips, and tasks.
- **Approvals** — say yes or no to leave, expenses, refunds, and cancellations.
- **Help** — short instructions inside the website.

## Money rules staff should know

- Type amounts in taka, for example `1500.50`.
- A bank or bKash reference cannot be used twice.
- A partial payment reduces what the customer still owes.
- Extra money becomes an advance held for that customer.
- Cancelled invoice and receipt numbers are never used again.
- Third-party money, such as an embassy fee, is not treated as your service income.
- Confirmed money records are cancelled with a reason. They are not silently deleted.

## If you cannot see a menu

Your role does not include it, or that module is turned off for the company. Ask the owner. Hiding a button is not the only protection: the server also refuses the action.
